﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;

namespace SCOR_Utils_Addin
{
    static class ExcelHelper
    {
        internal static object CheckNaN(double value)
        {
            return (Double.IsNaN(value) || Double.IsInfinity(value)) ? ExcelDna.Integration.ExcelError.ExcelErrorNA : (object)value;
        }

        internal static T CheckValue<T>(object value, T defaultValue) where T : struct
        {
            return (value is T) ? (T)value : defaultValue;
        }

        internal static bool IsMissing(object arg)
        {
            return arg.GetType() == typeof(ExcelMissing);
        }
    }
}
