﻿using System;
using System.Collections.Generic;
using System.Linq;
using ExcelDna.Integration;
using Excel = Microsoft.Office.Interop.Excel;
using IntelliSense = ExcelDna.IntelliSense;
using SCOR_Utils;
/*
missing arguments are of type ExcelMissing
cache: https://www.codeproject.com/Articles/1097174/Interpolation-in-Excel-using-Excel-DNA
*/

namespace SCOR_Utils_Addin
{
    //class was static
    //class didn't implement IExcelAddin Interface
    public class ExcelFunctions : IExcelAddIn
    {

        private static readonly string YCTag = @"#YC";

        public void AutoOpen()
        {
            IntelliSense.IntelliSenseServer.Register();
        }

        public void AutoClose()
        {

        }

        /*
        //TUTORIAL CACHE
        //STATUS: working but not faster at the time being with 1800 calls

        [ExcelFunction(Category = @"SCOR TEST", Description = "Create Interpolator object, test of cache")]
        public static object SCOR_CACHE_CURVE_CREATE(
            [ExcelArgument(Description = "Array of nodes")] double[] x,
            [ExcelArgument(Description = "Array of values")]  double[] y,
            [ExcelArgument(Description = "Interpolation Method = Linear or Natural Cubic Spline")] string interpolMethod)
        {
            if (!Enum.TryParse(interpolMethod, out InterpolationMethodType interpolationMethod))
                return ExcelError.ExcelErrorValue;
            else
            {
                return Cache.GlobalCache.CreateHandle(YCTag, new object[] { x, y, interpolationMethod }, (objectType, parameters) =>
                  {
                      Curve YC = null;
                      try
                      {
                          YC = new Curve(x, y);
                      }
                      catch (Exception e)
                      {
                          return e;
                      }

                      if (YC == null)
                          return ExcelError.ExcelErrorNull;
                      else
                          return YC;
                  }
                  );
            }
        }


        [ExcelFunction(Category = @"SCOR TEST", Description = "Evaluate interpolation at specified point")]
        public static object SCOR_CACHE_CURVE_INTERPOLATE(
            [ExcelArgument(Description = "Interpolator object")] string handle,
            [ExcelArgument(Description = "Interpolation point")] double x)
        {
            if (Cache.GlobalCache.TryGetObject(handle, out Curve YC))
            {
                if (YC != null)
                {
                    return ExcelHelper.CheckNaN(YC.ZeroCoupon(x));
                }
            }

            return ExcelError.ExcelErrorRef;
        }




        //END TUTORIAL CACHE
        */



        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Interpolation method implementing linear or natural cubic spline methods",HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static double SCOR_INTERPOLATE([ExcelArgument(@"InpX as Double()")] object InpX,
                                         [ExcelArgument(@"InpY as Double()")] object InpY,
                                         [ExcelArgument(@"X as Double")] object X,
                                         [ExcelArgument(@"[Optional: InterpolationMethod as String = ""linear""]")][System.Runtime.InteropServices.Optional] string interpolMethod)
        {

            if (ExcelHelper.IsMissing(InpX)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"InpX", @"Argument cannot be null, expecting an array");

            if(ExcelHelper.IsMissing(InpY))
                throw new ArgumentNullException(@"InpY", @"Argument cannot be null, expecting an array");

            double Xinput = 0;
            if (ExcelHelper.IsMissing(X))
            {
                throw new ArgumentNullException(@"X", @"Argument cannot be null, expecting a double");
            }
            else
            {
                //A COM Object can also be an array
                if (X.GetType().IsCOMObject)
                {
                    if(!double.TryParse(((Excel.Range)X).Value2, out Xinput)) throw new InvalidCastException(@"Problem casting X to a double from a Range");
                }

                //An array can also be treated to pass several values at the same time
                //if (X.GetType().IsArray)
                //{
                //    if (((Array)X).Length == 1)
                //    {
                //        if(!double.TryParse(((Array)X).ToString(), out Xinput)) throw new InvalidCastException(@"Problem casting X to a double from an Array");
                //    }
                //    else
                //    {
                //        throw new InvalidCastException(@"Problem casting X to a double from an Array");
                //    }
                //}

                if (X.GetType() == typeof(DateTime)) Xinput = ((DateTime)X).ToOADate();
                if (X.GetType() == typeof(string)) if(!double.TryParse((string)X,out Xinput)) { throw new InvalidCastException(@"Problem casting X to a double from a String"); }
                if (X.GetType() == typeof(double)) Xinput = (double)X;
            }

            InterpolationMethodType interpolationMethod;
            if (ExcelHelper.IsMissing(interpolMethod))
                interpolationMethod = InterpolationMethodType.LINEAR;
            else
            {
                if (!Enum.TryParse(interpolMethod, out interpolationMethod))
                    return (double)ExcelError.ExcelErrorValue;
            }

            Utils utils = new Utils();

            if (utils != null)
                return utils.Interpolate(InpX, InpY, Xinput, interpolationMethod);
            else
                return (double)ExcelError.ExcelErrorNA;
            //if (string.IsNullOrWhiteSpace(InterpolationMethod.ToString())) InterpolationMethod = InterpolationMethodType.LINEAR;
            //Utils utils = new Utils();

            //if (utils != null)
            //    return utils.Interpolate(InpX, InpY, Xinput, interpolationMethod);
            //else
            //    return (double)ExcelError.ExcelErrorNA;

        }


        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Forward Rate applicable between the startDate and endDate, based on the curve labeled as YCidentifier. This curve has to already exist in the cache.", HelpTopic = @"https://en.wikipedia.org/wiki/Forward_rate", IsThreadSafe = true)]
        public static double SCOR_FWD([ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double StartDate,
                                     [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double EndDate,
                                     [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
                                     [ExcelArgument(@"YCZC as Double()")] object YCZC) //for test
                                                                                       //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
                                                                                       //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
        {
            if (ExcelHelper.IsMissing(StartDate))
                throw new ArgumentNullException(@"StartDate", @"Argument cannot be null, expecting an array");
            else
            {
                if (StartDate == 0) return (double)ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(EndDate))
                throw new ArgumentNullException(@"EndDate", @"Argument cannot be null, expecting an array");
            else
            {
                if (EndDate == 0) return (double)ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(YCTenors)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"YCTenors", @"Argument cannot be null, expecting an array");

            if (ExcelHelper.IsMissing(YCZC))
                throw new ArgumentNullException(@"YCZC", @"Argument cannot be null, expecting an array");

            List<dynamic> TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            List<dynamic> ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();
            Dictionary<double, double> curvePoints = TenorList.Cast<double>().Zip(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value);

            Curve YC = new Curve(curvePoints);

            if (YC != null)
                return (double)ExcelHelper.CheckNaN(YC.ForwardRate(StartDate,EndDate));
            else
                return (double)ExcelError.ExcelErrorNA;

            //throw new NotImplementedException();
        }


        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Zero Coupon applicable at the input Maturity, based on the curve labeled as YCidentifier", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static double SCOR_ZC([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                                  [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
                                  [ExcelArgument(@"YCZC as Double()")] object YCZC) //for test
                                                                                    //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
                                                                                    //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
        {

            if (ExcelHelper.IsMissing(MaturityDate))
                throw new ArgumentNullException(@"MaturityDate", @"Argument cannot be null, expecting a double");
            else
            {
                if (MaturityDate == 0) return (double)ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(YCTenors)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"YCTenors", @"Argument cannot be null, expecting an array");

            if (ExcelHelper.IsMissing(YCZC))
                throw new ArgumentNullException(@"YCZC", @"Argument cannot be null, expecting an array");

            List<dynamic> TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            List<dynamic> ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();
            Dictionary<double, double> curvePoints = TenorList.Cast<double>().Zip(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value);

            Curve YC = new Curve(curvePoints);

            if (YC != null)
                return (double)ExcelHelper.CheckNaN(YC.ZeroCoupon(MaturityDate));
            else
                return (double)ExcelError.ExcelErrorNA;

            //cache is needed here
            //throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Discount Factor applicable at the input Maturity, based on the curve labeled as YCidentifier", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static double SCOR_DF([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                                  [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
                                  [ExcelArgument(@"YCZC as Double()")] object YCZC) //for test
                                                                                    //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
                                                                                    //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
        {

            if (ExcelHelper.IsMissing(MaturityDate))
                throw new ArgumentNullException(@"MaturityDate", @"Argument cannot be null, expecting a double");
            else
            {
                if (MaturityDate == 0) return (double)ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(YCTenors)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"YCTenors", @"Argument cannot be null, expecting an array");

            if (ExcelHelper.IsMissing(YCZC))
                throw new ArgumentNullException(@"YCZC", @"Argument cannot be null, expecting an array");

            List<dynamic> TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            List<dynamic> ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();
            Dictionary<double, double> curvePoints = TenorList.Cast<double>().Zip(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value);

            Curve YC = new Curve(curvePoints);

            if (YC != null)
                return (double)ExcelHelper.CheckNaN(YC.DiscountFactor(MaturityDate));
            else
                return (double)ExcelError.ExcelErrorNA;

            //cache is needed here
            //throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Year Fraction between two dates.", HelpTopic = @"https://en.wikipedia.org/wiki/Day_count_convention", IsThreadSafe = true)]
        public static double SCOR_YF(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double StartDate,
            [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double EndDate,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention
            )
        {
            if (ExcelHelper.IsMissing(StartDate))
                throw new ArgumentNullException(@"StartDate", @"Argument cannot be null, expecting an array");
            else
            {
                if (StartDate == 0) return (double)ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(EndDate))
                throw new ArgumentNullException(@"EndDate", @"Argument cannot be null, expecting an array");
            else
            {
                if (EndDate == 0) return (double)ExcelError.ExcelErrorNull;
            }

            DayCountConventionType dayCountConvention;
            if (ExcelHelper.IsMissing(DayCountConvention))
                dayCountConvention = DayCountConventionType.ACT_360;
            else
            {
                if (!Enum.TryParse(DayCountConvention, out dayCountConvention))
                    return (double)ExcelError.ExcelErrorValue;
            }

            return (double)ExcelHelper.CheckNaN(DateHelper.YearFraction(StartDate,EndDate,dayCountConvention));
        }
/*
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Price, Accrued Interest, Yield to Maturity, Duration and Convexity for a bond specified with the input parameters. Output is an array of 5 elements Array(Price, Accrued Interest, Yield, Duration, Convexity)", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_(finance)", IsThreadSafe = true)]
        public static double[] SCOR_BONDPRICING([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                                  [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                                  [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                                  [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                                  [ExcelArgument(@"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)")] double QuotedPrice,
                                  [ExcelArgument(@"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)")] double Yield,
                                  [ExcelArgument(@"[Optional] YCidentifier as String (Name of an existing curve)")] string YCidentifier)
        {
            double price = 0, accruedInterest = 0.1, yield = -100, duration = -1, convexity = -2;

            double[] output = new double[5];
            output[0] = price;
            output[1] = accruedInterest;
            output[2] = yield;
            output[3] = duration;
            output[4] = convexity;
            return output;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Yield to Maturity for a bond specified with the input parameters and a given Yield.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
        public static double SCOR_BONDYIELDTOPRICE([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                                  [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                                  [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                                  [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                                  [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield)
        {
            return 0;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Clean Price for a bond specified with the input parameters and a given Price.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
        public static double SCOR_BONDPRICETOYIELD([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                          [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                          [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                          [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                          [ExcelArgument(@"Price as Double (Clean Price, quoted in Percentage)")] double Price)
        {
            return 0;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Modified Duration for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_duration", IsThreadSafe = true)]
        public static double SCOR_BONDDURATION([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                          [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                          [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                          [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                          [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield)
        {
            return 0;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Convexity for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_convexity", IsThreadSafe = true)]
        public static double SCOR_BONDCONVEXITY([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                          [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                          [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                          [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                          [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield)
        {
            return 0;
            throw new NotImplementedException();
        }
*/
    }
}
