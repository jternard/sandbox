﻿using System;
using System.Collections.Generic;
using System.Linq;
using ExcelDna.Integration;
using Excel = Microsoft.Office.Interop.Excel;
using IntelliSense = ExcelDna.IntelliSense;
using SCOR_Utils;
/*
To Test/Debug:
    Set global parameters to Debug and x64
    Set the projects to Active / Any CPU
    Open the addin with the loaded Excel file

To publish:
    Set global parameters to Release and x64
    Set the projects to Active / Any CPU
    Then Sign the resulting packed x64 xll file which can be distributed

To install:
    Users need only to load the xll from anywhere on the network or their computers
    It might be necessary to have an admin to validate the certificate

 
missing arguments are of type ExcelMissing
cache: https://www.codeproject.com/Articles/1097174/Interpolation-in-Excel-using-Excel-DNA

determining the calling cells: C API with xlfCaller option (https://social.msdn.microsoft.com/Forums/office/en-US/678c303c-aec9-4845-a4c1-1d15e0782659/xll-determines-the-activecell-in-custom-function?forum=exceldev)
C API is more or less the ExcelDna.Integration.ExcelReference: https://stackoverflow.com/questions/31038649/passing-an-excel-range-from-vba-to-c-sharp-via-excel-dna

Deployment:
    Remember to change the name of the embedded dll path in this add-in.dna
    Potentially with Installer class: https://github.com/Excel-DNA/WiXInstaller/blob/master/Source/InstallerCA/InstallerClass.cs
    Also related: https://stackoverflow.com/questions/18602560/how-to-deploy-an-excel-xll-add-in-and-automatically-register-the-add-in-in-excel
     */

namespace SCOR_Utils_Addin
{
    //class was static
    //class didn't implement IExcelAddin Interface
    public class ExcelFunctions : IExcelAddIn
    {

        //private static readonly string YCTag = @"#YC";

        public void AutoOpen()
        {
            IntelliSense.IntelliSenseServer.Register();
        }

        public void AutoClose()
        {

        }

        /*
        //TUTORIAL CACHE
        //STATUS: working but not faster at the time being with 1800 calls

        [ExcelFunction(Category = @"SCOR TEST", Description = "Create Interpolator object, test of cache")]
        public static object SCOR_CACHE_CURVE_CREATE(
            [ExcelArgument(Description = "Array of nodes")] double[] x,
            [ExcelArgument(Description = "Array of values")]  double[] y,
            [ExcelArgument(Description = "Interpolation Method = Linear or Natural Cubic Spline")] string interpolMethod)
        {
            if (!Enum.TryParse(interpolMethod, out InterpolationMethodType interpolationMethod))
                return ExcelError.ExcelErrorValue;
            else
            {
                return Cache.GlobalCache.CreateHandle(YCTag, new object[] { x, y, interpolationMethod }, (objectType, parameters) =>
                  {
                      Curve YC = null;
                      try
                      {
                          YC = new Curve(x, y);
                      }
                      catch (Exception e)
                      {
                          return e;
                      }

                      if (YC == null)
                          return ExcelError.ExcelErrorNull;
                      else
                          return YC;
                  }
                  );
            }
        }


        [ExcelFunction(Category = @"SCOR TEST", Description = "Evaluate interpolation at specified point")]
        public static object SCOR_CACHE_CURVE_INTERPOLATE(
            [ExcelArgument(Description = "Interpolator object")] string handle,
            [ExcelArgument(Description = "Interpolation point")] double x)
        {
            if (Cache.GlobalCache.TryGetObject(handle, out Curve YC))
            {
                if (YC != null)
                {
                    return ExcelHelper.CheckNaN(YC.ZeroCoupon(x));
                }
            }

            return ExcelError.ExcelErrorRef;
        }




        //END TUTORIAL CACHE
        */



        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Interpolation method implementing linear or natural cubic spline methods",HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object[,] SCOR_INTERPOLATE([ExcelArgument(@"InpX as Array of Double")] double[] InpX,
                                         [ExcelArgument(@"InpY as Array of Double")] double[] InpY,
                                         [ExcelArgument(@"X as Array of Double")] double[] X,
                                         [ExcelArgument(@"[Optional: InterpolationMethod as String = ""linear""]")][System.Runtime.InteropServices.Optional] string interpolMethod)
        {

            if (ExcelHelper.IsMissing(InpX)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"InpX", @"Argument cannot be null, expecting an array of double");

            if(ExcelHelper.IsMissing(InpY))
                throw new ArgumentNullException(@"InpY", @"Argument cannot be null, expecting an array of double");


            if (ExcelHelper.IsMissing(X))
            {
                throw new ArgumentNullException(@"X", @"Argument cannot be null, expecting an array of double");
            }
            //else
            //{
            //    //A COM Object can also be an array
            //    if (X.GetType().IsCOMObject)
            //    {
            //        if(!double.TryParse(((Excel.Range)X).Value2, out Xinput)) throw new InvalidCastException(@"Problem casting X to a double from a Range");
            //    }

            //    //An array can also be treated to pass several values at the same time
            //    //if (X.GetType().IsArray)
            //    //{
            //    //    if (((Array)X).Length == 1)
            //    //    {
            //    //        if(!double.TryParse(((Array)X).ToString(), out Xinput)) throw new InvalidCastException(@"Problem casting X to a double from an Array");
            //    //    }
            //    //    else
            //    //    {
            //    //        throw new InvalidCastException(@"Problem casting X to a double from an Array");
            //    //    }
            //    //}

            //    if (X.GetType() == typeof(DateTime)) Xinput = ((DateTime)X).ToOADate();
            //    if (X.GetType() == typeof(string)) if(!double.TryParse((string)X,out Xinput)) { throw new InvalidCastException(@"Problem casting X to a double from a String"); }
            //    if (X.GetType() == typeof(double)) Xinput = (double)X;
            //}


            //double[] Xinput = new double[X.Length];

            //var caller = XlCall.Excel(XlCall.xlfCaller) as ExcelReference;
            //object[,] result = new object[caller.RowLast - caller.RowFirst + 1, caller.ColumnLast - caller.ColumnFirst + 1];

            object[] result = new object[X.Length];

            InterpolationMethodType interpolationMethod;
            if (ExcelHelper.IsMissing(interpolMethod) || interpolMethod == default(string))
                interpolationMethod = InterpolationMethodType.LINEAR;
            else
            {
                if (!Enum.TryParse(interpolMethod, out interpolationMethod))
                {
                    throw new ArgumentOutOfRangeException(@"Interpolation Method", @"Please use the following values: ""LINEAR"", ""NATURAL_CUBIC_SPLINE""");
                }
            }

            Utils utils = new Utils();
            if (utils != null)
            {
                for (int i = 0; i < X.Length; i++)
                    result[i] = utils.Interpolate(InpX, InpY, X[i], interpolationMethod);
            }
            else
            {
                for (int i = 0; i < X.Length; i++)
                    result[i] = ExcelError.ExcelErrorValue;
            }



            var caller = XlCall.Excel(XlCall.xlfCaller) as ExcelReference;
            object[,] outputExcel = new object[caller.RowLast - caller.RowFirst + 1, caller.ColumnLast - caller.ColumnFirst + 1];
            if (outputExcel.GetLength(0) == 1)
            {
                for (int i = 0; i < Math.Min(outputExcel.GetLength(1),result.Length); i++)
                    outputExcel.SetValue(ExcelHelper.CheckNaN((double)result[i]), 0, i);
            }
            else
            {
                for (int i = 0; i < Math.Min(outputExcel.GetLength(0), result.Length); i++)
                    outputExcel.SetValue(ExcelHelper.CheckNaN((double)result[i]), i, 0);
            }

            return outputExcel;

            //if (string.IsNullOrWhiteSpace(InterpolationMethod.ToString())) InterpolationMethod = InterpolationMethodType.LINEAR;
            //Utils utils = new Utils();

            //if (utils != null)
            //    return utils.Interpolate(InpX, InpY, Xinput, interpolationMethod);
            //else
            //    return (double)ExcelError.ExcelErrorNA;

        }


        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Forward Rate applicable between the startDate and endDate, based on the curve labeled as YCidentifier. This curve has to already exist in the cache.", HelpTopic = @"https://en.wikipedia.org/wiki/Forward_rate", IsThreadSafe = true)]
        public static object SCOR_FWD(
                                    [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double StartDate,
                                    [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double EndDate,
                                    [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
                                    [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
                                                                                      //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
                                                                                      //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
                                    [ExcelArgument(@"[Optional: AsOfDate as double/date = Today]")][System.Runtime.InteropServices.Optional] double AsOfDate,
                                    [ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] string Currency,
                                    [ExcelArgument(@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE""]")][System.Runtime.InteropServices.Optional] string InterestMethod,
                                    [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT_360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention,
                                    [ExcelArgument(@"[Optional: InterpolationMethod as String = ""linear""]")][System.Runtime.InteropServices.Optional] string InterpolMethod
                                    )
        {

            if (ExcelHelper.IsMissing(StartDate))
                throw new ArgumentNullException(@"StartDate", @"Argument cannot be null, expecting an array");
            else
            {
                if (StartDate == 0) return ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(EndDate))
                throw new ArgumentNullException(@"EndDate", @"Argument cannot be null, expecting an array");
            else
            {
                if (EndDate == 0) return ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(YCTenors)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"YCTenors", @"Argument cannot be null, expecting an array");

            if (ExcelHelper.IsMissing(YCZC))
                throw new ArgumentNullException(@"YCZC", @"Argument cannot be null, expecting an array");

            List<dynamic> TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            List<dynamic> ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();

            Dictionary<double, double> curvePoints = new Dictionary<double, double>();
            for (int i = 0;i<TenorList.Count; i++)
            {
                if (!ExcelHelper.IsMissing(TenorList[i]) && !ExcelHelper.IsMissing(ZCList[i]))
                    curvePoints.Add(TenorList[i], ZCList[i]);
            }

            //Dictionary<double, double> curvePoints = TenorList.Cast<double>().Zip(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value);


            Curve YC = new Curve(curvePoints);

            if (YC == null)
                return ExcelError.ExcelErrorNA;

            if(!ExcelHelper.IsMissing(AsOfDate) && AsOfDate != 0)
                YC.AsOfDate = AsOfDate;

            YC.Currency = Currency;

            if (Enum.TryParse(InterestMethod, out InterestMethodType interestMethod))
                YC.InterestMethod = interestMethod;

            if (Enum.TryParse(DayCountConvention, out DayCountConventionType dayCountConvention))
                YC.DayCountConvention = dayCountConvention;

            if (Enum.TryParse(InterpolMethod, out InterpolationMethodType interpolationMethod))
                YC.InterpolationMethod = interpolationMethod;
            
            return ExcelHelper.CheckNaN(YC.ForwardRate(StartDate, EndDate));
            //throw new NotImplementedException();
        }


        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Zero Coupon applicable at the input Maturity, based on the curve labeled as YCidentifier", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_ZC(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(@"[Optional: AsOfDate as double/date = Today]")][System.Runtime.InteropServices.Optional] double AsOfDate,
            [ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] string Currency,
            [ExcelArgument(@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE""]")][System.Runtime.InteropServices.Optional] string InterestMethod,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT_360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention,
            [ExcelArgument(@"[Optional: InterpolationMethod as String = ""linear""]")][System.Runtime.InteropServices.Optional] string InterpolMethod
            )
        {

            if (ExcelHelper.IsMissing(MaturityDate))
                throw new ArgumentNullException(@"MaturityDate", @"Argument cannot be null, expecting a double");
            else
            {
                if (MaturityDate == 0) return ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(YCTenors)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"YCTenors", @"Argument cannot be null, expecting an array");

            if (ExcelHelper.IsMissing(YCZC))
                throw new ArgumentNullException(@"YCZC", @"Argument cannot be null, expecting an array");

            List<dynamic> TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            List<dynamic> ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();

            Dictionary<double, double> curvePoints = new Dictionary<double, double>();
            for (int i = 0; i < TenorList.Count; i++)
            {
                if (!ExcelHelper.IsMissing(TenorList[i]) && !ExcelHelper.IsMissing(ZCList[i]))
                    curvePoints.Add(TenorList[i], ZCList[i]);
            }

            //Dictionary<double, double> curvePoints = TenorList.Cast<double>().Zip(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value);



            Curve YC = new Curve(curvePoints);

            if (YC == null)
                return ExcelError.ExcelErrorNA;

            if (!ExcelHelper.IsMissing(AsOfDate) && AsOfDate != 0)
                YC.AsOfDate = AsOfDate;

            YC.Currency = Currency;

            if (Enum.TryParse(InterestMethod, out InterestMethodType interestMethod))
                YC.InterestMethod = interestMethod;

            if (Enum.TryParse(DayCountConvention, out DayCountConventionType dayCountConvention))
                YC.DayCountConvention = dayCountConvention;

            if (Enum.TryParse(InterpolMethod, out InterpolationMethodType interpolationMethod))
                YC.InterpolationMethod = interpolationMethod;

            return ExcelHelper.CheckNaN(YC.ZeroCoupon(MaturityDate));

            //cache is needed here
            //throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Discount Factor applicable at the input Maturity, based on the curve labeled as YCidentifier", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_DF(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(@"[Optional: AsOfDate as double/date = Today]")][System.Runtime.InteropServices.Optional] double AsOfDate,
            [ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] string Currency,
            [ExcelArgument(@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE""]")][System.Runtime.InteropServices.Optional] string InterestMethod,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT_360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention,
            [ExcelArgument(@"[Optional: InterpolationMethod as String = ""linear""]")][System.Runtime.InteropServices.Optional] string InterpolMethod
            )
        {

            if (ExcelHelper.IsMissing(MaturityDate))
                throw new ArgumentNullException(@"MaturityDate", @"Argument cannot be null, expecting a double");
            else
            {
                if (MaturityDate == 0) return ExcelError.ExcelErrorNull;
            }

            if (ExcelHelper.IsMissing(YCTenors)) //InpX.GetType() == typeof(ExcelMissing)
                throw new ArgumentNullException(@"YCTenors", @"Argument cannot be null, expecting an array");

            if (ExcelHelper.IsMissing(YCZC))
                throw new ArgumentNullException(@"YCZC", @"Argument cannot be null, expecting an array");

            List<dynamic> TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            List<dynamic> ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();

            Dictionary<double, double> curvePoints = new Dictionary<double, double>();
            for (int i = 0; i < TenorList.Count; i++)
            {
                if (!ExcelHelper.IsMissing(TenorList[i]) && !ExcelHelper.IsMissing(ZCList[i]))
                    curvePoints.Add(TenorList[i], ZCList[i]);
            }

            //Dictionary<double, double> curvePoints = TenorList.Cast<double>().Zip(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value);


            Curve YC = new Curve(curvePoints);

            if (YC == null)
                return ExcelError.ExcelErrorNA;

            if (!ExcelHelper.IsMissing(AsOfDate) && AsOfDate != 0)
                YC.AsOfDate = AsOfDate;

            YC.Currency = Currency;

            if (Enum.TryParse(InterestMethod, out InterestMethodType interestMethod))
                YC.InterestMethod = interestMethod;

            if (Enum.TryParse(DayCountConvention, out DayCountConventionType dayCountConvention))
                YC.DayCountConvention = dayCountConvention;

            if (Enum.TryParse(InterpolMethod, out InterpolationMethodType interpolationMethod))
                YC.InterpolationMethod = interpolationMethod;

            return ExcelHelper.CheckNaN(YC.DiscountFactor(MaturityDate));

            //cache is needed here
            //throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Year Fraction between two dates.", HelpTopic = @"https://en.wikipedia.org/wiki/Day_count_convention", IsThreadSafe = true)]
        public static object SCOR_YF(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object StartDate,
            [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object EndDate,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] object DayCountConvention
            )
        {
            double startDate, endDate;
            if (ExcelHelper.IsMissing(StartDate))
                throw new ArgumentNullException(@"StartDate", @"Argument cannot be null, expecting an array");
            else
            {
                //if (StartDate == 0) return ExcelError.ExcelErrorNull; //with StartDate defined as a double
                if (!double.TryParse(StartDate.ToString(), out startDate))
                    throw new ArgumentNullException();
            }


            if (ExcelHelper.IsMissing(EndDate))
                throw new ArgumentNullException(@"EndDate", @"Argument cannot be null, expecting an array");
            else
            {
                //if (EndDate == 0) return ExcelError.ExcelErrorNull;
                if (!double.TryParse(EndDate.ToString(), out endDate))
                    throw new ArgumentNullException();
            }

            DayCountConventionType dayCountConvention;
            if (ExcelHelper.IsMissing(DayCountConvention))
                dayCountConvention = DayCountConventionType.ACT_360;
            else
            {
                if (!Enum.TryParse(DayCountConvention.ToString(), out dayCountConvention))
                    throw new ArgumentNullException();
                    //return ExcelError.ExcelErrorValue;
            }

            return ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate,endDate,dayCountConvention));
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the date corresponding to the Tenor.", HelpTopic = @"https://en.wikipedia.org/wiki/Day_count_convention", IsThreadSafe = true)]
        public static object SCOR_TENORDATE(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object Tenor,
            [ExcelArgument(@"[Optional] EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")][System.Runtime.InteropServices.Optional] object ReferenceDate,
            [ExcelArgument(@"[Optional] EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")][System.Runtime.InteropServices.Optional] object BusinessDayConvention
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention
            )
        {

            string tenor;
            if (ExcelHelper.IsMissing(Tenor))
                return ExcelError.ExcelErrorNA;
            else
                tenor = Tenor.ToString();


            DateTime refDate;
            if (ExcelHelper.IsMissing(ReferenceDate))
                refDate = DateTime.Today;
            else
                if(double.TryParse(ReferenceDate.ToString(), out double myRefDate))
                    refDate = DateTime.FromOADate(myRefDate);
                else
                    return ExcelError.ExcelErrorNA;

            if (!ExcelHelper.IsMissing(BusinessDayConvention))
                if(Enum.TryParse(BusinessDayConvention.ToString(), out BusinessDayConventionType businessDayConvention))
                    return DateHelper.AddTenor(refDate, tenor, businessDayConvention);

            return DateHelper.AddTenor(refDate, tenor);
        }
/*
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Price, Accrued Interest, Yield to Maturity, Duration and Convexity for a bond specified with the input parameters. Output is an array of 5 elements Array(Price, Accrued Interest, Yield, Duration, Convexity)", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_(finance)", IsThreadSafe = true)]
        public static double[] SCOR_BONDPRICING([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                                  [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                                  [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                                  [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                                  [ExcelArgument(@"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)")] double QuotedPrice,
                                  [ExcelArgument(@"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)")] double Yield,
                                  [ExcelArgument(@"[Optional] YCidentifier as String (Name of an existing curve)")] string YCidentifier)
        {
            double price = 0, accruedInterest = 0.1, yield = -100, duration = -1, convexity = -2;

            double[] output = new double[5];
            output[0] = price;
            output[1] = accruedInterest;
            output[2] = yield;
            output[3] = duration;
            output[4] = convexity;
            return output;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Yield to Maturity for a bond specified with the input parameters and a given Yield.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
        public static double SCOR_BONDYIELDTOPRICE([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                                  [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                                  [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                                  [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                                  [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield)
        {
            return 0;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Clean Price for a bond specified with the input parameters and a given Price.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
        public static double SCOR_BONDPRICETOYIELD([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                          [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                          [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                          [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                          [ExcelArgument(@"Price as Double (Clean Price, quoted in Percentage)")] double Price)
        {
            return 0;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Modified Duration for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_duration", IsThreadSafe = true)]
        public static double SCOR_BONDDURATION([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                          [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                          [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                          [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                          [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield)
        {
            return 0;
            throw new NotImplementedException();
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Convexity for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_convexity", IsThreadSafe = true)]
        public static double SCOR_BONDCONVEXITY([ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                          [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                          [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                          [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                          [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield)
        {
            return 0;
            throw new NotImplementedException();
        }
*/
    }
}
