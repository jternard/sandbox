﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;
using Microsoft.Office.Interop.Excel;

namespace SCOR_Utils_Addin
{
    internal static class ExcelHelper
    {
        internal static object CheckNaN(double value)
        {
            return (Double.IsNaN(value) || Double.IsInfinity(value)) ? ExcelError.ExcelErrorNA : (object)value;
        }

        internal static T CheckValue<T>(object value, T defaultValue) where T : struct
        {
            return (value is T) ? (T)value : defaultValue;
        }

        internal static bool IsMissing(object arg)
        {
            return (arg.GetType() == typeof(ExcelMissing) || arg.GetType() == typeof(ExcelEmpty) || arg.GetType() == typeof(ExcelError));
        }



        internal static Range CallingRange(ExcelReference xlref) //xlref will be "XlCall.xlfCaller" in the calling function
        {
            string refText = XlCall.Excel(XlCall.xlfReftext, xlref, true).ToString();
            dynamic app = ExcelDnaUtil.Application;
            return app?.Range[refText];
        }
    }
}
