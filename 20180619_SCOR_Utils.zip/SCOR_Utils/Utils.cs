﻿/*

To debug with Excel, go in Project Properties and Debug tab:
  - Set Start with External Program : "C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE"
  - Set Command Line Arguments: "C:\Users\U007018\source\repos\SCOR_Utils\SCOR_Utils\TestExcel.xlsm"
  - Set Enable Native Code Debugging
Register for COM interop has to be set to True
COM visible has to be set to True
Implement COM interface ([System.Runtime.InteropServices.ComVisible(true), System.Runtime.InteropServices.InterfaceType(System.Runtime.InteropServices.ComInterfaceType.InterfaceIsDual)])
Define classes implementing these COM interfaces  ([ClassInterface(ClassInterfaceType.None)])
Set the Build/Publish to 64 bit, or the ActiveX component will not be correctly registered (probably need to manually regasm, regsvr32 using the 32 bit version located in C:\Windows\SYSWOW64\)
https://www.red-gate.com/simple-talk/dotnet/visual-studio/build-and-deploy-a-net-com-assembly/
The Setup and Deploy project can be found on the Extension store (blocked by IT), the package is available locally at G:\Global SP&I\Jeremy Ternard Workbench\InstallerProjects.vsix
certificates: https://social.technet.microsoft.com/Forums/sharepoint/en-US/3dd3472a-dac0-4016-980c-9c16a06dcc33/issue-certificate-from-ca-server?forum=winserversecurity
certificates: http://www.entrust.net/knowledge-base/technote.cfm?tn=8924
certificates: https://www.ssl.com/how-to/combine-a-private-key-with-p7b-certificate-how-to-create-a-pfx-file/
sign the exe, not the msi: (from the msi/exe output folders) "SignTool sign /f ..\..\certificate\SCOR_Utils_Setup_jternard_20180608_chained.pfx /p jternard SCOR_Utils_Setup.msi"

problem with installing with "another version...": https://stackoverflow.com/questions/15234879/handle-another-version-of-this-product-is-already-installed-installation-of-th
problem with BadImageFormatException (installer -> 64 bits, dll -> any CPU): https://social.msdn.microsoft.com/Forums/windows/en-US/738586b8-00fb-4374-9571-982ca66da091/error-1001-could-not-load-file-or-assembly-built-by-an-assembly-newer-than-the-currently?forum=winformssetup

Make functions available within Excel as Formulas: https://www.codeproject.com/Articles/7753/Create-an-Automation-Add-In-for-Excel-using-NET 
 and https://blogs.msdn.microsoft.com/gabhan_berry/2008/04/07/writing-custom-excel-worksheet-functions-in-c/
 and https://code.msdn.microsoft.com/office/VBExcelAutomationAddIn-cbf24c4b

Intellisense in Excel:
    http://dailydoseofexcel.com/archives/2015/03/21/formula-arguments-and-intellisense/ (placeholders for functions (native and UDF) are set by pressing CTRL+SHIFT+A)
    https://github.com/Excel-DNA/IntelliSense/wiki/Usage-Instructions
 
Quant libs:
    Math.NET with license to put in the software: https://numerics.mathdotnet.com/License.html
     
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;

namespace SCOR_Utils
{
    [ClassInterface(ClassInterfaceType.None)]
    [Guid("595E90F3-1DCA-4930-9C54-1394E32B5231")]
    //[ProgId("SCOR_Utils.Utils")]
    public class Utils : IUtils
    {
        //public double Interpolate(object XValues, object YValues, double Xinput, string interpolationMethod = "linear")
        public double Interpolate(object XValues, object YValues, double Xinput, InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR)
        {
            double Youtput = 0;

            //Transform input Excel Arrays into List / Dictionary
            //Clean data where there is no value

            List<dynamic> XList = (XValues.GetType().IsCOMObject ? (Array)((Range)XValues).Value2 : (Array)XValues).Cast<object>().ToList();
            List<dynamic> YList = (YValues.GetType().IsCOMObject ? (Array)((Range)YValues).Value2 : (Array)YValues).Cast<object>().ToList();
            
            if (XList.Count == YList.Count)
            {

                SortedDictionary<double, double> inputDictionary = new SortedDictionary<double, double>();

                for (int i = 0; i< XList.Count; i++)
                {
                    double tmpX, tmpY;

                    if (XList[i] != null && YList[i] != null)
                    {
                        tmpX = Convert.ToDouble(XList[i]);
                        tmpY = Convert.ToDouble(YList[i]);

                        if (!inputDictionary.ContainsKey(tmpX))
                        {
                            inputDictionary.Add(tmpX, tmpY);
                        }
                    }
                }

                XList = null;
                YList = null;


                //if at least one pair of X and Y are not empty, call the specialized functions
                if (inputDictionary.Count != 0)
                {
                    if (inputDictionary.ContainsKey(Xinput))
                    {
                        inputDictionary.TryGetValue(Xinput, out Youtput);
                    }
                    else
                    {
                        switch (interpolationMethod)
                        {
                            case InterpolationMethodType.LINEAR:
                                Youtput = InterpolateLinear(inputDictionary, Xinput);
                                break;
                            case InterpolationMethodType.NATURAL_CUBIC_SPLINE:
                                Youtput = InterpolateNaturalCubicSpline(inputDictionary, Xinput);
                                break;
                            default:
                                throw new NotImplementedException();
                        }
                        //switch (interpolationMethod.ToLower().Trim())
                        //{
                        //case "linear":
                        //    Youtput = InterpolateLinear(inputDictionary, Xinput);
                        //    break;
                        //case "cubic spline":
                        //case "natural cubic spline":
                        //case "spline":
                        //    Youtput = InterpolateNaturalCubicSpline(inputDictionary, Xinput);
                        //    break;
                        //}
                    }
                    inputDictionary = null;
                }
            }
            
            return Youtput;
        }

        public double Interpolate(Dictionary<double,double> keyValuePairs, double Xinput, InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR)
        {
            return Interpolate(keyValuePairs.Keys.ToArray(), keyValuePairs.Values.ToArray(), Xinput, interpolationMethod);
        }

        public double InterpolateLinear(SortedDictionary<double,double> inputDictionary, double Xinput)
        {
            double Youtput = 0;

            if (inputDictionary.Count != 0)
            {
                //if one of the known points, or Xinput is inferior to lower key or higher key
                if (inputDictionary.ContainsKey(Xinput))
                    Youtput = inputDictionary[Xinput];
                else if (Xinput < inputDictionary.ElementAt(0).Key)
                    Youtput = inputDictionary.ElementAt(0).Value;
                else if (Xinput > inputDictionary.ElementAt(inputDictionary.Count-1).Key)
                    Youtput = inputDictionary.ElementAt(inputDictionary.Count-1).Value;
                else
                //interpolation is actually needed
                {
                    //find the surrounding elements
                    KeyValuePair<double, double> prevElement, nextElement;
                    prevElement = inputDictionary.Last(a => a.Key <= Xinput);
                    nextElement = inputDictionary.First(a => a.Key >= Xinput);
                    Youtput = prevElement.Value + (nextElement.Value - prevElement.Value) * (Xinput - prevElement.Key) / (nextElement.Key - prevElement.Key);
                }
            }

            return Youtput;
        }

        public double InterpolateNaturalCubicSpline(SortedDictionary<double, double> inputDictionary, double Xinput, double[][] splineCoefficients = default(double[][]))
        {

            double[] XValues = inputDictionary.Keys.ToArray<double>();
            double[] YValues = inputDictionary.Values.ToArray<double>();

            double Youtput = 0;
            
            if(splineCoefficients==null) splineCoefficients = NaturalCubicSplineCalibration(XValues,YValues);//

            int n = XValues.Length - 1;
            int index = 0;

            if (Xinput >= inputDictionary.ElementAt(inputDictionary.Count - 1).Key)
                index = n-1;
            else
            { 
                while (XValues[index + 1] <= Xinput)
                {
                    index++;
                }
            }

            double deltaX = Xinput - XValues[index];

            //Youtput = YValues[index] + b[index] * (deltaX) + c[index] * Math.Pow(deltaX, 2) + d[index] * Math.Pow(deltaX, 3);
            Youtput = splineCoefficients[0][index] + splineCoefficients[1][index] * (deltaX) + splineCoefficients[2][index] * Math.Pow(deltaX, 2) + splineCoefficients[3][index] * Math.Pow(deltaX, 3);
            return Youtput;
        }

        public double[][] NaturalCubicSplineCalibration(double[] inpX, double[] inpY)
        {
            int n = inpX.Length - 1;
            double[] h = new double[n];

            for (int i = 0; i < n; i++)
            {
                h[i] = inpX[i + 1] - inpX[i];
            }

            double[] alpha = new double[n];

            for (int i = 1; i < n; i++)
            {
                alpha[i] = 3 / h[i] * (inpY[i + 1] - inpY[i]) - 3 / h[i - 1] * (inpY[i] - inpY[i - 1]);
            }

            double[] l = new double[n + 1];
            double[] mu = new double[n + 1];
            double[] z = new double[n + 1];

            l[0] = 1;
            mu[0] = 0;
            z[0] = 0;

            for (int i = 1; i < n; i++)
            {
                l[i] = 2 * (inpX[i + 1] - inpX[i - 1]) - h[i - 1] * mu[i - 1];
                mu[i] = h[i] / l[i];
                z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i];
            }

            double[] b = new double[n];
            double[] c = new double[n + 1];
            double[] d = new double[n];

            l[n] = 1;
            z[n] = 0;
            c[n] = 0;

            for (int i = n - 1; i >= 0; i--)
            {
                c[i] = z[i] - mu[i] * c[i + 1];
                b[i] = (inpY[i + 1] - inpY[i]) / h[i] - h[i] * (c[i + 1] + 2 * c[i]) / 3;
                d[i] = (c[i + 1] - c[i]) / (3 * h[i]);
            }

            double[][] output = new double[4][];
            output[0] = inpY;
            output[1] = b;
            output[2] = c;
            output[3] = d;
            return output;
        }
    }
}