﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public enum DayCountConventionType
    {
        ACT_360,
        ACT_365,
        ACT_ACT,
        //30_360,
    }

    public enum TenorPeriodType
    {
        D = 1,
        W = 7,
        M = 30,
        Q = 90,
        Y = 360
    }

    public enum InterestMethodType
    {
        BULLET,
        COMPOUNDING_DISCRETE,
        COMPOUNDING_CONTINUOUS
    }

    public enum InterpolationMethodType
    {
        LINEAR,
        NATURAL_CUBIC_SPLINE
    }

    public enum BusinessDayConventionType
    {
        FOLLOWING,
        MODIFIED_FOLLOWING,
        PRECEDING,
        MODIFIED_PRECEDING,
        NONE
    }


    //public class Enums
    //{
    //}
}
