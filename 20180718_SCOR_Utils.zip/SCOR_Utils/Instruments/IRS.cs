﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public class IRS : Instrument
    {
        public double SwapRate
        {
            get => _rate;
            set => _rate = value;
        }

        public IRS(MyDates maturityDate) : base(maturityDate)
        {
            PaymentFrequency = 12;
            InstrumentType = InstrumentType.IRS;
            QuotationType = QuotationType.RATE;
            Identifier += @" (IRS)";
        }

        public IRS(string maturityTenor) : base(maturityTenor)
        {
            PaymentFrequency = 12;
            InstrumentType = InstrumentType.IRS;
            QuotationType = QuotationType.RATE;
            Identifier += @" (IRS)";
        }

        public IRS(MyDates maturityDate, DateTime asOfDate) : base(maturityDate, asOfDate)
        {
            PaymentFrequency = 12;
            InstrumentType = InstrumentType.IRS;
            QuotationType = QuotationType.RATE;
            Identifier += @" (IRS)";
        }

        public override void GenerateSchedule()
        {
            //if (ParentCurve != null)
            //{
            MyDates couponEndDate = MaturityDate;
            MyDates couponStartDate;

            int nbPeriod = 0;
            Schedule schedule;

            if (PaymentFrequency == 0)
            {
                couponStartDate = StartDate;
                schedule = new Schedule(this)
                {
                    StartDate = couponStartDate,
                    EndDate = couponEndDate,
                    SettlementDate = couponEndDate,
                    Rate = MarketPrice
                };

                _schedule.Add(schedule);
            }
            //generating the coupon periods
            else
            {
                while (couponEndDate > StartDate)
                    {
                        couponStartDate = couponEndDate.GetDate().AddMonths(-PaymentFrequency);

                        schedule = new Schedule(this)
                        {
                            StartDate = couponStartDate,
                            EndDate = couponEndDate,
                            SettlementDate = couponEndDate,
                            Rate = MarketPrice
                        };

                        _schedule.Add(schedule);
                        nbPeriod++;
                        couponEndDate = MaturityDate.GetDate().AddMonths(-nbPeriod * PaymentFrequency);
                    }
                _schedule.Sort();
            }
        }

        public override double MarketPrice
        {
            get => _marketPrice != 0 ? _marketPrice : SwapRate;            
            set => _marketPrice = value;
        }
    }
}
