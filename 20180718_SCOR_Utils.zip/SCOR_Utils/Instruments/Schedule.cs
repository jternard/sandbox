﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public class Schedule : IComparable
    {
        public MyDates StartDate = new MyDates();
        public MyDates EndDate = new MyDates();

        public Instrument ParentInstrument;

        //if settlement is set, return it, else retrieve the EndDate
        private MyDates _settlementDate;        
        public MyDates SettlementDate
        {
            get => _settlementDate ?? EndDate;
            set => _settlementDate = value;
        }


        public string Currency;
        public double Rate;

        //if _cashflow is set, return it, else compute it based on the period YF and the rate to be applied
        private double _cashflow;
        public double CashFlow
        {
            get
            {
                double output = _cashflow;
                if (_cashflow == 0)
                {
                    double yf = DateHelper.YearFraction(StartDate, EndDate);
                    output = yf * Rate;
                }
                return output;
            }
            set { _cashflow = value; }
        }

        public double DiscountedCashFlow => CashFlow * SettlementDF;

        public double StartDF
        {
            get => ParentInstrument?.ParentCurve?.DiscountFactor(StartDate) ?? 1;
        }

        public double EndDF
        {
            get => ParentInstrument?.ParentCurve?.DiscountFactor(EndDate) ?? 1;
        }

        public double SettlementDF
        {
            get => ParentInstrument?.ParentCurve?.DiscountFactor(SettlementDate) ?? 1;
        }

        public double StartZC
        {
            get => ParentInstrument?.ParentCurve?.ZeroCoupon(StartDate) ?? 0;
        }

        public double EndZC
        {
            get => ParentInstrument?.ParentCurve?.ZeroCoupon(EndDate) ?? 0;
        }

        public double SettlementZC
        {
            get => ParentInstrument?.ParentCurve?.ZeroCoupon(SettlementDate) ?? 0;
        }

        public Schedule() { }
        public Schedule(Instrument instr) => ParentInstrument = instr;

        public int CompareTo(object obj)
        {
            try
            {
                return SettlementDate.CompareTo(((Schedule)obj).SettlementDate);
            }
            catch
            {
                return 1;
            }
        }
    }
}
