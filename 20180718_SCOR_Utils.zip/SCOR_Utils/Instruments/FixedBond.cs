﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    The FixedBond represents a Plain Vanilla Bond. It is used to create a Bond for pricing purposes, or for the calibration of a FIXED_INCOME type of curve.
    The Market Price represents the Clean Price by default, and can be changed to Dirty Price by changing the field QuotationType.
    The Curve is used only if the MarketPrice AND YTM are not set.
*/
namespace SCOR_Utils
{
    public class FixedBond : Instrument
    {
        //_rate is a field from the Instrument and available for all Instruments. CouponRate is a specialized name for Bonds, but is inherently the same as the SwapRate for instance.
        //CouponRate is a double, e.g. 2% is represented as 0.02
        public double CouponRate
        {
          get => _rate;
          set => _rate = value;
        }

        //RepaymentNominal represents the Principal paid back at maturity.
        //RepaymentNominal is a double, e.g. a repayment nominal of 105 as can be seen on Bloomberg actually represents 105%, and should be set as 1.05
        public double RepaymentNominal { get; set; } = 1;


        //If YTM is not set, it can be obtained either by computing the YTM matching the MarketPrice or by using the Curve to discount the future cashflows
        protected internal double _ytm;
        public double YTM
        {
            get
            {
                try
                {
                    //if(QuotationType != QuotationType.YTM)
                        if (_ytm == 0)
                            if (_marketPrice != 0)
                                _ytm = PriceToYield(MarketPrice);
                            //if neither ytm and marketprice are not filled, try to use the curve to price the bond
                            else
                            {
                                _marketPrice = Pricing(out _modifiedDuration, out _convexity, out _ytm);
                                if (QuotationType == QuotationType.PERCENT_CLEAN) _marketPrice -= AccruedInterest();
                            }
                }
                catch
                {
                }
                return _ytm;
            }

            set => _ytm = value;
        }

        //If MarketPrice is not set, it can be obtained either by discounting all the future cashflows by using the YTM (if provided), or retrieving the Discount Factors from the ParentCurve
        public override double MarketPrice
        {
            get
            {
                try
                {
                    if (_marketPrice == 0)
                    {
                        if (_ytm != 0)
                            //Pricing returns the NPV. Since there is no nominal, this NPV is also the dirty price of the bond
                            //if the quotation is percent clean, the accrued interest needs to be removed from it
                            _marketPrice = Pricing(_ytm, out _modifiedDuration, out _convexity);
                        else
                            //if market price and ytm are empty, this means there is no information on the pricing
                            //if the bond has a yield curve, it can be priced anyway
                            _marketPrice = Pricing(out _modifiedDuration, out _convexity, out _ytm);

                        if (QuotationType == QuotationType.PERCENT_CLEAN) _marketPrice -= AccruedInterest();
                    }
                }
                catch
                {
                }
                return _marketPrice;
            }
            set => _marketPrice = value;
        }

        //ModifiedDuration is obtained when computing the YTM, or the MarketPrice
        private double _modifiedDuration;
        public double ModifiedDuration
        {
            //get
            //{
            //    double tmp;
            //    try
            //    {
            //        if (_modifiedDuration == 0)
            //            tmp = Pricing(YTM, out _modifiedDuration, out _convexity);
            //            //if (_ytm != 0)
            //            //    _marketPrice = Pricing(_ytm, out _modifiedDuration, out _convexity);
            //            //else
            //            //{
            //            //    if(_marketPrice == 0)
            //            //        _marketPrice = Pricing(out _modifiedDuration, out _convexity, out _ytm);
            //            //    else
            //            //    {
            //            //        _ytm = PriceToYield(MarketPrice);

            //            //    }
            //            //}

            //    }
            //    catch
            //    {
            //    }
            //    return _modifiedDuration;
            //}
            get => _modifiedDuration;
            //set => _modifiedDuration = value;
        }

        //Convexity is obtained when computing the YTM, or the MarketPrice
        private double _convexity;
        public double Convexity
        {
            //get
            //{
            //    try
            //    {
            //        if (_convexity == 0)
            //            if (_ytm != 0)
            //                _marketPrice = Pricing(_ytm, out _modifiedDuration, out _convexity);
            //    }
            //    catch
            //    {
            //    }
            //    return _convexity;
            //}
            get => _convexity;
            //set => _convexity = value;
        }


        //For all Bonds, the last period flow is the Repayment of Nominal
        //As Bonds are not completely defined, the schedule generation simply goes from Maturity to AsOfDate by creating a CouponPeriod for each period
        //Bonds with CouponRate == 0 will have all of their intermediate periods generated with a flow of 0
        //Bonds with CouponFrequency == 0, or the period to Maturity shorter than the CouponFrequency will be considered as ZeroCoupons
        public override void GenerateSchedule()
        {
            MyDates couponEndDate = MaturityDate;
            MyDates couponStartDate;
            

            int nbPeriod = 0;

            //At maturity, the principal gets repaid
            Schedule schedule = new Schedule(this)
            {
                EndDate = MaturityDate,
                SettlementDate = MaturityDate,
                CashFlow = RepaymentNominal,
                StartDate = MaturityDate
            };
            _schedule.Add(schedule);

            if (PaymentFrequency == 0)
            {
                couponStartDate = StartDate;
                schedule = new Schedule(this)
                {
                    StartDate = couponStartDate,
                    EndDate = couponEndDate,
                    SettlementDate = couponEndDate,
                    Rate = CouponRate
                };

                _schedule.Add(schedule);
            }
            //generating the coupon periods
            else
            {                
                while (couponEndDate > StartDate)
                {
                    couponStartDate = couponEndDate.GetDate().AddMonths(-PaymentFrequency);

                    schedule = new Schedule(this)
                    {
                        StartDate = couponStartDate,
                        EndDate = couponEndDate,
                        SettlementDate = couponEndDate,
                        Rate = CouponRate
                    };

                    _schedule.Add(schedule);
                    nbPeriod++;
                    couponEndDate = MaturityDate.GetDate().AddMonths(-nbPeriod * PaymentFrequency);
                }
                _schedule.Sort();
            }
            
        }

        //Determination of the Price based on the Yield. The Yield is used to discount all of the future cashflows.
        public virtual double YieldToPrice(double yield = 0)
        {
            if (yield == 0) yield = YTM;

            if (QuotationType == QuotationType.RATE)
                return yield;
            else
            {
                double price = Pricing(yield, out double modifiedDuration, out double convexity);
                
                switch (QuotationType)
                {
                    case QuotationType.PERCENT_CLEAN:
                        return (price - AccruedInterest()) * 100;
                    case QuotationType.PERCENT_DIRTY:
                        return price * 100;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
        }

        //Determination of the Yield based on the Price.
        //Newton-Raphson using Modified Duration as first order derivative of the function Price(YTM)
        public virtual double PriceToYield(double price = 0)
        {
            //if no input, retrieve the bond market price by default
            if (price == 0) price = MarketPrice;
            if (QuotationType == QuotationType.PERCENT_CLEAN) price += AccruedInterest();

            //if _ytm exists, start with it, else start with CouponRate (YTM = CouponRate under specific conditions, therefore a good starting point)
            double outYTM = CouponRate; //double outYTM = _ytm != 0 ? _ytm : CouponRate;

            //Newton-Raphson: the goal is to have tmpPrice corresponding to Price(outYTM) converge to the actual quoted or input price. tmpMD is modified duration used as first order derivative.
            double tmpPrice = Pricing(outYTM, out double tmpMD, out double tmpCVX);

            while (Math.Abs(price - tmpPrice) > 0.0000000001)
            {
                outYTM -= (price - tmpPrice) / tmpMD;
                tmpPrice = Pricing(outYTM, out tmpMD, out tmpCVX);
            }
            return outYTM;
        }

        //Outputs how much the price of the bond would shift by a modification of the YTM: deltaYTM -> deltaP
        public double PriceSensitivity(double deltaYTM)
        {
            double price = Pricing(YTM, out double modifiedDuration, out double convexity);
            return -modifiedDuration * deltaYTM + (0.5 * convexity * Math.Pow(deltaYTM, 2));
        }
            

        //UNTESTED
        public Schedule GetCurrentSchedule(MyDates myDate = null)
        {
            if (myDate is null) myDate = AsOfDate;
            return Schedule.Single(x => x.StartDate <= myDate && x.EndDate >= myDate);
        }

        public Schedule GetNextSchedule(MyDates myDate = null)
        {
            int schedIndex = Schedule.IndexOf(GetCurrentSchedule(myDate));
            if (schedIndex >= Schedule.Count - 1)
                return Schedule.Last();
            else
                return Schedule[schedIndex + 1];
        }

        public Schedule GetPreviousSchedule(MyDates myDate = null)
        {
            int schedIndex = Schedule.IndexOf(GetCurrentSchedule(myDate));
            if (schedIndex == 0)
                return Schedule.First();
            else
                return Schedule[schedIndex - 1];
        }

        //UNTESTED
        public double AccruedInterest(MyDates myDate = null)
        {
            if (myDate is null) myDate = AsOfDate;
            try
            {
                Schedule currentSchedule = GetCurrentSchedule(myDate);
                return DateHelper.YearFraction(currentSchedule.StartDate, myDate, DayCountConvention) * currentSchedule.Rate;
            }
            catch
            {
                return 0;
            }
        }

        //REPLACE BY LINQ?
        //public double AccruedInterest(DateTime asOfDate = default(DateTime))
        //{
        //    if (asOfDate == default(DateTime)) asOfDate = AsOfDate;

        //    foreach (Schedule schedule in Schedule)
        //        if(schedule.StartDate.GetDate() <= asOfDate && schedule.EndDate.GetDate() >= asOfDate)
        //            return DateHelper.YearFraction(schedule.StartDate.GetDate(), asOfDate) * schedule.Rate;

        //    throw new ArgumentOutOfRangeException();
        //}

        //public DateTime GetNextCouponDate(DateTime asOfDate = default(DateTime))
        //{
        //    if (asOfDate == default(DateTime)) asOfDate = AsOfDate;

        //    foreach (Schedule schedule in Schedule)
        //        if (schedule.StartDate.GetDate() <= asOfDate && schedule.EndDate.GetDate() >= asOfDate)
        //            return schedule.EndDate;

        //    throw new ArgumentOutOfRangeException();
        //}

        //public DateTime GetLastCouponDate(DateTime asOfDate = default(DateTime))
        //{
        //    if (asOfDate == default(DateTime)) asOfDate = AsOfDate;
        //    //List<Schedule> Schedule = GetSchedule();
        //    int i;
        //    for (i = 0; i < Schedule.Count; i++)
        //        if (Schedule[i].StartDate.GetDate() <= asOfDate && Schedule[i].EndDate.GetDate() >= asOfDate)
        //            break;

        //    if (i >= Schedule.Count)
        //        throw new ArgumentOutOfRangeException();

        //    if (i == 0)
        //        return Schedule[i].StartDate.GetDate();
        //    else
        //        return Schedule[i-1].EndDate.GetDate();
        //}



        /*
            NPV, modifiedDuration and convexity act as accumulator when looping through the schedule
            Attention, the NPV includes the accrued interest, therefore to get the theoretical clean price = NPV - AccruedInterest()
            CF_i = YF_i * RATE_i
            DF_i = POWER(1 + yield, -YF_i)   (i.e. this only handles annually compounded interest)
            NPV = SUM_i ( CF_i . DF_i )
            modifiedDuration = SUM_i ( CF_i . DF_i . YF_i ),      then divide by (NPV . (1 + yield))          https://en.wikipedia.org/wiki/Bond_duration
            convexity = SUM_i ( CF_i . DF_i . YF_i (YF_i + 1)),   then divide by (NPV . POWER(1 + yield, 2))  https://www.wallstreetmojo.com/convexity-of-a-bond-formula-duration/
        */
        public double Pricing(double yield, out double modifiedDuration, out double convexity)//, double price = 0, DateTime asOfDate = default(DateTime))
        {
            double NPV = 0;
            modifiedDuration = 0;
            convexity = 0;

            double yf;
            double cfdf;

            foreach (Schedule schedule in Schedule)
            {
                yf = DateHelper.YearFraction(AsOfDate, schedule.SettlementDate);
                cfdf = schedule.CashFlow * Math.Pow(1 + yield, -yf);

                NPV += cfdf;
                modifiedDuration += cfdf * yf;
                convexity += cfdf * yf * (yf + 1);
            }

            if (NPV == 0) throw new ArgumentNullException();

            modifiedDuration /= (NPV * (1 + yield));
            convexity /= (NPV * Math.Pow(1 + yield, 2));
            return NPV;
        }

        //similar but using the Parent Yield Curve if it exists
        public double Pricing(out double modifiedDuration, out double convexity, out double yield)
        {
            if (ParentCurve is null) throw new NullReferenceException();
            double NPV = 0;
            modifiedDuration = 0;
            convexity = 0;
            yield = 0;

            double yf;
            double cfdf;
            //double df;

            foreach (Schedule schedule in Schedule)
            {
                yf = DateHelper.YearFraction(AsOfDate, schedule.SettlementDate);
                cfdf = schedule.DiscountedCashFlow; //the schedule tries to get the parent curve of its linked instrument. Adding a Schedule line not linked to an instrument, itself not linked to a curve will not work

                NPV += cfdf;
                modifiedDuration += cfdf * yf;
                convexity += cfdf * yf * (yf + 1);
            }

            if (NPV == 0) throw new ArgumentNullException();

            yield = PriceToYield(QuotationType == QuotationType.PERCENT_CLEAN ? NPV - AccruedInterest() : NPV);
            modifiedDuration /= (NPV * (1 + yield));
            convexity /= (NPV * Math.Pow(1 + yield, 2));
            return NPV;
        }

        #region Constructors
        public FixedBond(MyDates maturityDate) : base(maturityDate)
        {
            InstrumentType = InstrumentType.BOND_FIXED;
            QuotationType = QuotationType.PERCENT_CLEAN;
            Identifier += @" (BOND)";
            PaymentFrequency = 12;
        }

        public FixedBond(string maturityTenor) : base(maturityTenor)
        {
            InstrumentType = InstrumentType.BOND_FIXED;
            QuotationType = QuotationType.PERCENT_CLEAN;
            Identifier += @" (BOND)";
            PaymentFrequency = 12;
        }


        public FixedBond(MyDates maturityDate, DateTime asOfDate) : base(maturityDate, asOfDate)
        {
            InstrumentType = InstrumentType.BOND_FIXED;
            QuotationType = QuotationType.PERCENT_CLEAN;
            Identifier += @" (BOND)";
            PaymentFrequency = 12;
        }
        #endregion
        #region DEPRECATED
        //public double ModifiedDuration(double yield = 0)
        //{
        //    double numerator = 0;
        //    double denominator = 0;
        //    foreach(Schedule schedule in GetSchedule())
        //    {
        //        double yf = DateHelper.YearFraction(AsOfDate, schedule.SettlementDate);
        //        numerator += schedule.CashFlow * yf * Math.Pow(1 + yield, -yf);
        //        denominator += schedule.CashFlow * Math.Pow(1 + yield, -yf);
        //    }
        //    return (numerator / denominator) / (1 + yield);
        //}

        //public double Convexity(double yield = 0)
        //{
        //    double numerator = 0;
        //    double denominator = 0;
        //    foreach (Schedule schedule in GetSchedule())
        //    {
        //        double yf = DateHelper.YearFraction(AsOfDate, schedule.SettlementDate);
        //        numerator += schedule.CashFlow * yf * (yf + 1) * Math.Pow(1 + yield, -yf); //- 2);
        //        denominator += schedule.CashFlow * Math.Pow(1 + yield, -yf);
        //    }
        //    return (numerator / denominator) / Math.Pow(1 + yield, 2) * 0.01;
        //}

        //public double PriceToYield(double price = 0)
        //{
        //    double outYTM = CouponRate;

        //    while (Math.Abs(price - YieldToPrice(outYTM)) > 0.000001)
        //        outYTM = outYTM - (price - YieldToPrice(outYTM)) / ModifiedDuration(outYTM);

        //    return outYTM;
        //}
        #endregion
    }
}