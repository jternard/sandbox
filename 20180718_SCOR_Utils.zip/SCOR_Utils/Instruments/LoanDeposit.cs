﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    class LoanDeposit : Instrument
    {
        public double Rate
        {
            get => _rate;
            set => _rate = value;
        }
        public LoanDeposit(MyDates maturityDate) : base(maturityDate)
        {
            PaymentFrequency = 0;
            InstrumentType = InstrumentType.LOAN_DEPOSIT;
            QuotationType = QuotationType.RATE;
            Identifier += @" (LOAN DEPOSIT)";
        }

        public LoanDeposit(string maturityTenor) : base(maturityTenor)
        {
            PaymentFrequency = 0;
            InstrumentType = InstrumentType.LOAN_DEPOSIT;
            QuotationType = QuotationType.RATE;
            Identifier += @" (LOAN DEPOSIT)";
        }

        public LoanDeposit(MyDates maturityDate, DateTime asOfDate) : base(maturityDate, asOfDate)
        {
            PaymentFrequency = 0;
            InstrumentType = InstrumentType.LOAN_DEPOSIT;
            QuotationType = QuotationType.RATE;
            Identifier += @" (LOAN DEPOSIT)";
        }

        public LoanDeposit(MyDates maturityDate, double ZC) : base(maturityDate, ZC)
        {
            PaymentFrequency = 0;
            InstrumentType = InstrumentType.LOAN_DEPOSIT;
            QuotationType = QuotationType.RATE;
            Identifier += @" (LOAN DEPOSIT)";
        }

        public LoanDeposit(string forwardTenor, string maturityTenor) : base(forwardTenor, maturityTenor)
        {
            PaymentFrequency = 0;
            InstrumentType = InstrumentType.LOAN_DEPOSIT;
            QuotationType = QuotationType.RATE;
            Identifier += @" (LOAN DEPOSIT)";
        }

    }
}
