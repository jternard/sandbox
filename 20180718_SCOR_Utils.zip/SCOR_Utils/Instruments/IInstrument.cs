﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public interface IInstrument
    {
        void GenerateSchedule();
        double DFToZC(double DF);
        double ZCToDF(double ZC);
    }
}
