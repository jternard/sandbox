﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

/*
DEPRECATED: this was used in the first iteration of the project as a COM compliant dll
To debug with Excel, go in Project Properties and Debug tab:
  - Set Start with External Program : "C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE"
  - Set Command Line Arguments: "C:\Users\U007018\source\repos\SCOR_Utils\SCOR_Utils\TestExcel.xlsm"
  - Set Enable Native Code Debugging
Register for COM interop has to be set to True
COM visible has to be set to True
Implement COM interface ([System.Runtime.InteropServices.ComVisible(true), System.Runtime.InteropServices.InterfaceType(System.Runtime.InteropServices.ComInterfaceType.InterfaceIsDual)])
Define classes implementing these COM interfaces ([ClassInterface(ClassInterfaceType.None)])
Set the Build/Publish to 64 bit, or the ActiveX component will not be correctly registered (probably need to manually regasm, regsvr32 using the 32 bit version located in C:\Windows\SYSWOW64\)
https://www.red-gate.com/simple-talk/dotnet/visual-studio/build-and-deploy-a-net-com-assembly/
The Setup and Deploy project can be found on the Extension store (blocked by IT), the package is available locally at G:\Global SP&I\Jeremy Ternard Workbench\InstallerProjects.vsix

problem with installing with "another version...": https://stackoverflow.com/questions/15234879/handle-another-version-of-this-product-is-already-installed-installation-of-th
problem with BadImageFormatException (installer -> 64 bits, dll -> any CPU): https://social.msdn.microsoft.com/Forums/windows/en-US/738586b8-00fb-4374-9571-982ca66da091/error-1001-could-not-load-file-or-assembly-built-by-an-assembly-newer-than-the-currently?forum=winformssetup

CERTIFICATES:
    https://social.technet.microsoft.com/Forums/sharepoint/en-US/3dd3472a-dac0-4016-980c-9c16a06dcc33/issue-certificate-from-ca-server?forum=winserversecurity
    http://www.entrust.net/knowledge-base/technote.cfm?tn=8924
    https://www.ssl.com/how-to/combine-a-private-key-with-p7b-certificate-how-to-create-a-pfx-file/
    Sign the MSI: (from the msi/exe output folders) "SignTool sign /f ..\..\certificate\SCOR_Utils_Setup_jternard_20180608_chained.pfx /p jternard SCOR_Utils_Setup.msi"
    OR sign the xll: "SignTool sign /f ..\..\..\certificate\SCOR_Utils_Setup_jternard_20180608_chained.pfx /p jternard SCOR_Utils_Addin-AddIn64-packed.xll"

Make functions available within Excel as Formulas
    https://www.codeproject.com/Articles/7753/Create-an-Automation-Add-In-for-Excel-using-NET 
    https://blogs.msdn.microsoft.com/gabhan_berry/2008/04/07/writing-custom-excel-worksheet-functions-in-c/
    https://code.msdn.microsoft.com/office/VBExcelAutomationAddIn-cbf24c4b

Intellisense in Excel:
    http://dailydoseofexcel.com/archives/2015/03/21/formula-arguments-and-intellisense/ (placeholders for functions (native and UDF) are set by pressing CTRL+SHIFT+A)
    https://github.com/Excel-DNA/IntelliSense/wiki/Usage-Instructions
 
Quant libs:
    Math.NET with license to put in the software: https://numerics.mathdotnet.com/License.html
*/

namespace SCOR_Utils
{
    //[ClassInterface(ClassInterfaceType.None)]
    //[Guid("5040C888-834E-47C6-B7FA-3E1B70ACA591")]
    public class Curve// : ICurve
    {
        public string Identifier;
        public string Currency;
        public CurveType CurveType = CurveType.MONEY_MARKET;
        public List<Instrument> Instruments = new List<Instrument>();
        public InterpolationMethodType InterpolationMethod { get; set; } = InterpolationMethodType.LINEAR;
        public InterestMethodType InterestMethod { get; set; } = InterestMethodType.BULLET;
        public DayCountConventionType DayCountConvention { get; set; } = DayCountConventionType.ACT_360;

        internal protected MyDates _settlementDate;
        public MyDates SettlementDate
        {
            get => _settlementDate ?? AsOfDate;            
            set => _settlementDate = value;
        }
        internal protected MyDates _asOfDate = new MyDates();
        public MyDates AsOfDate
        {
            get => _asOfDate;
            set
            {
                _asOfDate = value;
                //Need to also impact the instruments
                Instruments.ForEach(x => 
                {
                    x.MaturityDate.SetRefDate(_asOfDate);
                    x.StartDate.SetRefDate(_asOfDate);
                    x.AsOfDate = _asOfDate;
                });
            }
        }

        internal protected Interpolator _interpolator;
        //protected event EventHandler InterpolationMethodChange;
        //protected virtual void OnInterpolationMethodChange(EventArgs e)
        //{
        //    InterpolationMethodChange?.Invoke(this, e);
        //}

        public void AddInstrument(Instrument instrument)
        {
            if (instrument is null) throw new ArgumentNullException();
            //if the instrument is to be added in the list, override its dates to match the ones of the curve
            if (!Instruments.Contains(instrument))
            {
                instrument.MaturityDate.SetRefDate(AsOfDate);
                instrument.StartDate.SetRefDate(AsOfDate);
                instrument.AsOfDate = AsOfDate;
                instrument.ParentCurve = this;
                Instruments.Add(instrument);
            }
        }

        public void RemoveInstrument(Instrument instrument)
        {
            if (Instruments.Contains(instrument))
                Instruments.Remove(instrument);
        }

        public void ClearAll() => Instruments = new List<Instrument>();


        //WIP
        public void Calibrate() //set to protected internal?
        {
            //calibration only makes sense if there are instruments
            if (Instruments.Count != 0)
            {
                //TO HANDLE: CASE WHERE SOME INSTRUMENTS ARE CALIBRATED AND OTHERS ARE NOT
                //calibration is not needed if all the instruments already have Zero Coupons
                if(!Instruments.TrueForAll(x => x.ZeroCoupon != 0))
                {

                    //tmpCalibrationInstruments will hold the temporary instruments needed for calibration, as well as actual instruments
                    List<Instrument> tmpCalibrationInstruments = new List<Instrument>(Instruments);
                    #region pre-calibration
                    //TO HANDLE: CASE WHERE SOME INSTRUMENTS DO NOT HAVE A MARKET PRICE OR ZERO COUPON, JUST INTERPOLATE THE MARKET PRICE
                    //calibration only makes sense if the instruments have Market Prices
                    if (Instruments.TrueForAll(x => x.MarketPrice != 0))
                    {
                        //Step 1: retrieve the Schedule of all the Instruments and their maturity date
                        List<MyDates> scheduleDates = new List<MyDates>();
                        List<MyDates> maturityDates = new List<MyDates>();
                        foreach (Instrument instr in Instruments)
                        {
                            if (!maturityDates.Contains(instr.MaturityDate.GetDate())) maturityDates.Add(instr.MaturityDate.GetDate());
                            foreach (Schedule schedule in instr.Schedule)
                                if (!scheduleDates.Contains(schedule.SettlementDate.GetDate())) scheduleDates.Add(schedule.SettlementDate.GetDate());
                        }

                        if (scheduleDates.Count == 0) return;

                        //Step 2: comparison of settlement dates with actual instruments
                        //if a date doesn't appear in the list then a "shadow instrument needs to be added"

                        //Instrument tmpInstrument;

                        //Interpolation is Linear on Market Price
                        Interpolation.LinearInterpolation priceInterpolator = new Interpolation.LinearInterpolation(maturityDates.Select(x => (double)x), Instruments.Select(x => x.MarketPrice));

                        switch (CurveType)
                        {
                            case CurveType.FIXED_INCOME:
                                Interpolation.LinearInterpolation rateInterpolator = new Interpolation.LinearInterpolation(maturityDates.Select(x => (double)x), Instruments.Select(x => x._rate));
                                //Interpolation.LinearInterpolation YTMInterpolator = new Interpolation.LinearInterpolation(maturityDates.Select(x => (double)x), Instruments.Cast<FixedBond>().Select(x => x.YTM));
                                foreach (MyDates flowDate in scheduleDates)
                                    if (!maturityDates.Contains(flowDate))
                                        //tmpInstrument = new Instrument(flowDate, AsOfDate)
                                        tmpCalibrationInstruments.Add(
                                            new FixedBond(flowDate, AsOfDate)
                                            {
                                                DayCountConvention = this.DayCountConvention,
                                                InterestMethod = this.InterestMethod,
                                                Currency = this.Currency,
                                                Identifier = "temporary calibration instrument for date: " + flowDate,
                                                //YTM = YTMInterpolator.Interpolate((double)flowDate),
                                                MarketPrice = priceInterpolator.Interpolate((double)flowDate),
                                                CouponRate = rateInterpolator.Interpolate((double)flowDate)
                                            });
                                break;
                            case CurveType.MONEY_MARKET:
                                //Interpolation.LinearInterpolation priceInterpolator = new Interpolation.LinearInterpolation(maturityDates.Select(x => (double)x), Instruments.Select(x => x.MarketPrice));
                                foreach (MyDates flowDate in scheduleDates)
                                    if (!maturityDates.Contains(flowDate))
                                    {
                                        double swapRate = priceInterpolator.Interpolate((double)flowDate);
                                        tmpCalibrationInstruments.Add(
                                            new IRS(flowDate, AsOfDate)
                                            {
                                                DayCountConvention = this.DayCountConvention,
                                                InterestMethod = this.InterestMethod,
                                                Currency = this.Currency,
                                                Identifier = "temporary calibration instrument for date: " + flowDate,
                                                MarketPrice = swapRate,
                                                SwapRate = swapRate
                                            });
                                    }                                        
                                break;
                            default:
                                throw new NotImplementedException();
                        }
                        
                    }
                    #endregion

                    tmpCalibrationInstruments.Sort(); //instruments implement IComparable, they are sorted based on their ascending maturity
                    
                    #region calibration
                    Instrument tmpCalibrationInstrument;
                    Dictionary<DateTime, double> tmpCalibrationDF = new Dictionary<DateTime, double>();
                    //now that we have all the needed instruments, bootstrapping can be done on tmpCalibrationInstruments
                    for(int i = 0; i < tmpCalibrationInstruments.Count; i++)
                    {
                        tmpCalibrationInstrument = tmpCalibrationInstruments[i];
                        tmpCalibrationInstrument.Bootstrapping_DF(tmpCalibrationDF);
                        tmpCalibrationDF.Add(tmpCalibrationInstrument.MaturityDate, tmpCalibrationInstrument.DiscountFactor);
                    }
                    #endregion

                    #region post-calibration
                    //the actual instruments need to be put back into Instruments, discarding the temporary ones
                    foreach(Instrument tmpInstrument in tmpCalibrationInstruments)
                    {
                        if (Instruments.Contains(tmpInstrument))
                        {
                            RemoveInstrument(tmpInstrument);
                            AddInstrument(tmpInstrument);
                        }
                    }
                    #endregion
                }
            }
        }

        //if both input are null, the output will be 0 (difference between the same date = AsOfDate)
        public double YearFraction(MyDates endDate, MyDates startDate = null) => DateHelper.YearFraction(startDate ?? AsOfDate, endDate?? AsOfDate, DayCountConvention);        

        public double ZeroCoupon(MyDates myDate)
        {
            if (myDate is null) throw new ArgumentNullException();
            if (_interpolator is null)
            {
                IEnumerable<double> inpX = Instruments.Select(x => (double)x.MaturityDate);
                IEnumerable<double> inpY = Instruments.Select(x => x.ZeroCoupon);

                switch (InterpolationMethod)
                {
                    case InterpolationMethodType.LINEAR:
                        _interpolator = new Interpolation.LinearInterpolation(inpX, inpY);
                        break;
                    case InterpolationMethodType.NATURAL_CUBIC_SPLINE:
                        _interpolator = new Interpolation.NaturalCubicSplineInterpolation(inpX, inpY);
                        break;
                    default:
                        throw new NotImplementedException();
                }
            }
            return _interpolator.Interpolate((double)myDate);
        }

        public double DiscountFactor(MyDates myDate)
        {
            if (myDate is null) throw new ArgumentNullException();

            double outDF = 1;
            double ZC = ZeroCoupon(myDate);
            double YF = YearFraction(myDate, AsOfDate);

            if (myDate > AsOfDate)
            {
                switch (InterestMethod)
                {
                    case InterestMethodType.BULLET:
                        outDF = 1 / (1 + ZC * YF);
                        break;
                    case InterestMethodType.COMPOUNDING_DISCRETE:
                        outDF = Math.Pow(1 + ZC, -YF);
                        break;
                    case InterestMethodType.COMPOUNDING_CONTINUOUS:
                        outDF = Math.Exp(-ZC * YF);
                        break;
                    default:
                        throw new NotImplementedException();
                }
            }
            return outDF;
        }


        //https://en.wikipedia.org/wiki/Forward_rate
        //BULLET => Simple Rate
        //COMPOUNDING_DISCRETE => Yearly compounded rate
        //COMPOUNDING_CONTINUOUS => Continuously compounded rate
        public double ForwardRate(MyDates forwardStart, MyDates forwardEnd)
        {
            if (forwardStart is null || forwardEnd is null) throw new ArgumentNullException();
            if (forwardEnd <= forwardStart) throw new ArgumentOutOfRangeException();

            double outForward = 0;
            double dfStart = DiscountFactor(forwardStart);
            double dfEnd = DiscountFactor(forwardEnd);
            double YF = YearFraction(forwardEnd, forwardStart);

            double dfRatio = dfStart / dfEnd;

            //YF test is not needed as the check if forward end = forward start will throw an exception before
            switch (InterestMethod)
            {
                case InterestMethodType.BULLET:
                    outForward = (dfRatio - 1) / YF;
                    break;
                case InterestMethodType.COMPOUNDING_DISCRETE:
                    outForward = Math.Pow(dfRatio, 1 / YF) - 1;
                    break;
                case InterestMethodType.COMPOUNDING_CONTINUOUS:
                    outForward = Math.Log(dfRatio) / YF;
                    break;
                default:
                    throw new NotImplementedException();
            }

            return outForward;
        }

        #region Constructors
        public Curve() => Identifier = $"generated by initialization at {AsOfDate:d}";

        //expecting dates as key, and zero coupon as value
        public Curve(IDictionary<dynamic, double> inputDictionary)
        {
            if (inputDictionary is null) throw new ArgumentNullException();
            Instruments = new List<Instrument>(inputDictionary.Select(x => new Instrument(new MyDates(x.Key), x.Value)));
            Identifier = $"generated by initialization at {AsOfDate:d}";
        }

        //expecting dates for X, and ZC for Y
        public Curve(IEnumerable<dynamic> Dates, IEnumerable<double> ZeroCoupons)
        {
            if (Dates is null || ZeroCoupons is null) throw new ArgumentNullException();
            if (Dates.Count() != ZeroCoupons.Count()) throw new ArgumentOutOfRangeException();
            Instruments = new List<Instrument>(Dates.Zip(ZeroCoupons, (tenor, ZC) => new Instrument(new MyDates(tenor), ZC)));
            Identifier = $"generated by initialization at {AsOfDate:d}";
            //curvePoints = new SortedDictionary<double, double>(X.Zip(Y, (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value)); //This will crash if there are empty values
        }

        public Curve(IEnumerable<Instrument> instruments)
        {
            if (instruments is null) throw new ArgumentNullException();
            Instruments = instruments.ToList();
            Identifier = $"generated by initialization at {AsOfDate:d}";
        }
        #endregion

        #region deprecated
        //public double ZeroCoupon(double myDate)
        //{
        //    double outZC = 0;
        //    Utils utils = new Utils();
        //    if (utils != null)
        //    {
        //        switch (InterpolationMethod)
        //        {
        //            case InterpolationMethodType.LINEAR:
        //                outZC = utils.InterpolateLinear(new SortedDictionary<double, double>(curvePoints), myDate);
        //                break;
        //            case InterpolationMethodType.NATURAL_CUBIC_SPLINE:
        //                if (cubicSplineCoefficients == null)
        //                    cubicSplineCoefficients = utils.NaturalCubicSplineCalibration(curvePoints.Keys.ToArray(), curvePoints.Values.ToArray());
        //                outZC = utils.InterpolateNaturalCubicSpline(new SortedDictionary<double, double>(curvePoints), myDate, cubicSplineCoefficients);
        //                break;
        //            default:
        //                throw new NotImplementedException();
        //        }
        //    }
        //    else
        //        throw new NullReferenceException();
        //    utils = null;
        //    return outZC;
        //}

        //public object ZeroCoupon(object myDates)
        //{
        //    Array MyDates;
        //    if (myDates.GetType().IsArray)
        //    {
        //        MyDates = (myDates.GetType().IsCOMObject ? (Array)((Range)myDates).Value2 : (Array)myDates).Cast<double>().ToArray();
        //    }
        //    else
        //    {
        //        MyDates = new double[1];
        //        MyDates.SetValue(Convert.ToDouble(myDates), 0);
        //    }

        //    double[] outZC = new double[MyDates.Length];
        //    Utils utils = new Utils();

        //    switch (InterpolationMethod)
        //    {
        //        case InterpolationMethodType.LINEAR:
        //            for (int i = MyDates.GetLowerBound(0); i <= MyDates.GetUpperBound(0); i++)
        //            {
        //                outZC[i] = utils.InterpolateLinear(curvePoints, Convert.ToDouble(MyDates.GetValue(i)));
        //            }
        //            break;
        //        case InterpolationMethodType.NATURAL_CUBIC_SPLINE:
        //            if (cubicSplineCoefficients == null)
        //                cubicSplineCoefficients = utils.NaturalCubicSplineCalibration(curvePoints.Keys.ToArray(), curvePoints.Values.ToArray());
        //            for (int i = MyDates.GetLowerBound(0); i <= MyDates.GetUpperBound(0); i++)
        //            {
        //                outZC[i] = utils.InterpolateNaturalCubicSpline(curvePoints, Convert.ToDouble(MyDates.GetValue(i)), cubicSplineCoefficients); //would need to change the function not to recalibrate at each call
        //            }
        //            break;
        //        default:
        //            throw new NotImplementedException();
        //    }
        //    //if (interpolationMethod == "linear")
        //    //{
        //    //    for(int i = MyDates.GetLowerBound(0); i <= MyDates.GetUpperBound(0); i++)
        //    //    {
        //    //        outZC[i] = utils.InterpolateLinear(curvePoints, Convert.ToDouble(MyDates.GetValue(i)));
        //    //    }
        //    //}
        //    //else if(interpolationMethod.Contains("spline"))
        //    //{
        //    //    double[][] calibrationCoeff = utils.NaturalCubicSplineCalibration(curvePoints.Keys.ToArray(), curvePoints.Values.ToArray());
        //    //    for (int i = MyDates.GetLowerBound(0); i <= MyDates.GetUpperBound(0); i++)
        //    //    {
        //    //        outZC[i] = utils.InterpolateNaturalCubicSpline(curvePoints, Convert.ToDouble(MyDates.GetValue(i)), calibrationCoeff); //would need to change the function not to recalibrate at each call
        //    //    }
        //    //}

        //    utils = null;
        //    return outZC;
        //}

        //public double DiscountFactor(double myDate)
        //{
        //    double outDF = -1;
        //    double ZC = ZeroCoupon(myDate);
        //    double YF = YearFraction(myDate, (double)asOfDate);

        //    if (myDate < (double)asOfDate)
        //    {
        //        outDF = 1;
        //    }
        //    else
        //    {
        //        switch (InterestMethod)
        //        {
        //            case InterestMethodType.BULLET:
        //                outDF = 1 / (1 + ZC * YF);
        //                break;
        //            case InterestMethodType.COMPOUNDING_DISCRETE:
        //                outDF = Math.Pow(1 + ZC, -YF);
        //                break;
        //            case InterestMethodType.COMPOUNDING_CONTINUOUS:
        //                outDF = Math.Exp(-ZC * YF);
        //                break;
        //        }
        //    }
        //    return outDF;
        //}

        //public double ForwardRate(double forwardStart, double forwardEnd)
        //{

        //    double outForward = 0;
        //    double dfStart = DiscountFactor(forwardStart);
        //    double dfEnd = DiscountFactor(forwardEnd);
        //    double YF = YearFraction(forwardEnd, forwardStart);

        //    double dfRatio = dfStart / dfEnd;

        //    switch (InterestMethod)
        //    {
        //        case InterestMethodType.BULLET:
        //            outForward = (dfRatio - 1) / YF;
        //            break;
        //        case InterestMethodType.COMPOUNDING_DISCRETE:
        //            outForward = Math.Pow(dfRatio, 1 / YF) - 1;
        //            break;
        //        case InterestMethodType.COMPOUNDING_CONTINUOUS:
        //            outForward = Math.Log(dfRatio) / YF;
        //            break;
        //    }

        //    return outForward;
        //}

        //public void RemovePoint(double myDate)
        //{
        //    if (curvePoints.ContainsKey(myDate)) curvePoints.Remove(myDate);
        //}

        ////public void ClearAll()
        ////{
        ////    curvePoints = new SortedDictionary<double, double>();
        ////}

        //public void AddPoint(double inpX, double inpY)
        //{
        //    if (!curvePoints.ContainsKey(inpX)) curvePoints.Add(inpX, inpY);
        //}

        //public double[] ZeroCoupon(MyDates[] myDates)
        //{
        //    if (myDates == null) throw new ArgumentNullException();

        //    double[] output = new double[myDates.Length];
        //    for (int i = 0; i < myDates.Length; i++)
        //        output[i] = ZeroCoupon(myDates[i]);
        //    return output;
        //}


        #endregion
    }
}
