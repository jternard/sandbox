﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
To test some day count conventions: http://docs.fincad.com/support/developerfunc/mathref/Daycount.htm
validated on the two first examples
*/

namespace SCOR_Utils
{
    public static class DateHelper
    {
        public static DateTime Today => DateTime.Today;
        public static int NumberOfDays(DateTime startDate, DateTime endDate) => endDate.Subtract(startDate).Days;        
        public static double YearFraction(DateTime startDate, DateTime endDate, DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360)
        {
            if (DateTime.Equals(startDate, endDate)) return 0;
            int numDays;
            double basis = 360;

            switch (dayCountConvention)
            {
                case DayCountConventionType.ACT_360:
                    numDays = NumberOfDays(startDate, endDate);
                    break;
                case DayCountConventionType.ACT_365:
                    numDays = NumberOfDays(startDate, endDate);
                    basis = 365;
                    break;
                case DayCountConventionType.ACT_ACT:
                    return YF_ACT_ACT(startDate, endDate);
                case DayCountConventionType._30_360:
                    //If the first date of the accrual period falls on the 31st of the month, the date will be changed to the 30th.
                    //If the first date of the accrual period falls on the 30th of the month after applying (1) above, and the last date of the accrual period falls on the 31st of the month, the last date will be changed to the 30th.
                    if (startDate.Day == 31)
                    {
                        startDate = startDate.AddDays(-1);

                        if(endDate.Day == 31) endDate = endDate.AddDays(-1);
                    }
                    numDays = (endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDate.Day - startDate.Day);
                    break;
                case DayCountConventionType._30E_360:
                    if (startDate.Day == 31) startDate = startDate.AddDays(-1);
                    if (endDate.Day == 31) endDate = endDate.AddDays(-1);
                    numDays = (endDate.Year - startDate.Year) * 360 + (endDate.Month - startDate.Month) * 30 + (endDate.Day - startDate.Day);
                    break;
                default:
                    throw new NotImplementedException();
            }
            return numDays / basis;
        }

        public static double YF_ACT_ACT(DateTime startDate, DateTime endDate)
        {            
            int numDays;
            double basis = 0;
            DateTime tmpEndDate = new DateTime(startDate.Year, 12, 31);

            if(tmpEndDate < endDate)
            {
                numDays = NumberOfDays(startDate, tmpEndDate) + 1; //to account the 31.12.N to 01.01.N+1
                basis = DateTime.IsLeapYear(startDate.Year) ? 366 : 365;
                return numDays / basis + YF_ACT_ACT(tmpEndDate.AddDays(1), endDate);
            }
            else
            {
                numDays = NumberOfDays(startDate, endDate);
                basis = DateTime.IsLeapYear(endDate.Year) ? 366 : 365;
                return numDays / basis;
            }
        }        

        public static DateTime AddTenor(DateTime referenceDate, double numberPeriods, TenorPeriodType tenorPeriod = TenorPeriodType.Y, BusinessDayConventionType businessDayConvention = BusinessDayConventionType.FOLLOWING)
        {
            if (numberPeriods == 0) return referenceDate;

            DateTime output = referenceDate;
            int nbDays = 0, nbMonths = 0, nbYears = 0;
            try
            {
                switch (tenorPeriod)
                {
                    case TenorPeriodType.D:
                    case TenorPeriodType.W:
                        nbDays = (int)Math.Truncate(numberPeriods * (int)tenorPeriod);
                        break;
                    case TenorPeriodType.M:
                        nbMonths = (int)Math.Truncate(numberPeriods);
                        nbDays = (int)Math.Truncate((numberPeriods % nbMonths) * (int)tenorPeriod);
                        break;
                    case TenorPeriodType.Q:
                        nbMonths = (int)Math.Truncate(numberPeriods * 3); //2.17Q => 6.51M => 6M (0.17Q remaining)
                        nbDays = (int)Math.Truncate(((numberPeriods * 3) % nbMonths) * 30); //2.17Q => 6.51M => 6.51 modulo 6 yield 0.51, 0.51 * 30 gives the number of days on top of the 6 months
                        break;
                    case TenorPeriodType.Y:
                        nbYears = (int)Math.Truncate(numberPeriods); //1.4Y => 1Y (0.4Y remaining)
                        nbMonths = (int)Math.Truncate((numberPeriods % nbYears) * 12); //1.4Y => 1Y => 1.4 module 1 yield 0.4, 0.4 * 12 yields 4.8 => 4M (with 0.8M remaining) 
                        nbDays = (int)Math.Truncate((numberPeriods - nbYears - nbMonths / 12) * 360); //1.4Y - 1Y - (4M/12)Y yields 0.067Y, 0.067Y * 360 => 24 days
                        break;
                    default:
                        throw new NotImplementedException();
                }            

                output = referenceDate.AddYears(nbYears).AddMonths(nbMonths).AddDays(nbDays);
                int outputMonth = output.Month;

                if (output.DayOfWeek == DayOfWeek.Saturday || output.DayOfWeek == DayOfWeek.Sunday)
                {
                    switch (businessDayConvention)
                    {
                        case BusinessDayConventionType.NONE:
                            break;
                        case BusinessDayConventionType.FOLLOWING:
                            output = output.DayOfWeek == DayOfWeek.Sunday ? output.AddDays(1) : output.AddDays(2);
                            break;
                        case BusinessDayConventionType.MODIFIED_FOLLOWING:
                            output = output.DayOfWeek == DayOfWeek.Sunday ? output.AddDays(1) : output.AddDays(2); //MODIFIED should ensure that the new date is not in a different month, if it is the case then find the last/first open business day of the month
                            if(output.Month != outputMonth)
                                output = output.AddDays(-3); //going from a Monday to the previous Friday
                            break;
                        case BusinessDayConventionType.PRECEDING:
                            output = output.DayOfWeek == DayOfWeek.Sunday ? output.AddDays(-2) : output.AddDays(-1);
                            break;
                        case BusinessDayConventionType.MODIFIED_PRECEDING:
                            output = output.DayOfWeek == DayOfWeek.Sunday ? output.AddDays(-2) : output.AddDays(-1);
                            if (output.Month != outputMonth)
                                output = output.AddDays(3); //going from a Friday to the next Monday
                            break;
                        default:
                            throw new NotImplementedException();
                    }
                }
            }
            catch
            {
            }

            return output;
        }

        public static DateTime AddTenor(DateTime referenceDate, string tenor, BusinessDayConventionType businessDayConvention = BusinessDayConventionType.FOLLOWING)
        {
            if (tenor == String.Empty) return referenceDate;

            double numberPeriods = 0;
            TenorPeriodType tenorPeriod = TenorPeriodType.Y;

            //normal case
            if (tenor.Length >= 2 && Char.IsLetter(tenor.Last()))
            {
                Enum.TryParse(tenor.Last().ToString(),true, out tenorPeriod); //if this fails, tenorPeriod = Y
                double.TryParse(tenor.Substring(0, tenor.Length - 1), out numberPeriods); //if this fails, numberPeriods = 0
            }
            else            
                double.TryParse(tenor, out numberPeriods); //if (tenor length is 1 OR last character is not a string) and is convertible to a double, this will be a number of years, else numberPeriods = 0            

            return AddTenor(referenceDate, numberPeriods, tenorPeriod, businessDayConvention);
        }
    }
}
