﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils.InstrumentsREFACTOR
{
    public class Instrument : AbstractInstrument, IInstrument
    {
        public string Currency;        
        public InstrumentType InstrumentType { get; }
        public BusinessDayConventionType BusinessDayConvention = BusinessDayConventionType.FOLLOWING;
        public DayCountConventionType DayCountConvention = DayCountConventionType.ACT_360;
        public InterestMethodType InterestMethod = InterestMethodType.COMPOUNDING_DISCRETE;
        public Curve ParentCurve;
        public double YearFraction => DateHelper.YearFraction(AsOfDate, MaturityDate, DayCountConvention);
        public double NPV; //TODO

        protected internal List<Schedule> _schedule = new List<Schedule>();
        public List<Schedule> Schedule
        {
            get
            {
                if (_schedule.Count == 0)
                    GenerateSchedule();
                return _schedule;
            }
            set => _schedule = value;
        }

        public virtual void GenerateSchedule()
        {
            throw new NotImplementedException();
        }
    }
}
