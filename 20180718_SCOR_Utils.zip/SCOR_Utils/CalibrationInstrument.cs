﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils.InstrumentsREFACTOR
{
    class CalibrationInstrument : Instrument, ICalibrationInstrument
    {
        public QuotationType QuotationType = QuotationType.RATE;

        protected internal double _marketPrice;
        public virtual double MarketPrice
        {
            get => _marketPrice;
            set => _marketPrice = value;
        }

        protected internal double _discountFactor;
        public double DiscountFactor
        {
            get
            {
                if (_discountFactor == 0)
                    if (_zeroCoupon != 0)
                        _discountFactor = ZCToDF(_zeroCoupon);
                return _discountFactor;
            }
            set => _discountFactor = value;
        }

        protected internal double _zeroCoupon;
        public double ZeroCoupon
        {
            get
            {
                if (_zeroCoupon == 0)
                    if (_discountFactor != 0)
                        _zeroCoupon = DFToZC(_discountFactor);
                return _zeroCoupon;
            }
            set => _zeroCoupon = value;
        }

        public virtual void Bootstrapping_DF(IDictionary<MyDates, double> tmpCalibrationDF)
        {
            if (ZeroCoupon != 0) return; //an already calibrated instrument doesn't need to be recalibrated (in the current state of the curve)
            if (MaturityDate <= AsOfDate) //MaturityDate <= StartDate ||
                DiscountFactor = 1;
            else
                DiscountFactor = ZCToDF(MarketPrice);
        }

        public double ZCToDF(double ZC)
        {
            double outDF = 0;
            double YF = YearFraction;
            switch (InterestMethod)
            {
                case InterestMethodType.BULLET:
                    outDF = 1 / (1 + ZC * YF);
                    break;
                case InterestMethodType.COMPOUNDING_DISCRETE:
                    outDF = Math.Pow(1 + ZC, -YF);
                    break;
                case InterestMethodType.COMPOUNDING_CONTINUOUS:
                    outDF = Math.Exp(-ZC * YF);
                    break;
                default:
                    throw new NotImplementedException();
            }

            return outDF;
        }

        public double DFToZC(double DF)
        {
            double outZC = 0;
            double YF = YearFraction;

            //YF test is not needed as the check if forward end = forward start will throw an exception before
            switch (InterestMethod)
            {
                case InterestMethodType.BULLET:
                    outZC = (1 / DF - 1) / YF;
                    break;
                case InterestMethodType.COMPOUNDING_DISCRETE:
                    outZC = Math.Pow(1 / DF, 1 / YF) - 1;
                    break;
                case InterestMethodType.COMPOUNDING_CONTINUOUS:
                    outZC = -Math.Log(DF) / YF;
                    break;
                default:
                    throw new NotImplementedException();
            }

            return outZC;
        }
    }
}
