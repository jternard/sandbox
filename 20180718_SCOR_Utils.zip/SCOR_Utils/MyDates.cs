﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public class MyDates : IComparable
    {    
        internal protected DateTime _date;
        public DateTime GetDate() => (_date != default(DateTime)) ? _date : DateHelper.AddTenor(GetRefDate(), Tenor, BusinessDayConvention);
        public void SetDate(DateTime value) => _date = value;
        public void SetDate(double value) => _date = DateTime.FromOADate(value);

        internal protected DateTime _refDate = DateTime.Today;
        public DateTime GetRefDate() => _refDate;
        public void SetRefDate(DateTime value) => _refDate = value;
        public void SetRefDate(double value) => _refDate = DateTime.FromOADate(value);

        internal protected string _tenor = "";
        public string Tenor
        {
            get => _tenor;
            set => _tenor = value.Trim().ToUpper();
        }

        public BusinessDayConventionType BusinessDayConvention { get; set; } = BusinessDayConventionType.FOLLOWING;

        #region constructors
        public MyDates() { }
        public MyDates(DateTime inputDate) => SetDate(inputDate);
        public MyDates(double inputDateAsDouble) => SetDate(inputDateAsDouble);
        public MyDates(string inputTenor) => Tenor = inputTenor;
        public MyDates(string inputTenor, DateTime inputRefDate)
        {
            Tenor = inputTenor;
            SetRefDate(inputRefDate);
        }
        public MyDates(string inputTenor, double inputRefDateAsDouble)
        {
            Tenor = inputTenor.Trim().ToUpper();
            SetRefDate(DateTime.FromOADate(inputRefDateAsDouble));
        }
        #endregion

        #region conversions and casting
        public static explicit operator double(MyDates d) => d?.GetDate().ToOADate() ?? 0;      
        public static explicit operator MyDates(double d) => new MyDates(d);
        public static explicit operator string(MyDates d) => d?.GetDate().ToShortDateString() ?? string.Empty;
        public static implicit operator DateTime(MyDates d) => d?.GetDate() ?? new DateTime();
        public static implicit operator MyDates(DateTime d) => new MyDates(d);

        public TypeCode GetTypeCode() => TypeCode.Object;
        #endregion

        #region IComparable and operators

        //IComparer
        //public int Compare(object x, object y)
        //{
        //    if (x == null && y == null) return 0;
        //    if (x == null && y != null) return -1;
        //    if (x != null && y == null) return 1;
        //    try
        //    {
        //        return ((MyDates)x).GetDate().Subtract(((MyDates)y).GetDate()).Seconds;
        //    }
        //    catch
        //    {
        //        return 0;
        //    }
        //}

        //"this" will be considered superior if obj is null or not a Date
        public int CompareTo(object obj)
        {
            try
            {
                return (int)GetDate().Subtract(((MyDates)obj).GetDate()).TotalSeconds;
            }
            catch
            {
                return 1;
            }
        }

        public override bool Equals(object obj)
        {
            var dates = obj as MyDates;
            return dates != null &&
                   GetDate() == dates.GetDate();
        }

        public override int GetHashCode()
        {
            var hashCode = -1274777142;
            hashCode = hashCode * -1521134295 + _date.GetHashCode();
            hashCode = hashCode * -1521134295 + _refDate.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(_tenor);
            hashCode = hashCode * -1521134295 + BusinessDayConvention.GetHashCode();
            return hashCode;
        }

        public static bool operator ==(MyDates myDates1, MyDates myDates2)
        {
            if (myDates1 is null && myDates2 is null) return true;
            if (myDates1 is null || myDates2 is null) return false;
            return myDates1.CompareTo(myDates2) == 0;
        }
        public static bool operator !=(MyDates myDates1, MyDates myDates2) => !(myDates1 == myDates2);

        public static bool operator >(MyDates myDates1, MyDates myDates2)
        {
            if (myDates1 is null || myDates2 is null) return false;
            return myDates1.CompareTo(myDates2) > 0;
        }
        public static bool operator <(MyDates myDates1, MyDates myDates2)
        {
            if (myDates1 is null || myDates2 is null) return false;
            return myDates1.CompareTo(myDates2) < 0;
        }
        public static bool operator >=(MyDates myDates1, MyDates myDates2) => (myDates1 > myDates2 || myDates1 == myDates2);
        public static bool operator <=(MyDates myDates1, MyDates myDates2) => (myDates1 < myDates2 || myDates1 == myDates2);

        public override string ToString() => (string)this;
        
        #endregion
    }
}
