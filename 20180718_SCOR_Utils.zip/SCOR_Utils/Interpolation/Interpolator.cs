﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public abstract class Interpolator
    {
        protected internal List<double> _seriesX;
        protected internal List<double> _seriesY;

        public IEnumerable<double> SeriesX
        {
            get => _seriesX ?? new List<double>();
            set => _seriesX = value.ToList();
        }
        public IEnumerable<double> SeriesY
        {
            get => _seriesY ?? new List<double>();
            set => _seriesY = value.ToList();
        }

        protected internal void MatrixToArrays(double[,] inpSeries, out double[] inpX, out double[] inpY)
        {
            int arrayLength = Math.Max(inpSeries.GetLength(0), inpSeries.GetLength(1));
            inpX = new double[arrayLength];
            inpY = new double[arrayLength];

            if (inpSeries.GetLength(0) == 2)
                for(int i = 0; i < arrayLength; i++)
                {
                    inpX[i] = inpSeries[0, i];
                    inpY[i] = inpSeries[1, i];
                }
            else
                for (int i = 0; i < arrayLength; i++)
                {
                    inpX[i] = inpSeries[i, 0];
                    inpY[i] = inpSeries[i, 1];
                }
        }

        protected internal int FindPreviousIndex(double X)
        {
            if (X <= SeriesX?.First()) return 0;            
            return SeriesX?.Count(x => x <= X) - 1 ?? 0;
        }

        public abstract double Interpolate(double X);
        //public abstract double[] Interpolate(double[] X);
        public IEnumerable<double> Interpolate(IEnumerable<double> X) => X?.Select(x => Interpolate(x)) ?? null;

        #region Constructors
        public Interpolator(IEnumerable<double> inpX, IEnumerable<double> inpY)
        {
            if (inpX is null || inpY is null) throw new ArgumentNullException();
            if (inpX.Count() != inpY.Count()) throw new ArgumentOutOfRangeException();
            SeriesX = inpX;
            SeriesY = inpY;
        }
        public Interpolator(IDictionary<double, double> inpSeries)
        {
            if (inpSeries is null) throw new ArgumentNullException();
            if (inpSeries.Count == 0) throw new ArgumentOutOfRangeException();
            //the dictionary needs to be sorted on the keys
            IOrderedEnumerable<KeyValuePair<double, double>> tmpSeries = inpSeries.OrderBy(keyVal => keyVal.Key);
            SeriesX = tmpSeries.Select(keyVal => keyVal.Key);
            SeriesY = tmpSeries.Select(keyVal => keyVal.Value);
        }
        public Interpolator(double[,] inpSeries)
        {
            if (inpSeries is null) throw new ArgumentNullException();
            //restricts to an array of 2 vectors
            if (Math.Min(inpSeries.GetLength(0), inpSeries.GetLength(1)) > 2) throw new ArgumentOutOfRangeException();

            MatrixToArrays(inpSeries, out double[] inpX, out double[] inpY);
            SeriesX = inpX;
            SeriesY = inpY;
        }
        #endregion
    }
}
