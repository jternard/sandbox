﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils.Interpolation
{
    public class LinearInterpolation : Interpolator
    {
        public override double Interpolate(double X)
        {
            //boundaries => output the boundary element (no extrapolation)
            if (X <= SeriesX.First()) return SeriesY.First();
            if (X >= SeriesX.Last()) return SeriesY.Last();

            //existing element => output the corresponding Y element
            for (int i = 0; i < SeriesX.Count(); i++)
                if (SeriesX.ElementAt(i) == X)
                    return SeriesY.ElementAt(i);

            int prevElementIndex = FindPreviousIndex(X);
            int nextElementIndex = prevElementIndex + 1;

            double prevElementX = SeriesX.ElementAt(prevElementIndex);
            double nextElementX = SeriesX.ElementAt(nextElementIndex);
            double prevElementY = SeriesY.ElementAt(prevElementIndex);
            double nextElementY = SeriesY.ElementAt(nextElementIndex);

            return prevElementY + (nextElementY - prevElementY) * (X - prevElementX) / (nextElementX - prevElementX);
        }
        #region Constructors
        public LinearInterpolation(IDictionary<double, double> inpSeries) : base(inpSeries)
        {
        }

        public LinearInterpolation(double[,] inpSeries) : base(inpSeries)
        {
        }

        public LinearInterpolation(IEnumerable<double> inpX, IEnumerable<double> inpY) : base(inpX, inpY)
        {
        }
        #endregion
    }
}
