﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils.Interpolation
{
    public class NaturalCubicSplineInterpolation : Interpolator
    {
        protected internal bool _toCalibrate = true;
        protected internal double[][] _splineCoefficients;
        public double[][] SplineCoefficients
        {
            get
            {
                if (_toCalibrate)
                {
                    if (!(SeriesX is null) && !(SeriesY is null))
                    {
                        _splineCoefficients = NaturalCubicSplineCalibration(SeriesX, SeriesY);
                        _toCalibrate = false;
                    }
                }
                return _splineCoefficients;
            }
        }        

        private double[][] NaturalCubicSplineCalibration(IEnumerable<double> inpX, IEnumerable<double> inpY)
        {
            if (inpX is null || inpY is null) throw new ArgumentNullException();

            int n = inpX.Count() - 1;
            double[] h = new double[n];

            for (int i = 0; i < n; i++)
                h[i] = inpX.ElementAt(i + 1) - inpX.ElementAt(i);
            

            double[] alpha = new double[n];

            for (int i = 1; i < n; i++)
                alpha[i] = 3 / h[i] * (inpY.ElementAt(i + 1) - inpY.ElementAt(i)) - 3 / h[i - 1] * (inpY.ElementAt(i) - inpY.ElementAt(i - 1));
            

            double[] l = new double[n + 1];
            double[] mu = new double[n + 1];
            double[] z = new double[n + 1];

            l[0] = 1;
            mu[0] = 0;
            z[0] = 0;

            for (int i = 1; i < n; i++)
            {
                l[i] = 2 * (inpX.ElementAt(i + 1) - inpX.ElementAt(i - 1)) - h[i - 1] * mu[i - 1];
                mu[i] = h[i] / l[i];
                z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i];
            }

            double[] b = new double[n];
            double[] c = new double[n + 1];
            double[] d = new double[n];

            l[n] = 1;
            z[n] = 0;
            c[n] = 0;

            for (int i = n - 1; i >= 0; i--)
            {
                c[i] = z[i] - mu[i] * c[i + 1];
                b[i] = (inpY.ElementAt(i + 1) - inpY.ElementAt(i)) / h[i] - h[i] * (c[i + 1] + 2 * c[i]) / 3;
                d[i] = (c[i + 1] - c[i]) / (3 * h[i]);
            }

            double[][] output = new double[4][];
            output[0] = inpY.ToArray();
            output[1] = b;
            output[2] = c;
            output[3] = d;
            return output;
        }

        //need to add a boolean to check if elements have been modified since last calibration, to trigger a recalibration
        public override double Interpolate(double X)
        {
            //existing element => output the corresponding Y element
            for (int i = 0; i < SeriesX.Count(); i++)
                if (SeriesX.ElementAt(i) == X)
                    return SeriesY.ElementAt(i);

            int n = SeriesX.Count() - 1;
            int index = 0;

            if (X >= SeriesX.ElementAt(n - 1))
                index = n - 1;
            else
                index = FindPreviousIndex(X);
            
            double deltaX = X - SeriesX.ElementAt(index);

            //Youtput = YValues[index] + b[index] * (deltaX) + c[index] * Math.Pow(deltaX, 2) + d[index] * Math.Pow(deltaX, 3);
            return SplineCoefficients[0][index] + SplineCoefficients[1][index] * (deltaX) + SplineCoefficients[2][index] * Math.Pow(deltaX, 2) + SplineCoefficients[3][index] * Math.Pow(deltaX, 3);
        }

        #region Constructors
        public NaturalCubicSplineInterpolation(IEnumerable<double> inpX, IEnumerable<double> inpY) : base(inpX, inpY)
        {
        }

        public NaturalCubicSplineInterpolation(IDictionary<double, double> inpSeries) : base(inpSeries)
        {
        }

        public NaturalCubicSplineInterpolation(double[,] inpSeries) : base(inpSeries)
        {
        }
        #endregion
    }
}
