﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils.InstrumentsREFACTOR
{
    internal interface ICalibrationInstrument : IInstrument
    {
        void Bootstrapping_DF(IDictionary<MyDates, double> tmpCalibrationDF);
        double DFToZC(double DF);
        double ZCToDF(double ZC);
    }
}
