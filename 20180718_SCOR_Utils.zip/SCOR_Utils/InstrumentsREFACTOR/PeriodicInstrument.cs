﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils.InstrumentsREFACTOR
{
    class PeriodicInstrument : Instrument, IPeriodicInstrument
    {
        public int PaymentFrequency = 12;


        public Schedule GetCurrentSchedule(MyDates myDate = null)
        {
            if (myDate is null) myDate = AsOfDate;
            return Schedule.Single(x => x.StartDate <= myDate && x.EndDate >= myDate);
        }

        public Schedule GetNextSchedule(MyDates myDate = null)
        {
            int schedIndex = Schedule.IndexOf(GetCurrentSchedule(myDate));
            if (schedIndex >= Schedule.Count - 1)
                return Schedule.Last();
            else
                return Schedule[schedIndex + 1];
        }

        public Schedule GetPreviousSchedule(MyDates myDate = null)
        {
            int schedIndex = Schedule.IndexOf(GetCurrentSchedule(myDate));
            if (schedIndex == 0)
                return Schedule.First();
            else
                return Schedule[schedIndex - 1];
        }


        public double AccruedInterest(MyDates myDate = null)
        {
            if (myDate is null) myDate = AsOfDate;
            try
            {
                Schedule currentSchedule = GetCurrentSchedule(myDate);
                return DateHelper.YearFraction(currentSchedule.StartDate, myDate, DayCountConvention) * currentSchedule.Rate;
            }
            catch
            {
                return 0;
            }
        }
    }
}
