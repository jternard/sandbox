﻿using System;
using System.Collections.Generic;
using System.Linq;
using ExcelDna.Integration;
using Excel = Microsoft.Office.Interop.Excel;
using IntelliSense = ExcelDna.IntelliSense;
using SCOR_Utils;
/*
TO TEST/DEBUG:
    Set global parameters to Debug and x64
    Set the projects to Active / Any CPU
    Open the addin with the loaded Excel file

TO PUBLISH:
    Set global parameters to Release and x64
    Set the projects to Active / Any CPU
    Then Sign the resulting packed x64 xll file which can be distributed

TO INSTALL:
    Users need only to load the xll from anywhere on the network or their computers
    It might be necessary to have an admin to validate the certificate
 
missing arguments are of type ExcelMissing
CACHE:
    https://www.codeproject.com/Articles/1097174/Interpolation-in-Excel-using-Excel-DNA

determining the calling cells:
    C API with xlfCaller option (https://social.msdn.microsoft.com/Forums/office/en-US/678c303c-aec9-4845-a4c1-1d15e0782659/xll-determines-the-activecell-in-custom-function?forum=exceldev)
    C API is more or less the ExcelDna.Integration.ExcelReference: https://stackoverflow.com/questions/31038649/passing-an-excel-range-from-vba-to-c-sharp-via-excel-dna

DEPLOYMENT (DEPRECATED):
    Remember to change the name of the embedded dll path in this add-in.dna
    Potentially with Installer class: https://github.com/Excel-DNA/WiXInstaller/blob/master/Source/InstallerCA/InstallerClass.cs
    Also related: https://stackoverflow.com/questions/18602560/how-to-deploy-an-excel-xll-add-in-and-automatically-register-the-add-in-in-excel

CERTIFICATES:
   https://social.technet.microsoft.com/Forums/sharepoint/en-US/3dd3472a-dac0-4016-980c-9c16a06dcc33/issue-certificate-from-ca-server?forum=winserversecurity
   http://www.entrust.net/knowledge-base/technote.cfm?tn=8924
   https://www.ssl.com/how-to/combine-a-private-key-with-p7b-certificate-how-to-create-a-pfx-file/
   Sign the MSI: (from the msi/exe output folders) "SignTool sign /f ..\..\certificate\SCOR_Utils_Setup_jternard_20180608_chained.pfx /p jternard SCOR_Utils_Setup.msi"
   OR sign the xll: "SignTool sign /f ..\..\..\certificate\SCOR_Utils_Setup_jternard_20180608_chained.pfx /p jternard SCOR_Utils_Addin-AddIn64-packed.xll"
*/

namespace SCOR_Utils_Addin
{
    //class was static
    //class didn't implement IExcelAddin Interface
    public class ExcelFunctions : IExcelAddIn
    {

        //private static readonly string YCTag = @"#YC";
        #region IExcelAddin implementation
        public void AutoOpen() => IntelliSense.IntelliSenseServer.Register();
        public void AutoClose() { }
        #endregion
        
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Interpolation method implementing linear or natural cubic spline methods",HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_INTERPOLATE(
            [ExcelArgument(@"Point to interpolate. X as Double or Double()")] object X, 
            [ExcelArgument(@"InpX as Double()")] object InpX,
            [ExcelArgument(@"InpY as Double()")] object InpY,
            [ExcelArgument(description:@"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(X) || ExcelHelper.IsMissing(InpX) || ExcelHelper.IsMissing(InpY)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            if (!InpX.GetType().IsArray || !InpY.GetType().IsArray) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Interpolator interpolator;

            //try to parse the argument InterpolMethod:
            //if argument is missing, LINEAR is used by default
            //if argument is present, then if it matches a valid value (LINEAR, NATURAL_CUBIC_SPLINE) this value will be used, otherwise it returns an error
            InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            if (!ExcelHelper.IsMissing(InterpolMethod))            
                if (!Enum.TryParse(InterpolMethod.ToString(), true, out interpolationMethod))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            
            try
            {
                //USE LINQ, replace InpXList, inpX etc by a more generic approach

                //treatment of the input. From implicit object[,] to List<object>, then to List<double> for non missing elements in both lists
                List<object> InpXList = (InpX as object[,]).Cast<object>().ToList();
                List<object> InpYList = (InpY as object[,]).Cast<object>().ToList();

                if (InpXList.Count != InpYList.Count) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                List<double> inpX = new List<double>();
                List<double> inpY = new List<double>();

                for (int i = 0; i < InpXList.Count; i++)
                    if (Double.TryParse(InpXList[i].ToString(), out double tmpX) && Double.TryParse(InpYList[i].ToString(), out double tmpY))
                    {
                        inpX.Add(tmpX);
                        inpY.Add(tmpY);
                    }

                switch (interpolationMethod)
                {
                    case InterpolationMethodType.LINEAR:
                        interpolator = new SCOR_Utils.Interpolation.LinearInterpolation(inpX, inpY);
                        break;
                    case InterpolationMethodType.NATURAL_CUBIC_SPLINE:
                        interpolator = new SCOR_Utils.Interpolation.NaturalCubicSplineInterpolation(inpX, inpY);
                        break;
                    default:
                        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                }
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }
            

            if (!X.GetType().IsArray)
                //try to parse the argument X, if it manages to parse as a double, return the interpolated value (if the interpolated value is not a valid number it will also be counted as an error)
                //                                                                 else return an error
                return Double.TryParse(X.ToString(), out double x) ? ExcelHelper.CheckNaN(interpolator.Interpolate(x)) : ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);           
            else
            {
                object[,] XArray = X as object[,];
                object[,] output = new object[XArray.GetLength(0), XArray.GetLength(1)];

                for (int i = 0; i < XArray.GetLength(0); i++)
                    for (int j = 0; j < XArray.GetLength(1); j++)
                            output[i,j] = Double.TryParse(XArray[i,j].ToString(), out double x) ? ExcelHelper.CheckNaN(interpolator.Interpolate(x)) : ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                return output;
            }
        }


        //NOTE: to improve depending on the user input such as a 3x2 output with 3 startdate and 2 enddate, or a a list of StartDate and 1 EndDate
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Forward Rate applicable between the StartDate and EndDate. The Curve is defined by a set of YCTenors, YCZC and other optional parameters. The Forward Rate is computed based on this modeled curve.", HelpTopic = @"https://en.wikipedia.org/wiki/Forward_rate", IsThreadSafe = true)]
        public static object SCOR_FWD(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object StartDate,
            [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"". Tenors start from the Start Date.)")] object EndDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(description:@"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(description:@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description:@"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description:@"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(StartDate) || ExcelHelper.IsMissing(EndDate) || ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCZC)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Curve YC;
            try
            {
                YC = CreateZeroCurve(YCTenors, YCZC, RefDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates refDate = new MyDates();
            if (!ExcelHelper.IsMissing(RefDate))
                refDate.SetDate((dynamic)RefDate);
            

            MyDates startDate, endDate;

            //if both are singleton, then output the result
            if (!StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            {
                startDate = new MyDates((dynamic)StartDate);
                startDate.SetRefDate(refDate);

                if (EndDate.GetType() == typeof(string))
                    endDate = new MyDates((string)EndDate, startDate);
                else
                {
                    endDate = new MyDates((dynamic)EndDate);
                    endDate.SetRefDate(refDate);
                }

                return ExcelHelper.CheckNaN(YC.ForwardRate(startDate, endDate));
            }
            //one of the 2 inputs at least is an array
            else
            {
                int dimension0 = 0, dimension1 = 0;
                object[,] StartDateArray, EndDateArray;
                //if one of the 2 inputs is an array and the other not, then transform the one not an array into an array
                if (StartDate.GetType().IsArray != EndDate.GetType().IsArray)
                {
                    //StartDate is an array, but EndDate is not
                    if (StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
                    {
                        StartDateArray = StartDate as object[,];

                        dimension0 = StartDateArray.GetLength(0);
                        dimension1 = StartDateArray.GetLength(1);

                        EndDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                EndDateArray[i, j] = EndDate;                
                    }
                    //StartDate is not an array, EndDate is an array
                    else
                    {
                        EndDateArray = (object[,])EndDate;

                        dimension0 = EndDateArray.GetLength(0);
                        dimension1 = EndDateArray.GetLength(1);

                        StartDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                StartDateArray[i, j] = StartDate;
                    }
                }
                //if both inputs are arrays
                else
                {
                    StartDateArray = StartDate as object[,];
                    EndDateArray = EndDate as object[,];

                    //if the arrays have the same shape but transposed, transpose to have the same shape
                    if (StartDateArray.GetLength(0) == EndDateArray.GetLength(1) && StartDateArray.GetLength(1) == EndDateArray.GetLength(0)) EndDateArray = ExcelHelper.Transpose(EndDateArray);

                    dimension0 = Math.Max(StartDateArray.GetLength(0), EndDateArray.GetLength(0));
                    dimension1 = Math.Max(StartDateArray.GetLength(1), EndDateArray.GetLength(1));
                }

                //normal case, both are arrays:
                object[,] output = new object[dimension0, dimension1];

                //if the arrays have the same shape, possibility to optimise, O(n)
                if (StartDateArray.GetLength(0) == EndDateArray.GetLength(0) && StartDateArray.GetLength(1) == EndDateArray.GetLength(1))
                {
                    for (int i = 0; i < dimension0; i++)
                        for (int j = 0; j < dimension1; j++)
                            try
                            {
                                if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[i, j]))
                                    output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                else
                                {
                                    startDate = new MyDates((dynamic)StartDateArray[i, j]);
                                    startDate.SetRefDate(refDate);

                                    endDate = new MyDates((dynamic)EndDateArray[i, j]);
                                    if (EndDateArray[i, j].GetType() == typeof(string))
                                        endDate = new MyDates((string)EndDateArray[i, j], startDate);
                                    else
                                    {
                                        endDate = new MyDates((dynamic)EndDateArray[i, j]);
                                        endDate.SetRefDate(refDate);
                                    }

                                    output[i, j] = ExcelHelper.CheckNaN(YC.ForwardRate(startDate, endDate));
                                }
                            }
                            catch
                            {
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            }
                }
                else
                {
                    //to be optimised, O(n2)
                    //to be used if the 2 inputs are of different shape/orientation (row vs column)
                    for (int i = 0; i < StartDateArray.GetLength(0); i++)
                        for (int j = 0; j < StartDateArray.GetLength(1); j++)
                            for (int k = 0; k < EndDateArray.GetLength(0); k++)
                                for (int l = 0; l < EndDateArray.GetLength(1); l++)
                                    try
                                    {
                                        if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[k, l]))
                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                        else
                                        {
                                            startDate = new MyDates((dynamic)StartDateArray[i, j]);
                                            startDate.SetRefDate(refDate);

                                            if (EndDateArray[k, l].GetType() == typeof(string))
                                                endDate = new MyDates((dynamic)EndDateArray[k, l], startDate);
                                            else
                                            {
                                                endDate = new MyDates((dynamic)EndDateArray[k, l]);
                                                endDate.SetRefDate(refDate);
                                            }

                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelHelper.CheckNaN(YC.ForwardRate(startDate, endDate));
                                        }
                                    }
                                    catch
                                    {
                                        output[Math.Max(i, k), Math.Max(j, l)] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                    }
                }
                return output;
            }

            #region deprecated
            //MyDates startDate, endDate;
            //List<dynamic> TenorList, ZCList;
            //try
            //{
            //    startDate = new MyDates((dynamic)StartDate);
            //    endDate = new MyDates((dynamic)EndDate);
            //    TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            //    ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();
            //}
            //catch
            //{
            //    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}

            //Dictionary<double, double> curvePoints;

            //if (ZCList.TrueForAll(x => !ExcelHelper.IsMissing(x)) && TenorList.TrueForAll(x => !ExcelHelper.IsMissing(x)))
            //    curvePoints = new Dictionary<double, double>(TenorList.Cast<double>().(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value));
            //else
            //{
            //    curvePoints = new Dictionary<double, double>();
            //    for (int i = 0; i < TenorList.Count; i++)
            //    {
            //        if (!ExcelHelper.IsMissing(TenorList[i]) && !ExcelHelper.IsMissing(ZCList[i]))
            //            curvePoints.Add(TenorList[i], ZCList[i]);
            //    }
            //}


            //Curve YC = new Curve(curvePoints);

            //if (YC == null)
            //    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNA);

            //if (!ExcelHelper.IsMissing(RefDate))
            //{
            //    startDate.SetRefDate((dynamic)RefDate);
            //    endDate.SetRefDate((dynamic)RefDate);
            //    YC.RefDate = new MyDates((dynamic)RefDate);
            //}

            ////if (!ExcelHelper.IsMissing(Currency))
            ////    YC.Currency = Currency.ToString();


            //InterestMethodType interestMethod = InterestMethodType.COMPOUNDING_DISCRETE;
            //if (!ExcelHelper.IsMissing(InterestMethod))
            //{
            //    if (!Enum.TryParse(InterestMethod.ToString(), true, out interestMethod))
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}
            //YC.InterestMethod = interestMethod;

            //DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            //if (!ExcelHelper.IsMissing(DayCountConvention))
            //{
            //    if (!Enum.TryParse(DayCountConvention.ToString(), true, out dayCountConvention))
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}
            //YC.DayCountConvention = dayCountConvention;

            //InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            //if (!ExcelHelper.IsMissing(DayCountConvention))
            //{
            //    if (!Enum.TryParse(InterpolMethod.ToString(), true, out interpolationMethod))
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}
            //YC.InterpolationMethod = interpolationMethod;



            //return ExcelHelper.CheckNaN(YC.ForwardRate((double)startDate, (double)endDate));

            //throw new NotImplementedException();
            #endregion
        }


        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Zero Coupon applicable at the input Maturity. The Curve is defined by a set of YCTenors, YCZC and other optional parameters. The Forward Rate is computed based on this modeled curve.", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_ZC(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(description:@"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(description:@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description:@"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description:@"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {

            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCZC)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Curve YC;
            try
            {
                YC = CreateZeroCurve(YCTenors, YCZC, RefDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates maturityDate, refDate;

            if (!ExcelHelper.IsMissing(RefDate))
                refDate = new MyDates((dynamic)RefDate);
            else
                refDate = new MyDates();


            if (!MaturityDate.GetType().IsArray)
            {
                maturityDate = new MyDates((dynamic)MaturityDate);
                maturityDate.SetRefDate(refDate);
                return ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
            }
            else
            {
                object[,] MaturityDateArray = MaturityDate as object[,];

                object[,] output = new object[MaturityDateArray.GetLength(0), MaturityDateArray.GetLength(1)];
                for (int i = 0; i < MaturityDateArray.GetLength(0); i++)
                    for (int j = 0; j < MaturityDateArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(MaturityDateArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                maturityDate = new MyDates((dynamic)MaturityDateArray[i, j]);
                                maturityDate.SetRefDate(refDate);
                                output[i, j] = ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }            
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Discount Factor applicable at the input Maturity. The Curve is defined by a set of YCTenors, YCZC and other optional parameters. The Forward Rate is computed based on this modeled curve.", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_DF(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(description:@"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(description:@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCZC)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Curve YC;
            try
            {
                YC = CreateZeroCurve(YCTenors, YCZC, RefDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates maturityDate, refDate;

            if (!ExcelHelper.IsMissing(RefDate))
                refDate = new MyDates((dynamic)RefDate);
            else
                refDate = new MyDates();


            if (!MaturityDate.GetType().IsArray)
            {
                maturityDate = new MyDates((dynamic)MaturityDate);
                maturityDate.SetRefDate(refDate);
                return ExcelHelper.CheckNaN(YC.DiscountFactor(maturityDate));
            }
            else
            {
                object[,] MaturityDateArray = MaturityDate as object[,];

                object[,] output = new object[MaturityDateArray.GetLength(0), MaturityDateArray.GetLength(1)];
                for (int i = 0; i < MaturityDateArray.GetLength(0); i++)
                    for (int j = 0; j < MaturityDateArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(MaturityDateArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                maturityDate = new MyDates((dynamic)MaturityDateArray[i, j]);
                                maturityDate.SetRefDate(refDate);
                                output[i, j] = ExcelHelper.CheckNaN(YC.DiscountFactor(maturityDate));
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Year Fraction between two dates.", HelpTopic = @"https://en.wikipedia.org/wiki/Day_count_convention", IsThreadSafe = true)]
        public static object SCOR_YF(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object StartDate,
            [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object EndDate,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]",Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional] RefDate as Date/Double = Today", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name =@"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention
            )
        {
            if(ExcelHelper.IsMissing(StartDate) || ExcelHelper.IsMissing(EndDate)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            
            DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            if (!ExcelHelper.IsMissing(DayCountConvention))
                if (!Enum.TryParse(DayCountConvention.ToString(),true, out dayCountConvention))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            BusinessDayConventionType businessDayConv = BusinessDayConventionType.FOLLOWING;
            if (!ExcelHelper.IsMissing(BusinessDayConvention))
                if (!Enum.TryParse(BusinessDayConvention.ToString(), true, out businessDayConv))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            MyDates refDate = new MyDates();
            if (!ExcelHelper.IsMissing(RefDate))
                refDate.SetDate((dynamic)RefDate);


            MyDates startDate, endDate;

            //if both are singleton, then output the result
            if (!StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            {
                startDate = new MyDates((dynamic)StartDate)
                {
                    BusinessDayConvention = businessDayConv                    
                };
                startDate.SetRefDate(refDate);


                if (EndDate.GetType() == typeof(string))
                    endDate = new MyDates((string)EndDate, startDate);
                else
                {
                    endDate = new MyDates((dynamic)EndDate);
                    endDate.SetRefDate(refDate);
                }
                endDate.BusinessDayConvention = businessDayConv;

                return ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate, endDate, dayCountConvention));
            }
            //one of the 2 inputs at least is an array
            else
            {
                int dimension0 = 0, dimension1 = 0;
                object[,] StartDateArray, EndDateArray;
                //if one of the 2 inputs is an array and the other not, then transform the one not an array into an array
                if (StartDate.GetType().IsArray != EndDate.GetType().IsArray)
                {
                    //StartDate is an array, but EndDate is not
                    if (StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
                    {
                        StartDateArray = StartDate as object[,];

                        dimension0 = StartDateArray.GetLength(0);
                        dimension1 = StartDateArray.GetLength(1);

                        EndDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                EndDateArray[i, j] = EndDate;                      
                    }
                    //StartDate is not an array, EndDate is an array
                    else
                    {
                        EndDateArray = EndDate as object[,];

                        dimension0 = EndDateArray.GetLength(0);
                        dimension1 = EndDateArray.GetLength(1);

                        StartDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                StartDateArray[i, j] = StartDate;
                    }
                }
                //if both inputs are arrays
                else
                {
                    StartDateArray = StartDate as object[,];
                    EndDateArray = EndDate as object[,];

                    //if the arrays have the same shape but transposed, transpose to have the same shape
                    if (StartDateArray.GetLength(0) == EndDateArray.GetLength(1) && StartDateArray.GetLength(1) == EndDateArray.GetLength(0)) EndDateArray = ExcelHelper.Transpose(EndDateArray);

                    dimension0 = Math.Max(StartDateArray.GetLength(0), EndDateArray.GetLength(0));
                    dimension1 = Math.Max(StartDateArray.GetLength(1), EndDateArray.GetLength(1));
                }

                //normal case, both are arrays:
                object[,] output = new object[dimension0, dimension1];

                //if the arrays have the same shape, possibility to optimise, O(n)
                if (StartDateArray.GetLength(0) == EndDateArray.GetLength(0) && StartDateArray.GetLength(1) == EndDateArray.GetLength(1))
                {
                    for (int i = 0; i < dimension0; i++)
                        for (int j = 0; j < dimension1; j++)
                        {
                            try
                            {
                                if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[i, j]))
                                    output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                else
                                {
                                    startDate = new MyDates((dynamic)StartDateArray[i, j])
                                    {
                                        BusinessDayConvention = businessDayConv
                                    };
                                    startDate.SetRefDate(refDate);


                                    if (EndDateArray[i, j].GetType() == typeof(string))
                                        endDate = new MyDates((string)EndDateArray[i, j], startDate);
                                    else
                                    {
                                        endDate = new MyDates((dynamic)EndDateArray[i, j]);
                                        endDate.SetRefDate(refDate);
                                    }
                                    endDate.BusinessDayConvention = businessDayConv;

                                    output[i, j] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate, endDate, dayCountConvention));
                                }
                            }
                            catch
                            {
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            }
                        }
                }
                else
                {
                    //to be optimised, O(n2)
                    //to be used if the 2 inputs are of different shape/orientation (row vs column)

                    //problem with ram beyond 50k products apparently
                    if (StartDateArray.GetLength(0) * StartDateArray.GetLength(1) * EndDateArray.GetLength(0) * EndDateArray.GetLength(1) > 50000) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                    for (int i = 0; i < StartDateArray.GetLength(0); i++)
                        for (int j = 0; j < StartDateArray.GetLength(1); j++)
                            for (int k = 0; k < EndDateArray.GetLength(0); k++)
                                for (int l = 0; l < EndDateArray.GetLength(1); l++)
                                {
                                    try
                                    {
                                        if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[k, l]))
                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                        else
                                        {                                          
                                            startDate = new MyDates((dynamic)StartDateArray[i, j])
                                            {
                                                BusinessDayConvention = businessDayConv
                                            };
                                            startDate.SetRefDate(refDate);

                                            if (EndDateArray[k, l].GetType() == typeof(string))
                                                endDate = new MyDates((string)EndDateArray[k, l], startDate);
                                            else
                                            {
                                                endDate = new MyDates((dynamic)EndDateArray[k, l]);
                                                endDate.SetRefDate(refDate);
                                            }
                                            endDate.BusinessDayConvention = businessDayConv;

                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
                                        }
                                    }
                                    catch
                                    {
                                        output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                    }
                                    
                                }
                }
                return output;
            }

            #region deprecated
            //if (!StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            //{
            //    startDate = new MyDates((dynamic)StartDate);
            //    endDate = new MyDates((dynamic)EndDate);

            //    if (!ExcelHelper.IsMissing(RefDate))
            //    {
            //        startDate.SetRefDate((dynamic)RefDate);
            //        endDate.SetRefDate((dynamic)RefDate);
            //    }

            //    //override of the reference date of the end period if it is defined as a tenor
            //    if (EndDate.GetType() == typeof(string)) endDate.SetRefDate(startDate);

            //    startDate.BusinessDayConvention = businessDayConv;
            //    endDate.BusinessDayConvention = businessDayConv;

            //    return ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //}
            //else if (StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            //{
            //    object[] StartDateArray = (StartDate.GetType().IsCOMObject ? (Array)((Excel.Range)StartDate).Value2 : (Array)StartDate).Cast<object>().ToArray();
            //    object[] output = new object[StartDateArray.Length];
            //    for (int i = 0; i < StartDateArray.Length; i++)
            //    {
            //        if (ExcelHelper.IsMissing(StartDateArray[i]))
            //            output[i] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        else
            //        {
            //            startDate = new MyDates((dynamic)StartDateArray[i]);
            //            endDate = new MyDates((dynamic)EndDate);
            //            if (!ExcelHelper.IsMissing(RefDate))
            //            {
            //                startDate.SetRefDate((dynamic)RefDate);
            //                endDate.SetRefDate((dynamic)RefDate);
            //            }

            //            output[i] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //        }
            //    }
            //    return output;
            //}
            //else if (!StartDate.GetType().IsArray && EndDate.GetType().IsArray)
            //{
            //    object[] EndDateArray = (EndDate.GetType().IsCOMObject ? (Array)((Excel.Range)EndDate).Value2 : (Array)EndDate).Cast<object>().ToArray();
            //    object[] output = new object[EndDateArray.Length];
            //    for (int i = 0; i < EndDateArray.Length; i++)
            //    {
            //        if (ExcelHelper.IsMissing(EndDateArray[i]))
            //            output[i] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        else
            //        {
            //            startDate = new MyDates((dynamic)StartDate);
            //            endDate = new MyDates((dynamic)EndDateArray[i]);

            //            if (!ExcelHelper.IsMissing(RefDate))
            //            {
            //                startDate.SetRefDate((dynamic)RefDate);
            //                endDate.SetRefDate((dynamic)RefDate);
            //            }

            //            output[i] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //        }
            //    }
            //    return output;
            //}
            ////both are arrays
            //else
            //{
            //    object[] StartDateArray = (StartDate.GetType().IsCOMObject ? (Array)((Excel.Range)StartDate).Value2 : (Array)StartDate).Cast<object>().ToArray();
            //    object[] EndDateArray = (EndDate.GetType().IsCOMObject ? (Array)((Excel.Range)EndDate).Value2 : (Array)EndDate).Cast<object>().ToArray();
            //    object[,] output = new object[StartDateArray.Length, EndDateArray.Length];

            //    for (int i = 0; i < StartDateArray.Length; i++)
            //    {
            //        if (ExcelHelper.IsMissing(StartDateArray[i]))
            //        {
            //            for (int j = 0; j < EndDateArray.Length; j++)
            //                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        }
            //        else
            //        {
            //            startDate = new MyDates((dynamic)StartDateArray[i]);
            //            if (!ExcelHelper.IsMissing(RefDate))
            //                startDate.SetRefDate((dynamic)RefDate);

            //            for (int j = 0; j < EndDateArray.Length; j++)
            //            {
            //                if (ExcelHelper.IsMissing(EndDateArray[j]))
            //                    output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //                else
            //                {
            //                    endDate = new MyDates((dynamic)EndDateArray[j]);
            //                    if (!ExcelHelper.IsMissing(RefDate))
            //                        startDate.SetRefDate((dynamic)RefDate);

            //                    output[i, j] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //                }
            //            }
            //        }
            //    }
            //    return output;
            //}
            #endregion
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the date corresponding to the Tenor.", HelpTopic = @"https://en.wikipedia.org/wiki/Day_count_convention", IsThreadSafe = true)]
        public static object SCOR_TENORDATE(
            [ExcelArgument(@"Tenor as String (e.g. annual would be ""1Y"" or ""12M"")")] object Tenor,
            [ExcelArgument(description: @"[Optional] RefDate as Date/Double = Today",Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name = @"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention
            )
        {
            if (ExcelHelper.IsMissing(Tenor)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            
            BusinessDayConventionType businessDayConvention = BusinessDayConventionType.FOLLOWING;
            if (!ExcelHelper.IsMissing(BusinessDayConvention))
                if (!Enum.TryParse(BusinessDayConvention.ToString(), true, out businessDayConvention))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            MyDates refDate = new MyDates();
            if (!ExcelHelper.IsMissing(RefDate))
                refDate.SetDate((dynamic)RefDate);


            //if singleton
            if (!Tenor.GetType().IsArray)
            {
                if(Tenor.GetType() != typeof(string)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                return new MyDates(Tenor as string, refDate)
                {
                    BusinessDayConvention = businessDayConvention
                }.GetDate();
            }
            //if matricial
            else
            {
                object[,] TenorArray = Tenor as object[,];
                object[,] output = new object[TenorArray.GetLength(0), TenorArray.GetLength(1)];

                for (int i = 0; i < TenorArray.GetLength(0); i++)
                    for (int j = 0; j < TenorArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(TenorArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                output[i, j] = new MyDates((string)TenorArray[i, j], refDate)
                                {
                                    BusinessDayConvention = businessDayConvention
                                }.GetDate();  
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }

            #region deprecated
            //MyDates tenorDate;
            //if (Tenor.GetType().IsArray)
            //{
            //    object[] TenorArray = (Tenor.GetType().IsCOMObject ? (Array)((Excel.Range)Tenor).Value2 : (Array)Tenor).Cast<object>().ToArray();
            //    object[] output = new object[TenorArray.Length];
            //    for (int i = 0; i < output.Length; i++)
            //    {
            //        if(ExcelHelper.IsMissing(TenorArray[i]))
            //            output[i] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        else
            //        {
            //            tenorDate = new MyDates((dynamic)TenorArray[i]);

            //            if (!ExcelHelper.IsMissing(RefDate))
            //                tenorDate.SetRefDate((dynamic)RefDate);

            //            if (!ExcelHelper.IsMissing(BusinessDayConvention))
            //                if (Enum.TryParse(BusinessDayConvention.ToString(), true, out BusinessDayConventionType businessDayConvention))
            //                    tenorDate.BusinessDayConvention = businessDayConvention;

            //            output[i] = tenorDate.GetDate();
            //        }
            //    }

            //    if (Tenor.GetType() == typeof(object[,]))
            //        return ExcelHelper.Transpose(output);
            //    else
            //        return output;
            //}
            //else
            //{
            //    tenorDate = new MyDates(Tenor.ToString());
            //    try
            //    {
            //        if (!ExcelHelper.IsMissing(RefDate))
            //            tenorDate.SetRefDate((dynamic)RefDate);

            //        if (!ExcelHelper.IsMissing(BusinessDayConvention))
            //            if (Enum.TryParse(BusinessDayConvention.ToString(), true, out BusinessDayConventionType businessDayConvention))
            //                tenorDate.BusinessDayConvention = businessDayConvention;

            //        return tenorDate.GetDate();
            //    }
            //    catch
            //    {
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //    }
            //}
            #endregion
        }

        
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Price, Accrued Interest, Yield to Maturity, Duration and Convexity for a bond specified with the input parameters. Output is an array of 5 elements Array(Price, Accrued Interest, Yield, Duration, Convexity)", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_(finance)", IsThreadSafe = true)]
        public static object SCOR_BONDPRICING(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] object CouponRate,
            [ExcelArgument(@"CouponFrequency as Integer (represent the length of a period in months, e.g. 6 for half yearly, 3 for quarterly etc).)")] object CouponFrequency,
            [ExcelArgument(description: @"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)", Name = @"[QuotedPrice]")] object QuotedPrice,
            [ExcelArgument(description: @"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)", Name = @"[Yield]")] object Yield,
            [ExcelArgument(description: @"[Optional: PrincipalRepayment as double = 100]", Name = @"[PrincipalRepayment]")][System.Runtime.InteropServices.Optional] object PrincipalRepayment,
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name = @"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention,
            [ExcelArgument(description: @"[Optional: YCTenors as Double()]", Name = @"[YCTenors]")] object YCTenors, //for test
            [ExcelArgument(description: @"[Optional: YCZC as Double()]", Name = @"[YCZC]")] object YCZC, //for test
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(CouponRate) || ExcelHelper.IsMissing(CouponFrequency)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNull);

            FixedBond bond;
            double price, accruedInterest, yield, duration, convexity;

            try
            {
                bond = CreateBond(MaturityDate,CouponRate,CouponFrequency, PrincipalRepayment, RefDate, DayCountConvention, BusinessDayConvention);
                accruedInterest = bond.AccruedInterest();
                //actual computation IF YIELD OR PRICE ARE GIVEN, AKA MARKET INSTRUMENT
                if (!ExcelHelper.IsMissing(QuotedPrice) || !ExcelHelper.IsMissing(Yield))
                {
                    if (!ExcelHelper.IsMissing(Yield))
                    {
                        yield = (double)Yield;
                        bond.YTM = yield;
                        price = bond.YieldToPrice(yield); //not necessary as by default bond.YTM will be used, and bond.YTM = yield
                    }
                    else
                    {
                        price = (double)QuotedPrice;
                        bond.MarketPrice = price / 100;
                        yield = bond.YTM;
                    }                    
                    bond.Pricing(yield, out duration, out convexity);

                }
                //no yield AND no Price are given => theoretical
                else
                {                    
                    bond.ParentCurve = CreateZeroCurve(YCTenors, YCZC, RefDate, InterestMethod, DayCountConvention, InterpolMethod);
                    price = bond.Pricing(out duration, out convexity, out yield);
                    if (bond.QuotationType == QuotationType.PERCENT_CLEAN)
                        price -= accruedInterest;
                    price *= 100;
                }
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            //double[] output = new double[5];
            //output[0] = price;
            //output[1] = accruedInterest;
            //output[2] = yield;
            //output[3] = duration;
            //output[4] = convexity / 100;
            return new double[] { price, accruedInterest, yield, duration, convexity / 100};
        }
        
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Clean Price for a bond specified with the input parameters and a given Price.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
        public static object SCOR_BONDPRICE(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] object CouponRate,
            [ExcelArgument(@"CouponFrequency as Integer (represent the length of a period in months, e.g. 6 for half yearly, 3 for quarterly etc).)")] object CouponFrequency,
            [ExcelArgument(description: @"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)", Name = @"[QuotedPrice]")] object QuotedPrice,
            [ExcelArgument(description: @"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)", Name = @"[Yield]")] object Yield,
            [ExcelArgument(description: @"[Optional: PrincipalRepayment as double = 100]", Name = @"[PrincipalRepayment]")][System.Runtime.InteropServices.Optional] object PrincipalRepayment,
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name = @"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention,
            [ExcelArgument(description: @"[Optional: YCTenors as Double()]", Name = @"[YCTenors]")] object YCTenors, //for test
            [ExcelArgument(description: @"[Optional: YCZC as Double()]", Name = @"[YCZC]")] object YCZC, //for test
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(CouponRate) || ExcelHelper.IsMissing(CouponFrequency)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNull);
            if (!ExcelHelper.IsMissing(QuotedPrice)) return QuotedPrice;
            try
            {                
                return ((double[])SCOR_BONDPRICING(MaturityDate, CouponRate, CouponFrequency, QuotedPrice, Yield, PrincipalRepayment, RefDate, InterestMethod, DayCountConvention, BusinessDayConvention, YCTenors, YCZC, InterpolMethod))[0];
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Clean Price for a bond specified with the input parameters and a given Price.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
        public static object SCOR_BONDACCRUED(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] object CouponRate,
            [ExcelArgument(@"CouponFrequency as Integer (represent the length of a period in months, e.g. 6 for half yearly, 3 for quarterly etc).)")] object CouponFrequency,
            [ExcelArgument(description: @"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)", Name = @"[QuotedPrice]")] object QuotedPrice,
            [ExcelArgument(description: @"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)", Name = @"[Yield]")] object Yield,
            [ExcelArgument(description: @"[Optional: PrincipalRepayment as double = 100]", Name = @"[PrincipalRepayment]")][System.Runtime.InteropServices.Optional] object PrincipalRepayment,
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name = @"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention,
            [ExcelArgument(description: @"[Optional: YCTenors as Double()]", Name = @"[YCTenors]")] object YCTenors, //for test
            [ExcelArgument(description: @"[Optional: YCZC as Double()]", Name = @"[YCZC]")] object YCZC, //for test
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(CouponRate) || ExcelHelper.IsMissing(CouponFrequency)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNull);
            try
            {
                return ((double[])SCOR_BONDPRICING(MaturityDate, CouponRate, CouponFrequency, QuotedPrice, Yield, PrincipalRepayment, RefDate, InterestMethod, DayCountConvention, BusinessDayConvention, YCTenors, YCZC, InterpolMethod))[1];
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Yield to Maturity for a bond specified with the input parameters and a given Yield.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
        public static object SCOR_BONDYIELD(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] object CouponRate,
            [ExcelArgument(@"CouponFrequency as Integer (represent the length of a period in months, e.g. 6 for half yearly, 3 for quarterly etc).)")] object CouponFrequency,
            [ExcelArgument(description: @"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)", Name = @"[QuotedPrice]")] object QuotedPrice,
            [ExcelArgument(description: @"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)", Name = @"[Yield]")] object Yield,
            [ExcelArgument(description: @"[Optional: PrincipalRepayment as double = 100]", Name = @"[PrincipalRepayment]")][System.Runtime.InteropServices.Optional] object PrincipalRepayment,
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name = @"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention,
            [ExcelArgument(description: @"[Optional: YCTenors as Double()]", Name = @"[YCTenors]")] object YCTenors, //for test
            [ExcelArgument(description: @"[Optional: YCZC as Double()]", Name = @"[YCZC]")] object YCZC, //for test
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(CouponRate) || ExcelHelper.IsMissing(CouponFrequency)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNull);
            if (!ExcelHelper.IsMissing(Yield)) return Yield;
            try
            {
                return ((double[])SCOR_BONDPRICING(MaturityDate, CouponRate, CouponFrequency, QuotedPrice, Yield, PrincipalRepayment, RefDate, InterestMethod, DayCountConvention, BusinessDayConvention, YCTenors, YCZC, InterpolMethod))[2];
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Modified Duration for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_duration", IsThreadSafe = true)]
        public static object SCOR_BONDDURATION(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] object CouponRate,
            [ExcelArgument(@"CouponFrequency as Integer (represent the length of a period in months, e.g. 6 for half yearly, 3 for quarterly etc).)")] object CouponFrequency,
            [ExcelArgument(description: @"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)", Name = @"[QuotedPrice]")] object QuotedPrice,
            [ExcelArgument(description: @"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)", Name = @"[Yield]")] object Yield,
            [ExcelArgument(description: @"[Optional: PrincipalRepayment as double = 100]", Name = @"[PrincipalRepayment]")][System.Runtime.InteropServices.Optional] object PrincipalRepayment,
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name = @"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention,
            [ExcelArgument(description: @"[Optional: YCTenors as Double()]", Name = @"[YCTenors]")] object YCTenors, //for test
            [ExcelArgument(description: @"[Optional: YCZC as Double()]", Name = @"[YCZC]")] object YCZC, //for test
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(CouponRate) || ExcelHelper.IsMissing(CouponFrequency)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNull);
            try
            {
                return ((double[])SCOR_BONDPRICING(MaturityDate, CouponRate, CouponFrequency, QuotedPrice, Yield, PrincipalRepayment, RefDate, InterestMethod, DayCountConvention, BusinessDayConvention, YCTenors, YCZC, InterpolMethod))[3];
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Convexity for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_convexity", IsThreadSafe = true)]
        public static object SCOR_BONDCONVEXITY(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] object CouponRate,
            [ExcelArgument(@"CouponFrequency as Integer (represent the length of a period in months, e.g. 6 for half yearly, 3 for quarterly etc).)")] object CouponFrequency,
            [ExcelArgument(description: @"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)", Name = @"[QuotedPrice]")] object QuotedPrice,
            [ExcelArgument(description: @"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)", Name = @"[Yield]")] object Yield,
            [ExcelArgument(description: @"[Optional: PrincipalRepayment as double = 100]", Name = @"[PrincipalRepayment]")][System.Runtime.InteropServices.Optional] object PrincipalRepayment,
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]", Name = @"[BusinessDayConvention]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention,
            [ExcelArgument(description: @"[Optional: YCTenors as Double()]", Name = @"[YCTenors]")] object YCTenors, //for test
            [ExcelArgument(description: @"[Optional: YCZC as Double()]", Name = @"[YCZC]")] object YCZC, //for test
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(CouponRate) || ExcelHelper.IsMissing(CouponFrequency)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNull);
            try
            {
                return ((double[])SCOR_BONDPRICING(MaturityDate, CouponRate, CouponFrequency, QuotedPrice, Yield, PrincipalRepayment, RefDate, InterestMethod, DayCountConvention, BusinessDayConvention, YCTenors, YCZC, InterpolMethod))[4];
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }
        }

        internal static Curve CreateZeroCurve(
            object YCTenors,
            object YCZC,
            [System.Runtime.InteropServices.Optional] object RefDate,
            [System.Runtime.InteropServices.Optional] object InterestMethod,
            [System.Runtime.InteropServices.Optional] object DayCountConvention,
            [System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCZC)) throw new ArgumentNullException();
            //if the curve is not properly defined (i.e. 1 of the 2 vectors is a singleton), exit
            if (!YCZC.GetType().IsArray || !YCTenors.GetType().IsArray) throw new ArgumentNullException();

            InterestMethodType interestMethod = InterestMethodType.COMPOUNDING_DISCRETE;
            if (!ExcelHelper.IsMissing(InterestMethod))
                if (!Enum.TryParse(InterestMethod.ToString(), true, out interestMethod))
                    throw new ArgumentOutOfRangeException();

            DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            if (!ExcelHelper.IsMissing(DayCountConvention))
                if (!Enum.TryParse(DayCountConvention.ToString(), true, out dayCountConvention))
                    throw new ArgumentOutOfRangeException();

            InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            if (!ExcelHelper.IsMissing(InterpolMethod))
                if (!Enum.TryParse(InterpolMethod.ToString(), true, out interpolationMethod))
                    throw new ArgumentOutOfRangeException();


            //ExcelDNA COM wrapper transforms ranges in 2 dimensional objects (line or column vectors alike)
            object[,] TenorArray = YCTenors as object[,];
            object[,] ZCArray = YCZC as object[,];

            if (TenorArray.Length != ZCArray.Length) throw new ArgumentOutOfRangeException();
            if (TenorArray.GetLength(0) != ZCArray.GetLength(0)) ZCArray = ExcelHelper.Transpose(ZCArray);

            List<Instrument> myInstruments = new List<Instrument>();

            for (int i = 0; i < TenorArray.GetLength(0); i++)
                for (int j = 0; j < TenorArray.GetLength(1); j++)
                {
                    try
                    {
                        if (!ExcelHelper.IsMissing(TenorArray[i, j]) && !ExcelHelper.IsMissing(ZCArray[i, j]))                        
                            myInstruments.Add(
                                new Instrument(new MyDates((dynamic)TenorArray[i, j]), (double)ZCArray[i, j])
                                {
                                    InterestMethod = interestMethod,
                                    DayCountConvention = dayCountConvention                                    
                                }
                                );      
                    }
                    catch
                    {
                    }
                }

            if (myInstruments.Count == 0) throw new ArgumentNullException();         

            Curve YC = new Curve(myInstruments)
            {
                InterestMethod = interestMethod,
                DayCountConvention = dayCountConvention,
                InterpolationMethod = interpolationMethod
            };

            if (!ExcelHelper.IsMissing(RefDate)) YC.AsOfDate = new MyDates((dynamic)RefDate);

            //YC.Calibrate();

            return YC;
        }

        internal static Curve CreateSwapCurve(
            object YCTenors,
            object YCSwapRates,
            [System.Runtime.InteropServices.Optional] object RefDate,
            [System.Runtime.InteropServices.Optional] object InterestMethod,
            [System.Runtime.InteropServices.Optional] object DayCountConvention,
            [System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCSwapRates)) throw new ArgumentNullException();
            //if the curve is not properly defined (i.e. 1 of the 2 vectors is a singleton), exit
            if (!YCSwapRates.GetType().IsArray || !YCTenors.GetType().IsArray) throw new ArgumentNullException();

            InterestMethodType interestMethod = InterestMethodType.COMPOUNDING_DISCRETE;
            if (!ExcelHelper.IsMissing(InterestMethod))
                if (!Enum.TryParse(InterestMethod.ToString(), true, out interestMethod))
                    throw new ArgumentOutOfRangeException();

            DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            if (!ExcelHelper.IsMissing(DayCountConvention))
                if (!Enum.TryParse(DayCountConvention.ToString(), true, out dayCountConvention))
                    throw new ArgumentOutOfRangeException();

            InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            if (!ExcelHelper.IsMissing(InterpolMethod))
                if (!Enum.TryParse(InterpolMethod.ToString(), true, out interpolationMethod))
                    throw new ArgumentOutOfRangeException();


            //ExcelDNA COM wrapper transforms ranges in 2 dimensional objects (line or column vectors alike)
            object[,] TenorArray = YCTenors as object[,];
            object[,] SwapArray = YCSwapRates as object[,];

            if (TenorArray.Length != SwapArray.Length) throw new ArgumentOutOfRangeException();
            if (TenorArray.GetLength(0) != SwapArray.GetLength(0)) SwapArray = ExcelHelper.Transpose(SwapArray);            

            List<IRS> myInstruments = new List<IRS>();

            for (int i = 0; i < TenorArray.GetLength(0); i++)
                for (int j = 0; j < TenorArray.GetLength(1); j++)
                {
                    try
                    {
                        if (!ExcelHelper.IsMissing(TenorArray[i, j]) && !ExcelHelper.IsMissing(SwapArray[i, j]))
                            myInstruments.Add(
                                new IRS(new MyDates((dynamic)TenorArray[i, j]))
                                {
                                    SwapRate = (double)SwapArray[i, j],
                                    InterestMethod = interestMethod,
                                    DayCountConvention = dayCountConvention,                                    
                                }
                                );
                    }
                    catch
                    {
                    }
                }

            if (myInstruments.Count == 0) throw new ArgumentNullException();

            Curve YC = new Curve(myInstruments)
            {
                InterestMethod = interestMethod,
                DayCountConvention = dayCountConvention,
                InterpolationMethod = interpolationMethod,
                CurveType = CurveType.MONEY_MARKET
            };

            if (!ExcelHelper.IsMissing(RefDate)) YC.AsOfDate = new MyDates((dynamic)RefDate);

            YC.Calibrate();

            return YC;
        }

        //note: bonds have by default a yearly frequency
        internal static Curve CreateBondCurve(
            object YCTenors,
            object YCYTM,
            object YCCouponRates,
            [System.Runtime.InteropServices.Optional] object RefDate,
            [System.Runtime.InteropServices.Optional] object InterestMethod,
            [System.Runtime.InteropServices.Optional] object DayCountConvention,
            [System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCYTM) || ExcelHelper.IsMissing(YCCouponRates)) throw new ArgumentNullException();
            //if the curve is not properly defined (i.e. 1 of the 2 vectors is a singleton), exit
            if (!YCYTM.GetType().IsArray || !YCTenors.GetType().IsArray || !YCCouponRates.GetType().IsArray) throw new ArgumentNullException();

            InterestMethodType interestMethod = InterestMethodType.COMPOUNDING_DISCRETE;
            if (!ExcelHelper.IsMissing(InterestMethod))
                if (!Enum.TryParse(InterestMethod.ToString(), true, out interestMethod))
                    throw new ArgumentOutOfRangeException();

            DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            if (!ExcelHelper.IsMissing(DayCountConvention))
                if (!Enum.TryParse(DayCountConvention.ToString(), true, out dayCountConvention))
                    throw new ArgumentOutOfRangeException();

            InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            if (!ExcelHelper.IsMissing(InterpolMethod))
                if (!Enum.TryParse(InterpolMethod.ToString(), true, out interpolationMethod))
                    throw new ArgumentOutOfRangeException();


            //ExcelDNA COM wrapper transforms ranges in 2 dimensional objects (line or column vectors alike)
            object[,] TenorArray = YCTenors as object[,];
            object[,] YTMArray = YCYTM as object[,];
            object[,] CouponArray = YCCouponRates as object[,];

            if (TenorArray.Length != YTMArray.Length || YTMArray.Length != CouponArray.Length) throw new ArgumentOutOfRangeException();
            if (TenorArray.GetLength(0) != YTMArray.GetLength(0)) YTMArray = ExcelHelper.Transpose(YTMArray);
            if (TenorArray.GetLength(0) != CouponArray.GetLength(0)) CouponArray = ExcelHelper.Transpose(CouponArray);

            List<FixedBond> myInstruments = new List<FixedBond>();

            for (int i = 0; i < TenorArray.GetLength(0); i++)
                for (int j = 0; j < TenorArray.GetLength(1); j++)
                {
                    try
                    {
                        if (!ExcelHelper.IsMissing(TenorArray[i, j]) && !ExcelHelper.IsMissing(YTMArray[i, j]) && !ExcelHelper.IsMissing(CouponArray[i, j]))
                            myInstruments.Add(
                                new FixedBond(new MyDates((dynamic)TenorArray[i, j]))
                                {
                                    CouponRate = (double)CouponArray[i, j],
                                    YTM = (double)YTMArray[i, j],                                    
                                    InterestMethod = interestMethod,
                                    DayCountConvention = dayCountConvention,
                                }
                                );
                    }
                    catch
                    {
                    }
                }

            if (myInstruments.Count == 0) throw new ArgumentNullException();

            Curve YC = new Curve(myInstruments)
            {
                InterestMethod = interestMethod,
                DayCountConvention = dayCountConvention,
                InterpolationMethod = interpolationMethod,
                CurveType = CurveType.FIXED_INCOME
            };

            if (!ExcelHelper.IsMissing(RefDate)) YC.AsOfDate = new MyDates((dynamic)RefDate);

            YC.Calibrate();

            return YC;
        }

        internal static FixedBond CreateBond(
            object MaturityDate,
            object CouponRate,
            object CouponFrequency,
            [System.Runtime.InteropServices.Optional] object PrincipalRepayment,
            [System.Runtime.InteropServices.Optional] object RefDate,
            [System.Runtime.InteropServices.Optional] object DayCountConvention,
            [System.Runtime.InteropServices.Optional] object BusinessDayConvention
            )
        {

            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(CouponRate) || ExcelHelper.IsMissing(CouponFrequency)) throw new ArgumentNullException();

            BusinessDayConventionType businessDayConv = BusinessDayConventionType.FOLLOWING;
            if (!ExcelHelper.IsMissing(BusinessDayConvention))
                if (!Enum.TryParse(BusinessDayConvention.ToString(), true, out businessDayConv))
                    throw new ArgumentException();

            DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            if (!ExcelHelper.IsMissing(DayCountConvention))
                if (!Enum.TryParse(DayCountConvention.ToString(), true, out dayCountConvention))
                    throw new ArgumentException();


            FixedBond bond;

            //MaturityDate and AsOfDate
            if (ExcelHelper.IsMissing(RefDate))
                bond = new FixedBond(new MyDates((dynamic)MaturityDate))
                {
                    DayCountConvention = dayCountConvention,
                    BusinessDayConvention = businessDayConv
                };
            else
            {
                MyDates bondMaturityDate;

                if (MaturityDate.GetType() == typeof(string))
                    bondMaturityDate = new MyDates((string)MaturityDate, (dynamic)RefDate);
                else
                    bondMaturityDate = new MyDates((dynamic)MaturityDate);

                bond = new FixedBond(bondMaturityDate, new MyDates((dynamic)RefDate))
                {
                    DayCountConvention = dayCountConvention,
                    BusinessDayConvention = businessDayConv
                };
            }
            //fill as many fields as arguments are provided
            try { bond.CouponRate = (double)CouponRate; } catch { }
            try { bond.PaymentFrequency = Convert.ToInt32(CouponFrequency); } catch { }
            try { bond.RepaymentNominal = (double)PrincipalRepayment / 100; } catch { }

            return bond;
        }

        #region TESTS
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Zero Coupon applicable at the input Maturity. The Curve is defined by a set of YCTenors, YCZC and other optional parameters. The Forward Rate is computed based on this modeled curve.", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_ZCBOND(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors,
            [ExcelArgument(@"YCYTM as Double()")] object YCYTM,
            [ExcelArgument(@"YCCoupons as Double()")] object YCCoupons,
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {

            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCYTM) || ExcelHelper.IsMissing(YCCoupons)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Curve YC;
            try
            {
                YC = CreateBondCurve(YCTenors, YCYTM, YCCoupons, RefDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates maturityDate, refDate;

            if (!ExcelHelper.IsMissing(RefDate))
                refDate = new MyDates((dynamic)RefDate);
            else
                refDate = new MyDates();


            if (!MaturityDate.GetType().IsArray)
            {
                maturityDate = new MyDates((dynamic)MaturityDate);
                maturityDate.SetRefDate(refDate);
                return ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
            }
            else
            {
                object[,] MaturityDateArray = MaturityDate as object[,];

                object[,] output = new object[MaturityDateArray.GetLength(0), MaturityDateArray.GetLength(1)];
                for (int i = 0; i < MaturityDateArray.GetLength(0); i++)
                    for (int j = 0; j < MaturityDateArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(MaturityDateArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                maturityDate = new MyDates((dynamic)MaturityDateArray[i, j]);
                                maturityDate.SetRefDate(refDate);
                                output[i, j] = ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Zero Coupon applicable at the input Maturity. The Curve is defined by a set of YCTenors, YCZC and other optional parameters. The Forward Rate is computed based on this modeled curve.", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_ZCSWAP(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCSWAP, //for test
                                                              //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
                                                              //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(description: @"[Optional: RefDate as Date/Double = Today]", Name = @"[RefDate]")][System.Runtime.InteropServices.Optional] object RefDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(description: @"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]", Name = @"[InterestMethod]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(description: @"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]", Name = @"[DayCountConvention]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(description: @"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]", Name = @"[InterpolationMethod]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {

            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(MaturityDate) || ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCSWAP)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Curve YC;
            try
            {
                YC = CreateSwapCurve(YCTenors, YCSWAP, RefDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates maturityDate, refDate;

            if (!ExcelHelper.IsMissing(RefDate))
                refDate = new MyDates((dynamic)RefDate);
            else
                refDate = new MyDates();


            if (!MaturityDate.GetType().IsArray)
            {
                maturityDate = new MyDates((dynamic)MaturityDate);
                maturityDate.SetRefDate(refDate);
                return ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
            }
            else
            {
                object[,] MaturityDateArray = MaturityDate as object[,];

                object[,] output = new object[MaturityDateArray.GetLength(0), MaturityDateArray.GetLength(1)];
                for (int i = 0; i < MaturityDateArray.GetLength(0); i++)
                    for (int j = 0; j < MaturityDateArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(MaturityDateArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                maturityDate = new MyDates((dynamic)MaturityDateArray[i, j]);
                                maturityDate.SetRefDate(refDate);
                                output[i, j] = ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }
        }
        #endregion
        #region CACHE
        /*
        //STATUS: working but not faster at the time being with 1800 calls

        [ExcelFunction(Category = @"SCOR TEST", Description = "Create Interpolator object, test of cache")]
        public static object SCOR_CACHE_CURVE_CREATE(
            [ExcelArgument(Description = "Array of nodes")] double[] x,
            [ExcelArgument(Description = "Array of values")]  double[] y,
            [ExcelArgument(Description = "Interpolation Method = Linear or Natural Cubic Spline")] string InterpolMethod)
        {
            if (!Enum.TryParse(InterpolMethod, out InterpolationMethodType interpolationMethod))
                return ExcelError.ExcelErrorValue;
            else
            {
                return Cache.GlobalCache.CreateHandle(YCTag, new object[] { x, y, interpolationMethod }, (objectType, parameters) =>
                  {
                      Curve YC = null;
                      try
                      {
                          YC = new Curve(x, y);
                      }
                      catch (Exception e)
                      {
                          return e;
                      }

                      if (YC == null)
                          return ExcelError.ExcelErrorNull;
                      else
                          return YC;
                  }
                  );
            }
        }


        [ExcelFunction(Category = @"SCOR TEST", Description = "Evaluate interpolation at specified point")]
        public static object SCOR_CACHE_CURVE_INTERPOLATE(
            [ExcelArgument(Description = "Interpolator object")] string handle,
            [ExcelArgument(Description = "Interpolation point")] double x)
        {
            if (Cache.GlobalCache.TryGetObject(handle, out Curve YC))
            {
                if (YC != null)
                {
                    return ExcelHelper.CheckNaN(YC.ZeroCoupon(x));
                }
            }

            return ExcelError.ExcelErrorRef;
        }




        //END TUTORIAL CACHE
        */
        #endregion
    }
}