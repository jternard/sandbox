﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;
using ExcelDna.Integration;

namespace SCOR_Utils_Addin
{
    [RunInstaller(true)]
    public partial class XLLRegister : Installer
    {
        public XLLRegister()
        {
            InitializeComponent();
        }

        public static void Main()
        {

        }

        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);
            //ExcelIntegration.RegisterXLL();
        }

        public override void Rollback(IDictionary savedState)
        {
            base.Rollback(savedState);
        }

        public override void Uninstall(IDictionary savedState)
        {
            base.Uninstall(savedState);
        }
    }
}
