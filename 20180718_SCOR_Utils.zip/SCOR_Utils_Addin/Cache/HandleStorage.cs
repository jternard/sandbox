﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils_Addin.Cache
{
    class HandleStorage : IDisposable
    {
        private System.Threading.ReaderWriterLockSlim m_lock = new System.Threading.ReaderWriterLockSlim();
        private Dictionary<string, Handle> m_storage = new Dictionary<string, Handle>();
        internal object CreateHandle(string objectType, object[] parameters, Func<string, object[], object> maker)
        {
            return ExcelDna.Integration.ExcelAsyncUtil.Observe(objectType, parameters, () =>
             {
                 var value = maker(objectType, parameters);
                 var handle = new Handle(this, objectType, value);
                 m_lock.EnterWriteLock();
                 try
                 {
                     m_storage.Add(handle.Name, handle);
                 }
                 finally
                 {
                     m_lock.ExitWriteLock();
                 }
                 return handle;
             });
        }

        internal bool TryGetObject<T>(string name, out T value) where T : class
        {
            bool found = false;
            value = default(T);
            m_lock.EnterReadLock();
            try
            {
                if(m_storage.TryGetValue(name, out Handle handle))
                {
                    if(handle.Value is T)
                    {
                        value = handle.Value as T;
                        found = true;
                    }
                }
            }
            finally
            {
                m_lock.ExitReadLock();
            }
            return found;
        }

        internal Tuple<bool, TResult> TryReadObject<T, TResult, TArg>(string name, Func<T, TArg, TResult> reader, TArg argument) where T : class
        {
            bool valid = false;
            TResult result = default(TResult);
            T obj = default(T);
            m_lock.EnterReadLock();
            try
            {
                if(m_storage.TryGetValue(name, out Handle handle))
                {
                    obj = handle.Value as T;
                    if(obj != null)
                    {
                        result = reader(obj, argument);
                        valid = true;
                    }
                }
            }
            finally
            {
                m_lock.ExitReadLock();
            }
            return new Tuple<bool, TResult>(valid, result);
        }

        internal void Remove(Handle handle)
        {
            if(TryGetObject(handle.Name, out object value))
            {
                m_lock.EnterWriteLock();
                try
                {
                    m_storage.Remove(handle.Name);
                }
                finally
                {
                    m_lock.ExitWriteLock();
                }
                if (value is IDisposable disp)
                    disp.Dispose();
            }
        }

        #region implementation of IDisposable
        bool disposed = false;
        Microsoft.Win32.SafeHandles.SafeFileHandle handle = new Microsoft.Win32.SafeHandles.SafeFileHandle(IntPtr.Zero, true);
        public void Dispose()
        { 
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {

            if (disposed)
                return;

            if (disposing)
            {
                m_lock.Dispose();
                handle.Dispose();
            }

            disposed = true;
        }
        #endregion
    }
}
