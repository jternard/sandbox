﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public static class DateHelper
    {
        public static DateTime Today => DateTime.Today;
        public static int NumberOfDays(DateTime startDate, DateTime endDate) => endDate.Subtract(startDate).Days;
        
        public static double YearFraction(DateTime startDate, DateTime endDate, DayCountConventionType dayCountConvention)
        {
            int numDays = NumberOfDays(startDate, endDate); //if 30/360 => numDays = (EndDate.Year - StartDate.Year) * 360 + (EndDate.Month - StartDate.Month) * 30 + (EndDate.Day - StartDate.Day);

            double basis = 0;

            switch (dayCountConvention)
            {
                case DayCountConventionType.ACT_360:
                    basis = 360;
                    break;
                case DayCountConventionType.ACT_365:
                    basis = 365;
                    break;
                case DayCountConventionType.ACT_ACT:
                    if (endDate.Year == startDate.Year)
                        basis = DateTime.IsLeapYear(endDate.Year) ? 366 : 365;
                    else
                    {
                        throw new NotImplementedException("Missing algorithm for ACT/ACT");
                        //basis = 365.25;
                    }
                    break;
                default:
                    throw new NotImplementedException();
            }

            if (basis == 0) throw new NotImplementedException();
            return numDays / basis;
        }

        public static double YearFraction(double startDate, double endDate, DayCountConventionType dayCountConvention)
        {
            return YearFraction(DateTime.FromOADate(startDate), DateTime.FromOADate(endDate), dayCountConvention);
        }

        public static DateTime AddTenor(DateTime referenceDate, int numberPeriods, TenorPeriodType tenorPeriod)
        {
            DateTime output = referenceDate;
            switch (tenorPeriod)
            {
                case TenorPeriodType.D:
                    output = referenceDate.AddDays(numberPeriods);
                    break;
                case TenorPeriodType.W:
                    output = referenceDate.AddDays(numberPeriods * (int)TenorPeriodType.W);
                    break;
                case TenorPeriodType.M:
                    output = referenceDate.AddMonths(numberPeriods);
                    break;
                case TenorPeriodType.Q:
                    output = referenceDate.AddMonths(3 * numberPeriods);
                    break;
                case TenorPeriodType.Y:
                    output = referenceDate.AddYears(numberPeriods);
                    break;
                default:
                    throw new NotImplementedException();
            }

            return output;
        }

        public static DateTime AddTenor(DateTime referenceDate, string tenor)
        {
            int numberPeriods = 0;
            TenorPeriodType tenorPeriod;
            if (tenor.Length < 2)
                throw new ArgumentOutOfRangeException(@"string tenor should have at least 2 characters, e.g. ""3W"" or ""15Y""");
            else
            {
                if (!Enum.TryParse(tenor.Last().ToString(), out tenorPeriod)) throw new ArgumentOutOfRangeException();
                if (!int.TryParse(tenor.Substring(0, tenor.Length - 1), out numberPeriods)) throw new ArgumentOutOfRangeException();
            }

            return AddTenor(referenceDate, numberPeriods, tenorPeriod);
        }
    }
}
