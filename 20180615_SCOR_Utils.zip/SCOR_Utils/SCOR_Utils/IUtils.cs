﻿using System.Runtime.InteropServices;
using System;

namespace SCOR_Utils
{
    [ComVisible(true)]
    [InterfaceType(ComInterfaceType.InterfaceIsDual)]
    [Guid("91514B89-DE8F-451A-B390-25C1E8F42C3E")]
    public interface IUtils
    {
        double Interpolate(object XValues, object YValues, double Xinput, string interpolationMethod);
        //double Interpolate(System.Collections.Generic.Dictionary<double,double> inputDico , double Xinput, string interpolationMethod);
    }
}