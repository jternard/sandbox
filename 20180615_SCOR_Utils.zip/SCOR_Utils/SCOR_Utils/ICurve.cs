﻿using System.Runtime.InteropServices;
namespace SCOR_Utils
{
    [ComVisible(true)]
    [Guid("0764B9ED-8CBC-4D94-8638-283C0EAF18F2")]
    [InterfaceType(ComInterfaceType.InterfaceIsDual)]
    public interface ICurve
    {
        double AsOfDate { get; set; }
        string Currency { get; set; }
        string DayCountConvention { get; set; }
        string Identifier { get; set; }
        string InterestMethod { get; set; }
        string InterpolationMethod { get; set; }

        void AddPoint(double inpX, double inpY);
        double DiscountFactor(double myDate);
        double ForwardRate(double forwardStart, double forwardEnd);
        void RemovePoint(double myDate);
        double YearFraction(double endDate, double startDate = 0);
        double ZeroCoupon(double myDate);
        object ZeroCoupon(object myDates);
    }
}