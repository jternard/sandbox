﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public class FixedBond : Instrument
    {
        public double CouponRate { get; set; }
        public double YTM { get; set; }
        public string CouponFrequency { get; set; } //to replace by ENUM

        public List<Schedule> GetSchedule()
        {
            return _schedule;
        }

        #region Constructors
        public FixedBond(MyDates maturityDate) : base(maturityDate)
        {
            InstrumentType = InstrumentType.BOND_FIXED;
            QuotationType = QuotationType.PERCENT_CLEAN;
            MarketPrice = 100;
        }

        public FixedBond(string maturityTenor) : base(maturityTenor)
        {
            InstrumentType = InstrumentType.BOND_FIXED;
            QuotationType = QuotationType.PERCENT_CLEAN;
            MarketPrice = 100;
        }
        

        public FixedBond(MyDates maturityDate, DateTime asOfDate) : base(maturityDate, asOfDate)
        {
            InstrumentType = InstrumentType.BOND_FIXED;
            QuotationType = QuotationType.PERCENT_CLEAN;
            MarketPrice = 100;
        }

        public double YieldToPrice(double yield = 0)
        {
            return 100;
        }

        public double PriceToYield(double price = 0)
        {
            return CouponRate;
        }

        public double AccruedInterest(DateTime asOfDate = default(DateTime))
        {
            return 0;
        }

        public double ModifiedDuration
        {
            get
            {
                return MaturityDate.GetDate().Subtract(MaturityDate.GetRefDate()).Days;
            }
        }

        public double Convexity
        {
            get
            {
                return Math.Pow(ModifiedDuration,2);
            }
        }

        public double PriceSensitivity(double deltaYTM)
        {
            return -ModifiedDuration * deltaYTM + (0.5 * Convexity * Math.Pow(deltaYTM, 2));
        }

        public DateTime GetNextCouponDate(DateTime asOfDate)
        {
            return new DateTime();
        }

        public DateTime GetLastCouponDate(DateTime asOfDate)
        {
            return new DateTime();
        }


        //Price, Accrued Interest, Yield, Duration, Convexity
        public double[] Pricing(double yield = 0, double price = 0, DateTime asOfDate = default(DateTime))
        {
            return new double[] { 0, 0, 0, 0, 0 };
        }

        #endregion
    }
}
