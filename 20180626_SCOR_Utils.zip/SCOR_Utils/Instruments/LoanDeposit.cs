﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    class LoanDeposit : Instrument
    {
        public LoanDeposit(MyDates maturityDate) : base(maturityDate)
        {
        }

        public LoanDeposit(string maturityTenor) : base(maturityTenor)
        {
        }

        public LoanDeposit(MyDates maturityDate, DateTime asOfDate) : base(maturityDate, asOfDate)
        {
        }

        public LoanDeposit(MyDates maturityDate, double ZC) : base(maturityDate, ZC)
        {
        }

        public LoanDeposit(string forwardTenor, string maturityTenor) : base(forwardTenor, maturityTenor)
        {
        }
    }
}
