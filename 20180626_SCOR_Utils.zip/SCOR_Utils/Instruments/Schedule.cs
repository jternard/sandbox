﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public class Schedule
    {
        MyDates StartDate = new MyDates();
        MyDates EndDate = new MyDates();

        private MyDates _settlementDate;
        public MyDates SettlementDate
        {
            get
            {
                MyDates output = _settlementDate;
                if(_settlementDate == null)
                {
                    output = new MyDates("2D", EndDate); //by default, 2 days settlement lag
                }
                return output;
            }
            set { _settlementDate = value; }
        }


        string Currency;
        double Rate;

        private double _cashflow;
        //public void SetCashFlow(double value) => _cashflow = value;
        //public double GetCashFlow()
        //{
        //    double output = _cashflow;

        //    if(_cashflow == 0)
        //    {
        //        double yf = DateHelper.YearFraction(StartDate, EndDate);
        //        output = yf * Rate;
        //    }
            
        //    return output;
        //}
        
        //If cashflow is 0 (supposedly empty), compute the cashflow
        public double CashFlow
        {
            get
            {
                double output = _cashflow;
                if (_cashflow == 0)
                {
                    double yf = DateHelper.YearFraction(StartDate, EndDate);
                    output = yf * Rate;
                }
                return output;
            }
            set { _cashflow = 0; }
        }

        public double NPV => CashFlow * SettlementDF;

        public double StartDF
        {
            get
            {
                return 1;
            }
        }

        public double EndDF
        {
            get
            {
                return 1;
            }
        }

        public double SettlementDF
        {
            get
            {
                return 1;
            }
        }

        public double StartZC
        {
            get
            {
                return 0;
            }
        }

        public double EndZC
        {
            get
            {
                return 0;
            }
        }

        public double SettlementZC
        {
            get
            {
                return 0;
            }
        }

        public Schedule()
        {

        }
    }
}
