﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    class IRS : Instrument
    {
        public IRS(MyDates maturityDate) : base(maturityDate)
        {
        }

        public IRS(string maturityTenor) : base(maturityTenor)
        {
        }

        public IRS(MyDates maturityDate, DateTime asOfDate) : base(maturityDate, asOfDate)
        {
        }

        public IRS(MyDates maturityDate, double ZC) : base(maturityDate, ZC)
        {
        }

        public IRS(string forwardTenor, string maturityTenor) : base(forwardTenor, maturityTenor)
        {
        }
    }
}
