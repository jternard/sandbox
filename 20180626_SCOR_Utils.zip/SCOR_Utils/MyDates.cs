﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public class MyDates
    {
        private DateTime _date;
        private DateTime _refDate = DateTime.Today;
        private string _tenor = "";
        public string Tenor { get => _tenor; set => _tenor = value.Trim().ToUpper(); }
        public BusinessDayConventionType BusinessDayConvention { get; set; } = BusinessDayConventionType.FOLLOWING;


        public DateTime GetDate()
        {
            if (_date != default(DateTime))
                return _date;
            else
                return DateHelper.AddTenor(GetRefDate(), Tenor, BusinessDayConvention);
        }

        public void SetDate(DateTime value) => _date = value;
        public void SetDate(double value) => _date = DateTime.FromOADate(value);
        

        public DateTime GetRefDate() => _refDate;

        public void SetRefDate(DateTime value) => _refDate = value;
        public void SetRefDate(double value) => _refDate = DateTime.FromOADate(value);



        #region constructors
        public MyDates() { }
        public MyDates(DateTime inputDate) => SetDate(inputDate);
        public MyDates(double inputDateAsDouble) => SetDate(DateTime.FromOADate(inputDateAsDouble));
        public MyDates(string inputTenor) => Tenor = inputTenor.Trim().ToUpper();
        public MyDates(string inputTenor, DateTime inputRefDate)
        {
            Tenor = inputTenor.Trim().ToUpper();
            SetRefDate(inputRefDate);
        }
        public MyDates(string inputTenor, double inputRefDateAsDouble)
        {
            Tenor = inputTenor.Trim().ToUpper();
            SetRefDate(DateTime.FromOADate(inputRefDateAsDouble));
        }
        #endregion

        #region conversions and casting
        public static explicit operator double(MyDates d)
        {
            double output = 0;

            DateTime tmpDate = d.GetDate();
            if (tmpDate != null)
                output = d.GetDate().ToOADate();

            return output;
        }

        public static explicit operator MyDates(double d) => new MyDates(DateTime.FromOADate(d));

        public static explicit operator string(MyDates d)
        {
            string output = string.Empty;
            
            DateTime tmpDate = d.GetDate();
            if (tmpDate != null)
                output = d.GetDate().ToShortDateString();
            
            return output;
        }

        public static implicit operator DateTime(MyDates d)
        {
            DateTime output = d.GetDate();
            return output == null ? default(DateTime) : output;
        }

        public static implicit operator MyDates(DateTime d) => new MyDates(d);


        public TypeCode GetTypeCode() => TypeCode.Object;

        #endregion
    }
}
