﻿using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.IO;

//Taken from: https://devdump.wordpress.com/2009/01/17/setup-project-custom-actions/
//More information at: http://vbcity.com/forums/t/145818.aspx (page 2 at: http://vbcity.com/forums/t/146284.aspx)

namespace SCOR_Utils
{
    [RunInstaller(true)]
    [System.Runtime.InteropServices.ComVisible(false)]
    [System.Runtime.InteropServices.ClassInterface(System.Runtime.InteropServices.ClassInterfaceType.None)]
    public partial class RegasmInstaller : Installer
    {
        public RegasmInstaller()
        {
            InitializeComponent();
        }

        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);
            Regasm(true);

            try
            {
                string installFolder = stateSaver["TargetDir"].ToString();
                LogWrite(installFolder, "log.txt", "Started Installing");

                LogWrite(installFolder, "log.txt", "Started registering the dll");
                //Regasm(true);
            }
            catch
            {

            }
        }

        public override void Rollback(IDictionary savedState)
        {
            base.Rollback(savedState);
            Regasm(false);

            try
            {
                string installFolder = savedState["TargetDir"].ToString();
                LogWrite(installFolder, "log.txt", "Started Rolling Back");

                LogWrite(installFolder, "log.txt", "Started unregistering the dll");
                //Regasm(false);
            }
            catch
            {

            }
        }

        public override void Uninstall(IDictionary savedState)
        {
            base.Uninstall(savedState);
            Regasm(false);

            try
            {
                string installFolder = savedState["TargetDir"].ToString();
                LogWrite(installFolder, "log.txt", "Started Uninstalling");

                LogWrite(installFolder, "log.txt", "Started unregistering the dll");
                //Regasm(false);

                LogWrite(installFolder, "log.txt", "Started cleaning the output folder");
                CleanFolder(installFolder);
            }
            catch
            {

            }
            
        }

        private void Regasm(bool register)
        {
            //foreach (string keys in base.Context.Parameters.Keys)
            //    Console.WriteLine(keys + " : " + base.Context.Parameters[keys]);

            string file = base.Context.Parameters["Assembly"];

            if (string.IsNullOrEmpty(file))
                throw new InstallException("Assembly not defined in AssemblyInfo.cs");

            if (!File.Exists(file))
                return;

            System.Runtime.InteropServices.RegistrationServices regsrv = new System.Runtime.InteropServices.RegistrationServices();
            System.Reflection.Assembly assembly = System.Reflection.Assembly.LoadFrom(file);

            if (register)
            {

                regsrv.RegisterAssembly(assembly, System.Runtime.InteropServices.AssemblyRegistrationFlags.SetCodeBase);
            }
            else
            {
                try
                {
                    regsrv.UnregisterAssembly(assembly);
                }
                catch
                {

                }
            }
        }

        private void CleanFolder(string installFolder)
        {

            if (!Directory.Exists(installFolder))
                return;

            foreach(string filePath in Directory.GetFiles(installFolder))
                File.Delete(filePath);

            return;
        }

        public static void Main()
        {
            //Console.WriteLine("Test Installer");
        }

        private void LogWrite(string installFolder, string logFile, string messageLog)
        {
            if (!Directory.Exists(installFolder))
                return;

            if (!File.Exists(Path.Combine(installFolder, logFile)))
                return;

            using (StreamWriter myLogFile = new StreamWriter(Path.Combine(installFolder, logFile), true))
            {
                if (myLogFile == StreamWriter.Null)
                    return;
                myLogFile.WriteLine(messageLog);
                myLogFile.Flush();
                //myLogFile.Close();
            }
        }
    }
}
