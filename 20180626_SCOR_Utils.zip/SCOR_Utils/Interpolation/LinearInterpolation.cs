﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils.Interpolation
{
    public class LinearInterpolation : Interpolator
    {
        public LinearInterpolation(double[,] inpSeries) : base(inpSeries)
        {
        }

        public LinearInterpolation(Dictionary<double, double> inpSeries) : base(inpSeries)
        {
        }

        public LinearInterpolation(double[] inpX, double[] inpY) : base(inpX, inpY)
        {
        }

        public LinearInterpolation(List<double> inpX, List<double> inpY) : base(inpX, inpY)
        {
        }

        public override double Interpolate(double X)
        {
            //boundaries => output the boundary element (no extrapolation)
            if (X <= GetSeriesX.First()) return GetSeriesY.First();
            if (X >= GetSeriesX.Last()) return GetSeriesY.Last();

            //existing element => output the corresponding Y element
            int foundElementIndex = GetSeriesX.FindIndex(x => x == X);
            if (foundElementIndex != -1) return GetSeriesY[foundElementIndex];

            int prevElementIndex = FindPreviousIndex(X);
            int nextElementIndex = prevElementIndex + 1;

            double prevElementX = GetSeriesX[prevElementIndex];
            double nextElementX = GetSeriesX[nextElementIndex];
            double prevElementY = GetSeriesY[prevElementIndex];
            double nextElementY = GetSeriesY[nextElementIndex];

            return prevElementY + (nextElementY - prevElementY) * (X - prevElementX) / (nextElementX - prevElementX);
        }
    }
}
