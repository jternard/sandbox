﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SCOR_Utils
{
    public abstract class Interpolator
    {
        protected List<double> _seriesX = new List<double>();
        public List<double> GetSeriesX => _seriesX;
        protected void SetSeriesX(List<double> inpX) => _seriesX = inpX;
        protected void SetSeriesX(double[] inpX) => SetSeriesX(inpX.ToList());

        protected List<double> _seriesY;
        public List<double> GetSeriesY => _seriesY;
        protected void SetSeriesY(List<double> inpY) => _seriesY = inpY;
        protected void SetSeriesY(double[] inpY) => SetSeriesY(inpY.ToList());

        public void SetSeries(SortedDictionary<double,double> inpDictionary)
        {
            SetSeriesX(inpDictionary.Keys.ToList());
            SetSeriesY(inpDictionary.Values.ToList());
        }

        public void SetSeries(Dictionary<double, double> inpDictionary) => SetSeries(new SortedDictionary<double, double>(inpDictionary));

        public void SetSeries(List<double> inpX, List<double> inpY)
        {
            SetSeries(new Dictionary<double, double>(inpX.Zip(inpY, (x, y) => new { Key = x, Value = y }).ToDictionary(x => x.Key, x => x.Value)));
        }

        public void SetSeries(double[] inpX, double[] inpY) => SetSeries(inpX.ToList(), inpY.ToList());

        public Interpolator(double[] inpX, double[] inpY)
        {
            if (inpX == null || inpY == null) throw new ArgumentNullException();
            if (inpX.Length != inpY.Length) throw new ArgumentOutOfRangeException();
            SetSeries(inpX, inpY);
        }

        public Interpolator(double[,] inpSeries)
        {
            if(inpSeries == null) throw new ArgumentNullException();
            if (Math.Min(inpSeries.GetLength(0), inpSeries.GetLength(1)) > 2) throw new ArgumentOutOfRangeException();

            MatrixToArrays(inpSeries, out double[] inpX, out double[] inpY);
            SetSeries(inpX, inpY);
        }

        public Interpolator(Dictionary<double,double> inpSeries)
        {
            if (inpSeries == null) throw new ArgumentNullException();
            if (inpSeries.Count == 0) throw new ArgumentOutOfRangeException();
            SetSeries(inpSeries);
        }

        public Interpolator(List<double> inpX, List<double> inpY)
        {
            if (inpX == null || inpY == null) throw new ArgumentNullException();
            if (inpX.Count != inpY.Count) throw new ArgumentOutOfRangeException();
            SetSeries(inpX, inpY);
        }

        protected void MatrixToArrays(double[,] inpSeries, out double[] inpX, out double[] inpY)
        {
            int arrayLength = Math.Max(inpSeries.GetLength(0), inpSeries.GetLength(1));
            inpX = new double[arrayLength];
            inpY = new double[arrayLength];

            if (inpSeries.GetLength(0) == 2)
                for(int i = 0; i < arrayLength; i++)
                {
                    inpX[i] = inpSeries[0, i];
                    inpY[i] = inpSeries[1, i];
                }
            else
                for (int i = 0; i < arrayLength; i++)
                {
                    inpX[i] = inpSeries[i, 0];
                    inpY[i] = inpSeries[i, 1];
                }
        }

        protected int FindPreviousIndex(double X)
        {
            int prevElementIndex = 0;
            if (X >= GetSeriesX.First())
                prevElementIndex = GetSeriesX.FindLastIndex(x => x <= X);
            return prevElementIndex;
        }

        public abstract double Interpolate(double X);
        //public abstract double[] Interpolate(double[] X);
        public double[] Interpolate(double[] X)
        {
            if (X == null) throw new ArgumentNullException();

            double[] output = new double[X.Length];
            for (int i = 0; i < X.Length; i++)
                output[i] = Interpolate(X[i]);

            return output;
        }

        //int foundElementIndex = -1;
        //foundElementIndex = GetSeriesX.FindIndex(x => x == X);
        //    if(foundElementIndex != -1) return GetSeriesY[foundElementIndex];

        //    return 0;
    }
}
