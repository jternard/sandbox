﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDna.Integration;
using Microsoft.Office.Interop.Excel;

namespace SCOR_Utils_Addin
{
    internal static class ExcelHelper
    {
        internal static object CheckNaN(double value)
        {
            return (Double.IsNaN(value) || Double.IsInfinity(value)) ? ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNA) : value;
        }

        internal static T CheckValue<T>(object value, T defaultValue) where T : struct
        {
            return (value is T) ? (T)value : defaultValue;
        }

        internal static bool IsMissing(object arg)
        {
            return (arg.GetType() == typeof(ExcelMissing) || arg.GetType() == typeof(ExcelEmpty) || arg.GetType() == typeof(ExcelError));
        }

        //from 1 dimensional (a row vector in Excel) to 2 dimensionals with second dimension always 1 (a column vector in Excel)
        internal static object Transpose(object[] value)
        {
            if (value == null) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            object[,] output = new object[value.Length, 1];
            for (int i = 0; i < value.Length; i++)
                output[i, 0] = value[i];
            return output;
        }

        internal static object[,] Transpose(object[,] value)
        {
            if (value == null) throw new ArgumentNullException(); //return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            ////to transform into a single dimensional array
            //if(value.Length == Math.Max(value.GetLength(0), value.GetLength(1)))
            //{
            //    object[] output = new object[value.Length];

            //    if (value.GetLength(0) == 1)
            //        for (int i = 0; i < value.GetLength(1); i++)
            //            output[i] = value[0, i];
            //    else
            //        for (int i = 0; i < value.GetLength(0); i++)
            //            output[i] = value[i, 0];

            //    return output;
            //}
            //else
            //{
                object[,] output = new object[value.GetLength(1), value.GetLength(0)];
                for (int i = 0; i < value.GetLength(1); i++)
                    for (int j = 0; j < value.GetLength(0); j++)
                        output[i, j] = value[j, i];

                return output;
            //}
        }

        //internal static Range CallingRange(ExcelReference xlref) //xlref will be "XlCall.xlfCaller" in the calling function
        //{
        //    string refText = XlCall.Excel(XlCall.xlfReftext, xlref, true).ToString();
        //    dynamic app = ExcelDnaUtil.Application;
        //    return app?.Range[refText];
        //}

        //internal static object FormatOutput(object output, params object[] inputParams)
        //{
        //    //if output is null, return an error to Excel
        //    if (output == null) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNA);

        //    //if inputParams is null, return output
        //    if (inputParams == null) return output;

        //    //if output is a singleton, no matter the size of the relevant inputs, output the singleton (Excel should populate the cells as needed)
        //    if (!output.GetType().IsArray)
        //        return output;
        //    else
        //    {
        //        object[] outputArray = (object[])(Array)output;

        //        //if output is an array, with different dimensions than the number of relevant inputs, return the array output
        //        if (outputArray.Rank != inputParams.Length)
        //            return outputArray;
        //        else
        //            //if output is an array, with same dimensions as the number of relevant inputs, then 
        //            return null;
        //    }
        //    return null;
        //}
    }
}
