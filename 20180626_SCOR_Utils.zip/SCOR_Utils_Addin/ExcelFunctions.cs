﻿using System;
using System.Collections.Generic;
using System.Linq;
using ExcelDna.Integration;
using Excel = Microsoft.Office.Interop.Excel;
using IntelliSense = ExcelDna.IntelliSense;
using SCOR_Utils;
/*
To Test/Debug:
    Set global parameters to Debug and x64
    Set the projects to Active / Any CPU
    Open the addin with the loaded Excel file

To publish:
    Set global parameters to Release and x64
    Set the projects to Active / Any CPU
    Then Sign the resulting packed x64 xll file which can be distributed

To install:
    Users need only to load the xll from anywhere on the network or their computers
    It might be necessary to have an admin to validate the certificate

 
missing arguments are of type ExcelMissing
cache: https://www.codeproject.com/Articles/1097174/Interpolation-in-Excel-using-Excel-DNA

determining the calling cells: C API with xlfCaller option (https://social.msdn.microsoft.com/Forums/office/en-US/678c303c-aec9-4845-a4c1-1d15e0782659/xll-determines-the-activecell-in-custom-function?forum=exceldev)
C API is more or less the ExcelDna.Integration.ExcelReference: https://stackoverflow.com/questions/31038649/passing-an-excel-range-from-vba-to-c-sharp-via-excel-dna

Deployment:
    Remember to change the name of the embedded dll path in this add-in.dna
    Potentially with Installer class: https://github.com/Excel-DNA/WiXInstaller/blob/master/Source/InstallerCA/InstallerClass.cs
    Also related: https://stackoverflow.com/questions/18602560/how-to-deploy-an-excel-xll-add-in-and-automatically-register-the-add-in-in-excel
     */

namespace SCOR_Utils_Addin
{
    //class was static
    //class didn't implement IExcelAddin Interface
    public class ExcelFunctions : IExcelAddIn
    {

        //private static readonly string YCTag = @"#YC";
        #region IExcelAddin implementation
        public void AutoOpen()
        {
            IntelliSense.IntelliSenseServer.Register();
        }

        public void AutoClose()
        {

        }
        #endregion


        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Interpolation method implementing linear or natural cubic spline methods",HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_INTERPOLATE(
            [ExcelArgument(@"Point to interpolate. X as Double or Double()")] object X, 
            [ExcelArgument(@"InpX as Double()")] object InpX,
            [ExcelArgument(@"InpY as Double()")] object InpY,
            [ExcelArgument(@"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]")][System.Runtime.InteropServices.Optional] object interpolMethod
            )
        {

            if (ExcelHelper.IsMissing(X) || ExcelHelper.IsMissing(InpX) || ExcelHelper.IsMissing(InpY)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            if (!InpX.GetType().IsArray || !InpY.GetType().IsArray) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Interpolator interpolator;

            InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            if (!ExcelHelper.IsMissing(interpolMethod))
            {
                if (!Enum.TryParse(interpolMethod.ToString(), true, out interpolationMethod))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            try
            {
                //treatment of the input. From implicit object[,] to List<object>, then to List<double> for non missing elements in both lists
                List<object> InpXList = ((Array)InpX).Cast<object>().ToList();
                List<object> InpYList = ((Array)InpY).Cast<object>().ToList();

                if (InpXList.Count != InpYList.Count) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                List<double> inpX = new List<double>();
                List<double> inpY = new List<double>();

                for (int i = 0; i < InpXList.Count; i++)
                    if (!ExcelHelper.IsMissing(InpXList[i]) && !ExcelHelper.IsMissing(InpYList[i]))
                        if(InpXList[i].ToString() != string.Empty && InpYList[i].ToString() != string.Empty)
                        {
                            inpX.Add((double)InpXList[i]);
                            inpY.Add((double)InpYList[i]);
                        }
                
                switch (interpolationMethod)
                {
                    case InterpolationMethodType.LINEAR:
                        interpolator = new SCOR_Utils.Interpolation.LinearInterpolation(inpX.Cast<double>().ToArray(), inpY.Cast<double>().ToArray());
                        break;
                    case InterpolationMethodType.NATURAL_CUBIC_SPLINE:
                        interpolator = new SCOR_Utils.Interpolation.NaturalCubicSplineInterpolation(inpX.Cast<double>().ToArray(), inpY.Cast<double>().ToArray());
                        break;
                    default:
                        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                }
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            
            double x;

            if (!X.GetType().IsArray)
            {
                if(X.ToString() == string.Empty)
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                x = (double)X;
                return ExcelHelper.CheckNaN(interpolator.Interpolate(x));
            }
            else
            {
                object[,] XArray = (object[,])X;
                object[,] output = new object[XArray.GetLength(0), XArray.GetLength(1)];

                for (int i = 0; i < XArray.GetLength(0); i++)
                    for (int j = 0; j < XArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(XArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else if(XArray[i, j].ToString() == string.Empty)
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                x = (double)XArray[i, j];
                                output[i, j] = ExcelHelper.CheckNaN(interpolator.Interpolate(x));
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }

            #region Shaping to calling range
            //var caller = XlCall.Excel(XlCall.xlfCaller) as ExcelReference;
            //object[,] outputExcel = new object[caller.RowLast - caller.RowFirst + 1, caller.ColumnLast - caller.ColumnFirst + 1];
            //if (outputExcel.GetLength(0) == 1)
            //{
            //    for (int i = 0; i < Math.Min(outputExcel.GetLength(1),result.Length); i++)
            //        outputExcel.SetValue(ExcelHelper.CheckNaN((double)result[i]), 0, i);
            //}
            //else
            //{
            //    for (int i = 0; i < Math.Min(outputExcel.GetLength(0), result.Length); i++)
            //        outputExcel.SetValue(ExcelHelper.CheckNaN((double)result[i]), i, 0);
            //}

            //return outputExcel;
            #endregion
        }


        //NOTE: to improve depending on the user input such as a 3x2 output with 3 startdate and 2 enddate, or a a list of StartDate and 1 EndDate
        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Forward Rate applicable between the startDate and endDate, based on the curve labeled as YCidentifier. This curve has to already exist in the cache.", HelpTopic = @"https://en.wikipedia.org/wiki/Forward_rate", IsThreadSafe = true)]
        public static object SCOR_FWD(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object StartDate,
            [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"". Tenors start from the Start Date.)")] object EndDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(@"[Optional: AsOfDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"") = Today]")][System.Runtime.InteropServices.Optional] object AsOfDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(@"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(StartDate) || ExcelHelper.IsMissing(EndDate)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Curve YC;
            try
            {
                YC = CreateCurve(YCTenors, YCZC, AsOfDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates refDate = new MyDates();
            if (!ExcelHelper.IsMissing(AsOfDate))
                refDate.SetDate((dynamic)AsOfDate);


            MyDates startDate, endDate;

            //if both are singleton, then output the result
            if (!StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            {
                if(StartDate.ToString() == string.Empty || EndDate.ToString() == string.Empty) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                startDate = new MyDates((dynamic)StartDate);
                startDate.SetRefDate(refDate);

                if (EndDate.GetType() == typeof(string))
                    endDate = new MyDates((dynamic)EndDate, startDate);
                else
                {
                    endDate = new MyDates((dynamic)EndDate);
                    endDate.SetRefDate(refDate);
                }

                return ExcelHelper.CheckNaN(YC.ForwardRate(startDate, endDate));
            }
            //one of the 2 inputs at least is an array
            else
            {
                int dimension0 = 0, dimension1 = 0;
                object[,] StartDateArray, EndDateArray;
                //if one of the 2 inputs is an array and the other not, then transform the one not an array into an array
                if (StartDate.GetType().IsArray != EndDate.GetType().IsArray)
                {
                    //StartDate is an array, but EndDate is not
                    if (StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
                    {
                        StartDateArray = (object[,])StartDate;

                        dimension0 = StartDateArray.GetLength(0);
                        dimension1 = StartDateArray.GetLength(1);

                        EndDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                EndDateArray[i, j] = EndDate;                
                    }
                    //StartDate is not an array, EndDate is an array
                    else
                    {
                        EndDateArray = (object[,])EndDate;

                        dimension0 = EndDateArray.GetLength(0);
                        dimension1 = EndDateArray.GetLength(1);

                        StartDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                StartDateArray[i, j] = StartDate;
                    }
                }
                //if both inputs are arrays
                else
                {
                    StartDateArray = (object[,])StartDate;
                    EndDateArray = (object[,])EndDate;
                    dimension0 = Math.Max(StartDateArray.GetLength(0), EndDateArray.GetLength(0));
                    dimension1 = Math.Max(StartDateArray.GetLength(1), EndDateArray.GetLength(1));
                }

                //normal case, both are arrays:
                object[,] output = new object[dimension0, dimension1];

                //if the arrays have the same shape, possibility to optimise, O(n)
                if(StartDateArray.GetLength(0) == EndDateArray.GetLength(0) || StartDateArray.GetLength(1) == EndDateArray.GetLength(1))
                {
                    for (int i = 0; i < dimension0; i++)
                        for (int j = 0; j < dimension1; j++)
                            try
                            {
                                if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[i, j]))
                                    output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                else if (StartDateArray[i, j].ToString() == string.Empty || EndDateArray[i, j].ToString() == string.Empty)
                                    output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                else
                                {
                                    startDate = new MyDates((dynamic)StartDateArray[i, j]);
                                    startDate.SetRefDate(refDate);

                                    endDate = new MyDates((dynamic)EndDateArray[i, j]);
                                    if (EndDateArray[i, j].GetType() == typeof(string))
                                        endDate = new MyDates((string)EndDateArray[i, j], startDate);
                                    else
                                    {
                                        endDate = new MyDates((dynamic)EndDateArray[i, j]);
                                        endDate.SetRefDate(refDate);
                                    }

                                    output[i, j] = ExcelHelper.CheckNaN(YC.ForwardRate(startDate, endDate));
                                }
                            }
                            catch
                            {
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            }
                }
                else
                {
                    //to be optimised, O(n2)
                    //to be used if the 2 inputs are of different shape/orientation (row vs column)
                    for (int i = 0; i < StartDateArray.GetLength(0); i++)
                        for (int j = 0; j < StartDateArray.GetLength(1); j++)
                            for (int k = 0; k < EndDateArray.GetLength(0); k++)
                                for (int l = 0; l < EndDateArray.GetLength(1); l++)
                                    try
                                    {
                                        if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[k, l]))
                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                        else if (StartDateArray[i, j].ToString() == string.Empty || EndDateArray[k, l].ToString() == string.Empty)
                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                        else
                                        {
                                            startDate = new MyDates((dynamic)StartDateArray[i, j]);
                                            startDate.SetRefDate(refDate);

                                            if (EndDateArray[k, l].GetType() == typeof(string))
                                                endDate = new MyDates((dynamic)EndDateArray[k, l], startDate);
                                            else
                                            {
                                                endDate = new MyDates((dynamic)EndDateArray[k, l]);
                                                endDate.SetRefDate(refDate);
                                            }

                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelHelper.CheckNaN(YC.ForwardRate(startDate, endDate));
                                        }
                                    }
                                    catch
                                    {
                                        output[Math.Max(i, k), Math.Max(j, l)] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                    }
                }
                return output;
            }

            #region deprecated
            //MyDates startDate, endDate;
            //List<dynamic> TenorList, ZCList;
            //try
            //{
            //    startDate = new MyDates((dynamic)StartDate);
            //    endDate = new MyDates((dynamic)EndDate);
            //    TenorList = (YCTenors.GetType().IsCOMObject ? (Array)((Excel.Range)YCTenors).Value2 : (Array)YCTenors).Cast<object>().ToList();
            //    ZCList = (YCZC.GetType().IsCOMObject ? (Array)((Excel.Range)YCZC).Value2 : (Array)YCZC).Cast<object>().ToList();
            //}
            //catch
            //{
            //    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}

            //Dictionary<double, double> curvePoints;

            //if (ZCList.TrueForAll(x => !ExcelHelper.IsMissing(x)) && TenorList.TrueForAll(x => !ExcelHelper.IsMissing(x)))
            //    curvePoints = new Dictionary<double, double>(TenorList.Cast<double>().Zip(ZCList.Cast<double>(), (tenor, zc) => new { Key = tenor, Value = zc }).ToDictionary(x => x.Key, x => x.Value));
            //else
            //{
            //    curvePoints = new Dictionary<double, double>();
            //    for (int i = 0; i < TenorList.Count; i++)
            //    {
            //        if (!ExcelHelper.IsMissing(TenorList[i]) && !ExcelHelper.IsMissing(ZCList[i]))
            //            curvePoints.Add(TenorList[i], ZCList[i]);
            //    }
            //}


            //Curve YC = new Curve(curvePoints);

            //if (YC == null)
            //    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorNA);

            //if (!ExcelHelper.IsMissing(AsOfDate))
            //{
            //    startDate.SetRefDate((dynamic)AsOfDate);
            //    endDate.SetRefDate((dynamic)AsOfDate);
            //    YC.AsOfDate = new MyDates((dynamic)AsOfDate);
            //}

            ////if (!ExcelHelper.IsMissing(Currency))
            ////    YC.Currency = Currency.ToString();


            //InterestMethodType interestMethod = InterestMethodType.COMPOUNDING_DISCRETE;
            //if (!ExcelHelper.IsMissing(InterestMethod))
            //{
            //    if (!Enum.TryParse(InterestMethod.ToString(), true, out interestMethod))
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}
            //YC.InterestMethod = interestMethod;

            //DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            //if (!ExcelHelper.IsMissing(DayCountConvention))
            //{
            //    if (!Enum.TryParse(DayCountConvention.ToString(), true, out dayCountConvention))
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}
            //YC.DayCountConvention = dayCountConvention;

            //InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            //if (!ExcelHelper.IsMissing(DayCountConvention))
            //{
            //    if (!Enum.TryParse(InterpolMethod.ToString(), true, out interpolationMethod))
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //}
            //YC.InterpolationMethod = interpolationMethod;



            //return ExcelHelper.CheckNaN(YC.ForwardRate((double)startDate, (double)endDate));

            //throw new NotImplementedException();
            #endregion
        }


        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Zero Coupon applicable at the input Maturity, based on the curve labeled as YCidentifier", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_ZC(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(@"[Optional: AsOfDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"") = Today]")][System.Runtime.InteropServices.Optional] object AsOfDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(@"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {

            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(MaturityDate)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            Curve YC;
            try
            {
                YC = CreateCurve(YCTenors, YCZC, AsOfDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates maturityDate;

            if (!MaturityDate.GetType().IsArray)
            {
                if (MaturityDate.ToString() == string.Empty) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                maturityDate = new MyDates((dynamic)MaturityDate);
                if (!ExcelHelper.IsMissing(AsOfDate))
                    maturityDate.SetRefDate((dynamic)AsOfDate);
                return ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
            }
            else
            {
                object[,] MaturityDateArray = (object[,])MaturityDate;

                object[,] output = new object[MaturityDateArray.GetLength(0), MaturityDateArray.GetLength(1)];
                for (int i = 0; i < MaturityDateArray.GetLength(0); i++)
                    for (int j = 0; j < MaturityDateArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(MaturityDateArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else if (MaturityDateArray[i, j].ToString() == string.Empty)
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                maturityDate = new MyDates((dynamic)MaturityDateArray[i, j]);
                                output[i, j] = ExcelHelper.CheckNaN(YC.ZeroCoupon(maturityDate));
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }            
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Retrieves the Discount Factor applicable at the input Maturity, based on the curve labeled as YCidentifier", HelpTopic = @"https://en.wikipedia.org/wiki/Interpolation", IsThreadSafe = true)]
        public static object SCOR_DF(
            [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object MaturityDate,
            [ExcelArgument(@"YCTenors as Double()")] object YCTenors, //for test
            [ExcelArgument(@"YCZC as Double()")] object YCZC, //for test
            //[ExcelArgument(@"YCidentifier as string (Name of an existing curve)")] string YCidentifier,
            //[ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT/360""]")][System.Runtime.InteropServices.Optional] string DayCountConvention)
            [ExcelArgument(@"[Optional: AsOfDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"") = Today]")][System.Runtime.InteropServices.Optional] object AsOfDate,
            //[ExcelArgument(@"[Optional: Currency as String = """"]")][System.Runtime.InteropServices.Optional] object Currency,
            [ExcelArgument(@"[Optional: InterestMethod as String = ""COMPOUNDING_DISCRETE"" (""BULLET"", ""COMPOUNDING_DISCRETE"", ""COMPOUNDING_CONTINUOUS"")]")][System.Runtime.InteropServices.Optional] object InterestMethod,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(@"[Optional: InterpolationMethod as String = ""LINEAR"" (""LINEAR"", ""NATURAL_CUBIC_SPLINE"")]")][System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            //if mandatory inputs are missing, exit
            if (ExcelHelper.IsMissing(MaturityDate)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            
            Curve YC;
            try
            {
                YC = CreateCurve(YCTenors, YCZC, AsOfDate, InterestMethod, DayCountConvention, InterpolMethod);
            }
            catch
            {
                return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            }

            MyDates maturityDate;

            if (!MaturityDate.GetType().IsArray)
            {
                try
                {
                    if (MaturityDate.ToString() == string.Empty) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                    maturityDate = new MyDates((dynamic)MaturityDate);
                    if (!ExcelHelper.IsMissing(AsOfDate))
                        maturityDate.SetRefDate((dynamic)AsOfDate);
                    return ExcelHelper.CheckNaN(YC.DiscountFactor(maturityDate));
                }
                catch
                {
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                }

            }
            else
            {
                object[,] MaturityDateArray = (object[,])MaturityDate;
                //object[] MaturityDateArray = (MaturityDate.GetType().IsCOMObject ? (Array)((Excel.Range)MaturityDate).Value2 : (Array)MaturityDate).Cast<object>().ToArray();

                object[,] output = new object[MaturityDateArray.GetLength(0), MaturityDateArray.GetLength(1)];
                for (int i = 0; i < MaturityDateArray.GetLength(0); i++)
                    for (int j = 0; j < MaturityDateArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(MaturityDateArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else if(MaturityDateArray[i, j].ToString() == string.Empty)
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                maturityDate = new MyDates((dynamic)MaturityDateArray[i, j]);
                                output[i, j] = ExcelHelper.CheckNaN(YC.DiscountFactor(maturityDate));
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Year Fraction between two dates.", HelpTopic = @"https://en.wikipedia.org/wiki/Day_count_convention", IsThreadSafe = true)]
        public static object SCOR_YF(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object StartDate,
            [ExcelArgument(@"EndDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object EndDate,
            [ExcelArgument(@"[Optional: DayCountConvention as String = ""ACT_360"" (""ACT_360"", ""ACT_365"", ""ACT_ACT"", ""_30_360"", ""_30E_360"")]")][System.Runtime.InteropServices.Optional] object DayCountConvention,
            [ExcelArgument(@"[Optional: RefDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")]")][System.Runtime.InteropServices.Optional] object RefDate,
            [ExcelArgument(@"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention
            )
        {

            if(ExcelHelper.IsMissing(StartDate) || ExcelHelper.IsMissing(EndDate)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            
            DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            if (!ExcelHelper.IsMissing(DayCountConvention))
                if (!Enum.TryParse(DayCountConvention.ToString(),true, out dayCountConvention))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            BusinessDayConventionType businessDayConv = BusinessDayConventionType.FOLLOWING;
            if (!ExcelHelper.IsMissing(BusinessDayConvention))
                if (!Enum.TryParse(BusinessDayConvention.ToString(), true, out businessDayConv))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            MyDates refDate = new MyDates();
            if (!ExcelHelper.IsMissing(RefDate))
                refDate.SetDate((dynamic)RefDate);


            MyDates startDate, endDate;

            //if both are singleton, then output the result
            if (!StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            {
                if (StartDate.ToString() == string.Empty || EndDate.ToString() == string.Empty) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                startDate = new MyDates((dynamic)StartDate);
                startDate.BusinessDayConvention = businessDayConv;
                startDate.SetRefDate(refDate);


                if (EndDate.GetType() == typeof(string))
                    endDate = new MyDates((string)EndDate, startDate);
                else
                {
                    endDate = new MyDates((dynamic)EndDate);
                    endDate.SetRefDate(refDate);
                }     
                endDate.BusinessDayConvention = businessDayConv;

                return ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            }
            //one of the 2 inputs at least is an array
            else
            {
                int dimension0 = 0, dimension1 = 0;
                object[,] StartDateArray, EndDateArray;
                //if one of the 2 inputs is an array and the other not, then transform the one not an array into an array
                if (StartDate.GetType().IsArray != EndDate.GetType().IsArray)
                {
                    //StartDate is an array, but EndDate is not
                    if (StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
                    {
                        StartDateArray = (object[,])StartDate;

                        dimension0 = StartDateArray.GetLength(0);
                        dimension1 = StartDateArray.GetLength(1);

                        EndDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                EndDateArray[i, j] = EndDate;                      
                    }
                    //StartDate is not an array, EndDate is an array
                    else
                    {
                        EndDateArray = (object[,])EndDate;

                        dimension0 = EndDateArray.GetLength(0);
                        dimension1 = EndDateArray.GetLength(1);

                        StartDateArray = new object[dimension0, dimension1];
                        for (int i = 0; i < dimension0; i++)
                            for (int j = 0; j < dimension1; j++)
                                StartDateArray[i, j] = StartDate;
                    }
                }
                //if both inputs are arrays
                else
                {
                    StartDateArray = (object[,])StartDate;
                    EndDateArray = (object[,])EndDate;
                    dimension0 = Math.Max(StartDateArray.GetLength(0), EndDateArray.GetLength(0));
                    dimension1 = Math.Max(StartDateArray.GetLength(1), EndDateArray.GetLength(1));
                }

                //normal case, both are arrays:
                object[,] output = new object[dimension0, dimension1];

                //if the arrays have the same shape, possibility to optimise, O(n)
                if (StartDateArray.GetLength(0) == EndDateArray.GetLength(0) || StartDateArray.GetLength(1) == EndDateArray.GetLength(1))
                {
                    for (int i = 0; i < dimension0; i++)
                        for (int j = 0; j < dimension1; j++)
                        {
                            try
                            {
                                if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[i, j]))
                                    output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                else
                                {
                                    if (StartDateArray[i, j].ToString() == string.Empty || EndDateArray[i, j].ToString() == string.Empty)
                                        output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                                    startDate = new MyDates((dynamic)StartDateArray[i, j]);
                                    startDate.BusinessDayConvention = businessDayConv;
                                    startDate.SetRefDate(refDate);


                                    if (EndDateArray[i, j].GetType() == typeof(string))
                                        endDate = new MyDates((string)EndDateArray[i, j], startDate);
                                    else
                                    {
                                        endDate = new MyDates((dynamic)EndDateArray[i, j]);
                                        endDate.SetRefDate(refDate);
                                    }
                                    endDate.BusinessDayConvention = businessDayConv;

                                    output[i, j] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
                                }
                            }
                            catch
                            {
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            }
                        }
                }
                else
                {
                    //to be optimised, O(n2)
                    //to be used if the 2 inputs are of different shape/orientation (row vs column)
                    for (int i = 0; i < StartDateArray.GetLength(0); i++)
                        for (int j = 0; j < StartDateArray.GetLength(1); j++)
                            for (int k = 0; k < EndDateArray.GetLength(0); k++)
                                for (int l = 0; l < EndDateArray.GetLength(1); l++)
                                {
                                    try
                                    {
                                        if (ExcelHelper.IsMissing(StartDateArray[i, j]) || ExcelHelper.IsMissing(EndDateArray[k, l]))
                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                        else
                                        {
                                            if (StartDateArray[i, j].ToString() == string.Empty || EndDateArray[i, j].ToString() == string.Empty)
                                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                                            startDate = new MyDates((dynamic)StartDateArray[i, j]);
                                            startDate.BusinessDayConvention = businessDayConv;
                                            startDate.SetRefDate(refDate);

                                            if (EndDateArray[k, l].GetType() == typeof(string))
                                                endDate = new MyDates((string)EndDateArray[k, l], startDate);
                                            else
                                            {
                                                endDate = new MyDates((dynamic)EndDateArray[k, l]);
                                                endDate.SetRefDate(refDate);
                                            }
                                            endDate.BusinessDayConvention = businessDayConv;

                                            output[Math.Max(i, k), Math.Max(j, l)] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
                                        }
                                    }
                                    catch
                                    {
                                        output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                                    }
                                    
                                }
                }
                return output;
            }

            #region deprecated
            //if (!StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            //{
            //    startDate = new MyDates((dynamic)StartDate);
            //    endDate = new MyDates((dynamic)EndDate);

            //    if (!ExcelHelper.IsMissing(RefDate))
            //    {
            //        startDate.SetRefDate((dynamic)RefDate);
            //        endDate.SetRefDate((dynamic)RefDate);
            //    }

            //    //override of the reference date of the end period if it is defined as a tenor
            //    if (EndDate.GetType() == typeof(string)) endDate.SetRefDate(startDate);

            //    startDate.BusinessDayConvention = businessDayConv;
            //    endDate.BusinessDayConvention = businessDayConv;

            //    return ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //}
            //else if (StartDate.GetType().IsArray && !EndDate.GetType().IsArray)
            //{
            //    object[] StartDateArray = (StartDate.GetType().IsCOMObject ? (Array)((Excel.Range)StartDate).Value2 : (Array)StartDate).Cast<object>().ToArray();
            //    object[] output = new object[StartDateArray.Length];
            //    for (int i = 0; i < StartDateArray.Length; i++)
            //    {
            //        if (ExcelHelper.IsMissing(StartDateArray[i]))
            //            output[i] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        else
            //        {
            //            startDate = new MyDates((dynamic)StartDateArray[i]);
            //            endDate = new MyDates((dynamic)EndDate);
            //            if (!ExcelHelper.IsMissing(RefDate))
            //            {
            //                startDate.SetRefDate((dynamic)RefDate);
            //                endDate.SetRefDate((dynamic)RefDate);
            //            }

            //            output[i] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //        }
            //    }
            //    return output;
            //}
            //else if (!StartDate.GetType().IsArray && EndDate.GetType().IsArray)
            //{
            //    object[] EndDateArray = (EndDate.GetType().IsCOMObject ? (Array)((Excel.Range)EndDate).Value2 : (Array)EndDate).Cast<object>().ToArray();
            //    object[] output = new object[EndDateArray.Length];
            //    for (int i = 0; i < EndDateArray.Length; i++)
            //    {
            //        if (ExcelHelper.IsMissing(EndDateArray[i]))
            //            output[i] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        else
            //        {
            //            startDate = new MyDates((dynamic)StartDate);
            //            endDate = new MyDates((dynamic)EndDateArray[i]);

            //            if (!ExcelHelper.IsMissing(RefDate))
            //            {
            //                startDate.SetRefDate((dynamic)RefDate);
            //                endDate.SetRefDate((dynamic)RefDate);
            //            }

            //            output[i] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //        }
            //    }
            //    return output;
            //}
            ////both are arrays
            //else
            //{
            //    object[] StartDateArray = (StartDate.GetType().IsCOMObject ? (Array)((Excel.Range)StartDate).Value2 : (Array)StartDate).Cast<object>().ToArray();
            //    object[] EndDateArray = (EndDate.GetType().IsCOMObject ? (Array)((Excel.Range)EndDate).Value2 : (Array)EndDate).Cast<object>().ToArray();
            //    object[,] output = new object[StartDateArray.Length, EndDateArray.Length];

            //    for (int i = 0; i < StartDateArray.Length; i++)
            //    {
            //        if (ExcelHelper.IsMissing(StartDateArray[i]))
            //        {
            //            for (int j = 0; j < EndDateArray.Length; j++)
            //                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        }
            //        else
            //        {
            //            startDate = new MyDates((dynamic)StartDateArray[i]);
            //            if (!ExcelHelper.IsMissing(RefDate))
            //                startDate.SetRefDate((dynamic)RefDate);

            //            for (int j = 0; j < EndDateArray.Length; j++)
            //            {
            //                if (ExcelHelper.IsMissing(EndDateArray[j]))
            //                    output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //                else
            //                {
            //                    endDate = new MyDates((dynamic)EndDateArray[j]);
            //                    if (!ExcelHelper.IsMissing(RefDate))
            //                        startDate.SetRefDate((dynamic)RefDate);

            //                    output[i, j] = ExcelHelper.CheckNaN(DateHelper.YearFraction(startDate.GetDate(), endDate.GetDate(), dayCountConvention));
            //                }
            //            }
            //        }
            //    }
            //    return output;
            //}
            #endregion
        }

        [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the date corresponding to the Tenor.", HelpTopic = @"https://en.wikipedia.org/wiki/Day_count_convention", IsThreadSafe = true)]
        public static object SCOR_TENORDATE(
            [ExcelArgument(@"StartDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] object Tenor,
            [ExcelArgument(@"[Optional] ReferenceDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"") = Today")][System.Runtime.InteropServices.Optional] object ReferenceDate,
            [ExcelArgument(@"[Optional: BusinessDayConvention as String = ""FOLLOWING"" (""FOLLOWING"", ""MODIFIED_FOLLOWING"", ""PRECEDING"", ""MODIFIED_PRECEDING"", ""NONE"")]")][System.Runtime.InteropServices.Optional] object BusinessDayConvention
            )
        {
            if (ExcelHelper.IsMissing(Tenor)) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            
            BusinessDayConventionType businessDayConvention = BusinessDayConventionType.FOLLOWING;
            if (!ExcelHelper.IsMissing(BusinessDayConvention))
                if (!Enum.TryParse(BusinessDayConvention.ToString(), true, out businessDayConvention))
                    return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

            MyDates refDate = new MyDates();
            if (!ExcelHelper.IsMissing(ReferenceDate))
                refDate.SetDate((dynamic)ReferenceDate);


            MyDates tenorDate;

            //if singleton
            if (!Tenor.GetType().IsArray)
            {
                if (Tenor.ToString() == string.Empty) return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                tenorDate = new MyDates((dynamic)Tenor);
                tenorDate.SetRefDate(refDate);
                tenorDate.BusinessDayConvention = businessDayConvention;
                return tenorDate.GetDate();
            }
            //if matricial
            else
            {
                object[,] TenorArray = (object[,])Tenor;
                object[,] output = new object[TenorArray.GetLength(0), TenorArray.GetLength(1)];

                for (int i = 0; i < TenorArray.GetLength(0); i++)
                    for (int j = 0; j < TenorArray.GetLength(1); j++)
                        try
                        {
                            if (ExcelHelper.IsMissing(TenorArray[i, j]))
                                output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                            else
                            {
                                if (TenorArray[i, j].ToString() == string.Empty) output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);

                                tenorDate = new MyDates((dynamic)TenorArray[i, j]);
                                tenorDate.SetRefDate(refDate);
                                tenorDate.BusinessDayConvention = businessDayConvention;
                                output[i, j] = tenorDate.GetDate();
                            }
                        }
                        catch
                        {
                            output[i, j] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
                        }
                return output;
            }

            #region deprecated
            //MyDates tenorDate;
            //if (Tenor.GetType().IsArray)
            //{
            //    object[] TenorArray = (Tenor.GetType().IsCOMObject ? (Array)((Excel.Range)Tenor).Value2 : (Array)Tenor).Cast<object>().ToArray();
            //    object[] output = new object[TenorArray.Length];
            //    for (int i = 0; i < output.Length; i++)
            //    {
            //        if(ExcelHelper.IsMissing(TenorArray[i]))
            //            output[i] = ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //        else
            //        {
            //            tenorDate = new MyDates((dynamic)TenorArray[i]);

            //            if (!ExcelHelper.IsMissing(ReferenceDate))
            //                tenorDate.SetRefDate((dynamic)ReferenceDate);

            //            if (!ExcelHelper.IsMissing(BusinessDayConvention))
            //                if (Enum.TryParse(BusinessDayConvention.ToString(), true, out BusinessDayConventionType businessDayConvention))
            //                    tenorDate.BusinessDayConvention = businessDayConvention;

            //            output[i] = tenorDate.GetDate();
            //        }
            //    }

            //    if (Tenor.GetType() == typeof(object[,]))
            //        return ExcelHelper.Transpose(output);
            //    else
            //        return output;
            //}
            //else
            //{
            //    tenorDate = new MyDates(Tenor.ToString());
            //    try
            //    {
            //        if (!ExcelHelper.IsMissing(ReferenceDate))
            //            tenorDate.SetRefDate((dynamic)ReferenceDate);

            //        if (!ExcelHelper.IsMissing(BusinessDayConvention))
            //            if (Enum.TryParse(BusinessDayConvention.ToString(), true, out BusinessDayConventionType businessDayConvention))
            //                tenorDate.BusinessDayConvention = businessDayConvention;

            //        return tenorDate.GetDate();
            //    }
            //    catch
            //    {
            //        return ExcelErrorUtil.ToComError(ExcelError.ExcelErrorValue);
            //    }
            //}
            #endregion
        }

        /*
                [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Price, Accrued Interest, Yield to Maturity, Duration and Convexity for a bond specified with the input parameters. Output is an array of 5 elements Array(Price, Accrued Interest, Yield, Duration, Convexity)", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_(finance)", IsThreadSafe = true)]
                public static double[] SCOR_BONDPRICING(
                    [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                    [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                    [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                    [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                    [ExcelArgument(@"[Optional] QuotedPrice as Double = 100 (Clean Price, quoted in Percentage)")] double QuotedPrice,
                    [ExcelArgument(@"[Optional] Yield as Double = CouponRate (e.g. 3% should be 0.03)")] double Yield,
                    [ExcelArgument(@"[Optional] YCidentifier as String (Name of an existing curve)")] string YCidentifier
                    )
                {
                    double price = 0, accruedInterest = 0.1, yield = -100, duration = -1, convexity = -2;

                    double[] output = new double[5];
                    output[0] = price;
                    output[1] = accruedInterest;
                    output[2] = yield;
                    output[3] = duration;
                    output[4] = convexity;
                    return output;
                    throw new NotImplementedException();
                }

                [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Yield to Maturity for a bond specified with the input parameters and a given Yield.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
                public static double SCOR_BONDYIELDTOPRICE(
                    [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                    [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                    [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                    [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                    [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield
                    )
                {
                    return 0;
                    throw new NotImplementedException();
                }

                [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Clean Price for a bond specified with the input parameters and a given Price.", HelpTopic = @"https://en.wikipedia.org/wiki/Yield_to_maturity", IsThreadSafe = true)]
                public static double SCOR_BONDPRICETOYIELD(
                    [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                    [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                    [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                    [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                    [ExcelArgument(@"Price as Double (Clean Price, quoted in Percentage)")] double Price
                    )
                {
                    return 0;
                    throw new NotImplementedException();
                }

                [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Modified Duration for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_duration", IsThreadSafe = true)]
                public static double SCOR_BONDDURATION(
                    [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                    [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                    [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                    [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                    [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield
                    )
                {
                    return 0;
                    throw new NotImplementedException();
                }

                [ExcelFunction(Category = @"SCOR Add-In", Description = @"Computes the Convexity for a bond specified with the input parameters.", HelpTopic = @"https://en.wikipedia.org/wiki/Bond_convexity", IsThreadSafe = true)]
                public static double SCOR_BONDCONVEXITY(
                    [ExcelArgument(@"MaturityDate as Date/Double/String (Tenors included, e.g. annual would be ""1Y"" or ""12M"")")] double MaturityDate,
                    [ExcelArgument(@"CouponRate as Double (e.g. 3% should be 0.03)")] double CouponRate,
                    [ExcelArgument(@"CouponFrequency as String (similar to Tenors, e.g. annual would be ""1Y"" or ""12M"")")] double CouponFrequency,
                    [ExcelArgument(@"DayCountConvention as String = ""ACT/360""]")] string DayCountConvention,
                    [ExcelArgument(@"Yield as Double (e.g. 3% should be 0.03)")] double Yield
                    )
                {
                    return 0;
                    throw new NotImplementedException();
                }
        */


        internal static Curve CreateCurve(
            object YCTenors,
            object YCZC,
            [System.Runtime.InteropServices.Optional] object AsOfDate,
            [System.Runtime.InteropServices.Optional] object InterestMethod,
            [System.Runtime.InteropServices.Optional] object DayCountConvention,
            [System.Runtime.InteropServices.Optional] object InterpolMethod
            )
        {
            if (ExcelHelper.IsMissing(YCTenors) || ExcelHelper.IsMissing(YCZC)) throw new ArgumentNullException();
            //if the curve is not properly defined (i.e. 1 of the 2 vectors is a singleton), exit
            if (!YCZC.GetType().IsArray || !YCTenors.GetType().IsArray) throw new ArgumentNullException();


            //ExcelDNA COM wrapper transforms ranges in 2 dimensional objects (line or column vectors alike)
            object[,] TenorArray = (object[,])(YCTenors);
            object[,] ZCArray = (object[,])(YCZC);

            if (TenorArray.Length != ZCArray.Length) throw new ArgumentNullException();
            if (TenorArray.GetLength(0) != ZCArray.GetLength(0)) ZCArray = ExcelHelper.Transpose(ZCArray);

            List<Instrument> myInstruments = new List<Instrument>();

            for (int i = 0; i < TenorArray.GetLength(0); i++)
                for (int j = 0; j < TenorArray.GetLength(1); j++)
                {
                    try
                    {
                        if (!ExcelHelper.IsMissing(TenorArray[i, j]) && !ExcelHelper.IsMissing(ZCArray[i, j]))
                            if (TenorArray[i, j].ToString() != string.Empty && ZCArray[i, j].ToString() != string.Empty)
                                myInstruments.Add(new Instrument(new MyDates((dynamic)TenorArray[i, j]), (double)ZCArray[i, j]));
                    }
                    catch
                    {
                    }
                }

            if (myInstruments.Count == 0) throw new ArgumentNullException();

            Curve YC = new Curve(myInstruments);
            if (!ExcelHelper.IsMissing(AsOfDate)) YC.AsOfDate = new MyDates((dynamic)AsOfDate);

            InterestMethodType interestMethod = InterestMethodType.COMPOUNDING_DISCRETE;
            if (!ExcelHelper.IsMissing(InterestMethod))
                if (!Enum.TryParse(InterestMethod.ToString(), true, out interestMethod))
                    throw new ArgumentNullException();
            YC.InterestMethod = interestMethod;

            DayCountConventionType dayCountConvention = DayCountConventionType.ACT_360;
            if (!ExcelHelper.IsMissing(DayCountConvention))
                if (!Enum.TryParse(DayCountConvention.ToString(), true, out dayCountConvention))
                    throw new ArgumentNullException();
            YC.DayCountConvention = dayCountConvention;


            InterpolationMethodType interpolationMethod = InterpolationMethodType.LINEAR;
            if (!ExcelHelper.IsMissing(InterpolMethod))
                if (!Enum.TryParse(InterpolMethod.ToString(), true, out interpolationMethod))
                    throw new ArgumentNullException();
            YC.InterpolationMethod = interpolationMethod;
            
            return YC;
        }


        #region CACHE
        /*
        //STATUS: working but not faster at the time being with 1800 calls

        [ExcelFunction(Category = @"SCOR TEST", Description = "Create Interpolator object, test of cache")]
        public static object SCOR_CACHE_CURVE_CREATE(
            [ExcelArgument(Description = "Array of nodes")] double[] x,
            [ExcelArgument(Description = "Array of values")]  double[] y,
            [ExcelArgument(Description = "Interpolation Method = Linear or Natural Cubic Spline")] string interpolMethod)
        {
            if (!Enum.TryParse(interpolMethod, out InterpolationMethodType interpolationMethod))
                return ExcelError.ExcelErrorValue;
            else
            {
                return Cache.GlobalCache.CreateHandle(YCTag, new object[] { x, y, interpolationMethod }, (objectType, parameters) =>
                  {
                      Curve YC = null;
                      try
                      {
                          YC = new Curve(x, y);
                      }
                      catch (Exception e)
                      {
                          return e;
                      }

                      if (YC == null)
                          return ExcelError.ExcelErrorNull;
                      else
                          return YC;
                  }
                  );
            }
        }


        [ExcelFunction(Category = @"SCOR TEST", Description = "Evaluate interpolation at specified point")]
        public static object SCOR_CACHE_CURVE_INTERPOLATE(
            [ExcelArgument(Description = "Interpolator object")] string handle,
            [ExcelArgument(Description = "Interpolation point")] double x)
        {
            if (Cache.GlobalCache.TryGetObject(handle, out Curve YC))
            {
                if (YC != null)
                {
                    return ExcelHelper.CheckNaN(YC.ZeroCoupon(x));
                }
            }

            return ExcelError.ExcelErrorRef;
        }




        //END TUTORIAL CACHE
        */
        #endregion


    }
}
